<?php

declare(strict_types=1);

namespace App\Helpers;

final class DtoHelper
{
    public static function valueToArrayOrNull(string $name, array $arguments): ?array
    {
        $value = $arguments[$name] ?? null;
        if (!$value) {
            return null;
        }

        if (is_array($value)) {
            return $value;
        }

        return [$value];
    }
}
