<?php

declare(strict_types=1);

namespace App\Helpers;

use Illuminate\Support\Str;

class Arr extends \Illuminate\Support\Arr
{
    public static function getArrayOfInt($array, $key, $default = null)
    {
        $array = static::get($array, $key, $default);

        if ($array === $default) {
            return $array;
        }

        return array_map(static function (string $item) {
            return $item ? (int) $item : null;
        }, $array);
    }
}
