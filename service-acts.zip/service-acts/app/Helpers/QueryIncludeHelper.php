<?php

declare(strict_types=1);

namespace App\Helpers;

use Illuminate\Http\Request;

final class QueryIncludeHelper
{
    public function __construct(private array $includes) {}

    public function has(string $field): bool
    {
        return in_array($field, $this->includes, true);
    }

    public static function parse(string $value): self
    {
        return new self(explode(',', $value));
    }

    public static function fromRequest(Request $request): self
    {
        return self::parse((string) $request->input('include', ''));
    }
}
