<?php

declare(strict_types=1);

namespace App\Helpers;

use Illuminate\Support\Carbon;

final class FileHelper
{
    public static function getPath(): string
    {
        return Carbon::now()->format('/Y/m/d/H/i/s/') . hash('sha256', (string) rand(10, 9999)) . '/';
    }

    public static function generateFilePath(string $contents, ?string $extension = null, ?string $prefixFolder = null): string
    {
        $hash = hash('sha256', $contents);
        $path = self::getPath();

        return ($prefixFolder ?? '') . $path . $hash . ($extension ? '.' . $extension : '');
    }
}
