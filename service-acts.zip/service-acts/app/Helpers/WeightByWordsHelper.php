<?php

declare(strict_types=1);

namespace App\Helpers;

use Illuminate\Support\Str;
use NoName\Dictionaries\Acts\ActMeasureDictionary;
use NumberFormatter;
use RuntimeException;

final class WeightByWordsHelper
{
    protected const TRANSLATION_KEY_TON       = 'measures.ton';
    protected const TRANSLATION_KEY_KG        = 'measures.kg';
    protected const TRANSLATION_KEY_GRAM      = 'measures.gram';
    protected const TRANSLATION_KEY_MILLIGRAM = 'measures.milligram';

    public static function num2str(float $value, int $measureId, $locale = 'ru'): string
    {
        [$integerTransKeys, $decimalTransKeys] = self::getMeasureTransKeys($measureId);

        $parts = explode('.', number_format(abs($value), 3, '.', ' '));

        $integerParts = self::explodeThousands(' ', $parts[0], count($integerTransKeys));
        $decimalPart = (int) $parts[1];

        $integerTransKeys = array_reverse($integerTransKeys);
        $integerParts     = array_reverse($integerParts);

        $res = [];
        foreach ($integerParts as $key => $integerPart) {
            $integerPart = (int) $integerPart;
            $transKey = $integerTransKeys[$key];
            if ($integerPart > 0 || count($integerParts) === 1) {
                $res[] = self::formatAsSingleMeasure($integerPart, $transKey, $locale);
            }
        }

        $res = array_reverse($res);

        if ($decimalPart > 0) {
            $res[] = self::formatAsSingleMeasure($decimalPart, $decimalTransKeys[0], $locale);
        }

        return implode(' ', $res);
    }

    /**
     * @return array<string>
     */
    private static function explodeThousands(string $separator, string $string, int $limit): array
    {
        $parts = explode($separator,  $string);

        $result = [];

        for ($i = 1; $i < $limit; $i++) {
            $part = array_pop($parts);

            if ($part === null) {
                break;
            }

            $result[] = $part;
        }

        if (count($parts) > 0) {
            $result[] = implode('', $parts);
        }

        return array_reverse($result);
    }

    private static function formatAsSingleMeasure(float $value, string $transKey, $locale = 'ru'): string
    {
        $number = floor($value);

        $formatter = NumberFormatter::create($locale, NumberFormatter::SPELLOUT);

        if (!$formatter) {
            throw new RuntimeException('Failed to create formatter for locale ' . $locale);
        }

        $strNumber = $formatter->format($number);

        if ($transKey === self::TRANSLATION_KEY_TON) {
            if ($locale === 'ru' || $locale === 'ru_RU') {
                foreach (['один' => 'одна', 'два' => 'две'] as $search => $replace) {
                    if (Str::endsWith($strNumber, $search)) {
                        $strNumber = Str::replaceLast($search, $replace, $strNumber);
                    }
                }
            }
        }

        return trans_choice($transKey, $number, ['value' => $strNumber], $locale);
    }

    /**
     * Определение ключей для целой и дробной части числа для склонения в разных языках
     *
     * @return array{0: array, 1: array}
     */
    private static function getMeasureTransKeys(int $measureId): array
    {
        return match ($measureId) {
            ActMeasureDictionary::WEIGHT_TON => [
                [self::TRANSLATION_KEY_TON],
                [self::TRANSLATION_KEY_KG],
            ],
            ActMeasureDictionary::KILOGRAM => [
                [self::TRANSLATION_KEY_TON, self::TRANSLATION_KEY_KG],
                [self::TRANSLATION_KEY_GRAM],
            ],
            ActMeasureDictionary::GRAM => [
                [self::TRANSLATION_KEY_TON, self::TRANSLATION_KEY_KG, self::TRANSLATION_KEY_GRAM],
                [self::TRANSLATION_KEY_MILLIGRAM],
            ],
        };
    }
}
