<?php

declare(strict_types=1);

namespace App\Helpers;

use NumberFormatter;

final class AmountByWordsHelper
{
    private const LANG_WORDS = [
        [1, 2, 3,], // рубли
        [4, 5, 6],  // копейки
    ];

    /**
     * Получение строкового описания значения от числового с указанием единиц измерения.
     * Пример: 86921.26 -> восемьдесят шесть тысяч девятьсот двадцать один рубль 26 копеек
     *
     * @param int|float $value
     * @param string    $locale
     *
     * @return string
     */
    public static function num2str(int|float $value, string $locale = 'ru'): string
    {
        $value = explode('.', number_format($value, 2, '.', ''));

        $formatter = new NumberFormatter($locale, NumberFormatter::SPELLOUT);
        $str       = $formatter->format((int) $value[0]);

        $rub  = self::endingOfWord((int) $value[0], 0);
        $cent = self::endingOfWord((int) $value[1], 1);

        $result = $str . ' ' . $rub . ' ' . $value[1] . ' ' . $cent;

        return mb_strtoupper(mb_substr($result, 0, 1)) . mb_substr($result, 1);
    }

    /**
     * Определение склонения рубля / копейки в зависимости от значения.
     * $langWordsKey может быть: 0 - для рублей и 1 - для копеек
     *
     * @param int $value
     * @param int $langWordsKey
     *
     * @return string
     */
    private static function endingOfWord(int $value, int $langWordsKey): string
    {
        if (($value = $value % 100) > 19) $value %= 10;

        return match ($value) {
            1 => __('amountByWords.' . self::LANG_WORDS[$langWordsKey][0]),
            2, 3, 4 => __('amountByWords.' . self::LANG_WORDS[$langWordsKey][1]),
            default => __('amountByWords.' . self::LANG_WORDS[$langWordsKey][2]),
        };
    }
}
