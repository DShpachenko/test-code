<?php

declare(strict_types=1);

namespace App\Models\Storage;

use Illuminate\Database\Eloquent\Model;

final class File extends Model
{
    protected $table = 'storage.files';

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    protected $casts = [
        'created_at'  => 'immutable_datetime:Y-m-d H:i:s',
        'updated_at'  => 'immutable_datetime:Y-m-d H:i:s',
    ];

    protected $fillable = [
        'type',
        'path',
    ];
}
