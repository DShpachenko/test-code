<?php

declare(strict_types=1);

namespace App\Models\Acts;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

/**
 * @property Act $act
 */
final class ActSignature extends Model
{
    protected $table = 'acts.act_signatures';

    protected $dates = [
        'manager_signature_at',
        'employee_signature_at',
        'created_at',
        'updated_at',
    ];

    protected $casts = [
        'manager_signature_at'  => 'immutable_datetime:Y-m-d H:i:s',
        'employee_signature_at' => 'immutable_datetime:Y-m-d H:i:s',
        'created_at'            => 'immutable_datetime:Y-m-d H:i:s',
        'updated_at'            => 'immutable_datetime:Y-m-d H:i:s',
    ];

    protected $fillable = [
        'act_id',
        'manager_signature_id',
        'employee_signature_id',
        'manager_signature_at',
        'employee_signature_at',
        'created_at',
        'updated_at',
    ];

    public function act(): BelongsTo
    {
        return $this->belongsTo(Act::class);
    }
}
