<?php

declare(strict_types=1);

namespace App\Models\Acts;

use App\Models\Storage\File;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

final class ActFile extends Model
{
    use SoftDeletes;

    protected $table = 'acts.act_file';

    public $timestamps = false;

    protected $dates = [
        'created_at',
    ];

    protected $casts = [
        'created_at' => 'immutable_datetime:Y-m-d H:i:s',
    ];

    protected $fillable = [
        'act_id',
        'file_id',
        'created_at',
    ];

    public function act(): BelongsTo
    {
        return $this->belongsTo(Act::class);
    }

    public function file(): BelongsTo
    {
        return $this->belongsTo(File::class);
    }
}
