<?php

declare(strict_types=1);

namespace App\Models\Acts;

use App\Models\Storage\File;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasOneThrough;
use Illuminate\Database\Eloquent\SoftDeletes;

/**
 * @property int     $id
 * @property int     $company_id
 * @property string  $name
 * @property int     $agent_id
 * @property string  $sign_order
 * @property ?int    $manager_contractor_id
 * @property Carbon  $created_at
 * @property Carbon  $updated_at
 * @property ?Carbon $deleted_at
 */
final class Template extends Model
{
    use SoftDeletes;

    protected $table = 'acts.templates';

    protected $casts = [
        'created_at' => 'immutable_datetime:Y-m-d H:i:s',
        'updated_at' => 'immutable_datetime:Y-m-d H:i:s',
    ];

    protected $fillable = [
        'company_id',
        'name',
        'agent_id',
        'sign_order',
        'manager_contractor_id',
    ];

    public function file(): HasOneThrough
    {
        return $this->hasOneThrough(
            File::class,
            TemplateFile::class,
            'template_id',
            'id',
            'id',
            'file_id'
        );
    }
}
