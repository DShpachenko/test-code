<?php

declare(strict_types=1);

namespace App\Models\Acts;

use App\Models\Storage\File;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

final class TemplateFile extends Model
{
    protected $table = 'acts.template_file';

    public $timestamps = false;

    protected $casts = [
        'created_at' => 'immutable_datetime:Y-m-d H:i:s',
    ];

    protected $fillable = [
        'template_id',
        'file_id',
        'created_at',
    ];

    public function template(): BelongsTo
    {
        return $this->belongsTo(Template::class);
    }

    public function file(): BelongsTo
    {
        return $this->belongsTo(File::class);
    }
}
