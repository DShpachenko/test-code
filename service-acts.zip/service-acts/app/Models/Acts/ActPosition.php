<?php

declare(strict_types=1);

namespace App\Models\Acts;

use Illuminate\Database\Eloquent\Model;

final class ActPosition extends Model
{
    protected $table = 'acts.act_positions';

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    protected $casts = [
        'value'            => 'float',
        'impurity_percent' => 'float',
        'tare_weight'      => 'float',
        'price'            => 'float',
        'amount'           => 'float',
        'clear_value'      => 'float',
        'created_at'       => 'immutable_datetime:Y-m-d H:i:s',
        'updated_at'       => 'immutable_datetime:Y-m-d H:i:s',
    ];

    protected $fillable = [
        'act_id',
        'name',
        'type',
        'measure_unit_id',
        'value',
        'impurity_percent',
        'tare_weight',
        'price',
        'amount',
        'clear_value',
    ];
}
