<?php

declare(strict_types=1);

namespace App\Models\Acts;

use App\Models\Storage\File;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

final class Export extends Model
{
    protected $table = 'acts.exports';

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    protected $casts = [
        'filters'        => 'array',
        'status_details' => 'array',
        'created_at'     => 'immutable_datetime:Y-m-d H:i:s',
        'updated_at'     => 'immutable_datetime:Y-m-d H:i:s',
    ];

    protected $fillable = [
        'company_id',
        'author_id',
        'status',
        'status_details',
        'email',
        'filters',
        'type',
    ];

    public function files(): BelongsToMany
    {
        return $this->belongsToMany(File::class, ExportFile::class);
    }
}
