<?php

declare(strict_types=1);

namespace App\Models\Acts;

use App\Models\Storage\File;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Collection;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;
use Illuminate\Database\Eloquent\Relations\HasOneThrough;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasOne;

/**
 * @property string $status
 * @property string $external_number
 * @property Carbon $created_at
 *
 * @property-read ActSignature|null $signature
 * @property-read File|null         $file
 * @property-read Collection|File[] $files
 * @property-read Collection $positions
 */
final class Act extends Model
{
    use SoftDeletes;

    protected $table = 'acts.acts';

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    protected $casts = [
        'info'        => 'array',
        'period_from' => 'date:Y-m-d',
        'period_to'   => 'date:Y-m-d',
        'total_price' => 'float',
        'created_at'  => 'immutable_datetime:Y-m-d H:i:s',
        'updated_at'  => 'immutable_datetime:Y-m-d H:i:s',
    ];

    protected $fillable = [
        'author_id',
        'manager_contractor_id',
        'company_id',
        'employee_contractor_id',
        'agent_id',
        'source_document_id',
        'act_document_id',
        'payment_id',
        'number',
        'name',
        'description',
        'total_price',
        'period_from',
        'period_to',
        'status',
        'info',
        'payment_id',
        'document_hash',
        'template_id',
        'sign_order',
        'type',
        'branch_office_id',
        'external_number',
    ];

    public function signature(): HasOne
    {
        return $this->hasOne(ActSignature::class);
    }

    public function file(): HasOneThrough
    {
        return $this->hasOneThrough(
            File::class,
            ActFile::class,
            'act_id',
            'id',
            'id',
            'file_id'
        );
    }

    public function files(): HasManyThrough
    {
        return $this->hasManyThrough(
            File::class,
            ActFile::class,
            'act_id',
            'id',
            'id',
            'file_id'
        );
    }

    public function positions(): HasMany
    {
        return $this->hasMany(
            ActPosition::class,
            'act_id',
            'id',
        );
    }
}
