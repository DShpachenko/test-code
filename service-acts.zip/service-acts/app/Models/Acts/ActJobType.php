<?php

declare(strict_types=1);

namespace App\Models\Acts;

use Illuminate\Database\Eloquent\Model;

final class ActJobType extends Model
{
    protected $table = 'acts.act_job_types';

    protected $dates = [
        'created_at',
        'updated_at',
    ];

    protected $casts = [
        'price'      => 'float',
        'created_at' => 'immutable_datetime:Y-m-d H:i:s',
        'updated_at' => 'immutable_datetime:Y-m-d H:i:s',
    ];

    protected $fillable = [
        'act_id',
        'name',
        'price',
        'count',
        'measure_id',
    ];
}
