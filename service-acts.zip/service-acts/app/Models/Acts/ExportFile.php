<?php

declare(strict_types=1);

namespace App\Models\Acts;

use Illuminate\Database\Eloquent\Model;

final class ExportFile extends Model
{
    protected $table = 'acts.export_files';

    public $timestamps = false;

    protected $dates = [
        'created_at',
    ];

    protected $casts = [
        'created_at' => 'immutable_datetime:Y-m-d H:i:s',
    ];

    protected $fillable = [
        'export_id',
        'file_id',
        'created_at',
    ];
}
