<?php

declare(strict_types=1);

namespace App\Models\Logs;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * @property int $id
 * @property ?int $customer_id
 * @property string $action
 * @property ?int $entity_id
 * @property ?array $info
 * @property Carbon $created_at
 */
final class OperationLog extends Model
{
    public $timestamps = false;

    protected $table = 'logs.operation_logs';

    protected $dates = [
        'created_at',
    ];

    protected $casts = [
        'info'       => 'array',
        'created_at' => 'immutable_datetime:Y-m-d H:i:s',
    ];

    protected $fillable = [
        'customer_id',
        'action',
        'entity_id',
        'info',
        'created_at',
    ];
}
