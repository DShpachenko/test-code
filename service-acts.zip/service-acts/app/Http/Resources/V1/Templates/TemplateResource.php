<?php

declare(strict_types=1);

namespace App\Http\Resources\V1\Templates;

use App\Enums\NoName\Templates\SignOrderEnum;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Dto\Pipelines\Templates\GetTemplatePipelineDto;
use App\Dto\Pipelines\Templates\CreateTemplatePipelineDto;

final class TemplateResource extends JsonResource
{
    public function toArray($request): array
    {
        $dto               = $this->dto();
        $template          = $dto->getTemplate();
        $agent             = $dto->getAgent();
        $managerContractor = $dto->getManagerContractor();

        return [
            'id'                 => $template->getId(),
            'name'               => $template->getName(),
            'agent'              => [
                'id'   => $agent->getId(),
                'name' => $agent->getName(),
            ],
            'sign_order'         => [
                'title' => SignOrderEnum::title($template->getSignOrder()),
                'value' => $template->getSignOrder(),
            ],
            'manager_contractor' => $managerContractor ? [
                'id'        => $managerContractor->getId(),
                'short_name' => $managerContractor->getShortName(),
            ] : null,
        ];
    }

    private function dto(): CreateTemplatePipelineDto|GetTemplatePipelineDto
    {
        return $this->resource;
    }
}
