<?php

declare(strict_types=1);

namespace App\Http\Resources\V1\Acts;

use App\Dto\Entities\Acts\ActDto;
use App\Dto\Entities\Acts\ActJobTypeDto;
use App\Dto\Pipelines\Acts\GetActPipelineDto;
use App\Dto\Pipelines\Acts\CreateActPipelineDto;
use App\Enums\NoName\Acts\StatusEnum;
use App\Services\Act\ActService;
use Illuminate\Http\Resources\Json\JsonResource;
use App\Exceptions\Pipelines\ObjectNotFoundException;

final class ActResource extends JsonResource
{
    private bool $isFullView      = false;
    private bool $isForContractor = false;
    private bool $isInternal      = false;

    public function toArray($request): array
    {
        /** @var \NoName\ClientAuthJwt\Dto\UserSet $user */
        $user = auth()->user();

        /** @var ActDto $act */
        [$act, $dto] = $this->prepareData();

        if (! $act) {
            throw new ObjectNotFoundException();
        }

        $signature                   = $act->getSignature();
        $agent                       = $dto->getAgent();
        $managerContractor           = $dto->getManagerContractor();
        $managerContractorWorkplace  = $dto->getManagerContractorsWorkplace();
        $managerPosition             = $managerContractorWorkplace?->getPosition();
        $employeeContractor          = $dto->getEmployeeContractor();
        $employeeContractorWorkplace = $dto->getEmployeeContractorsWorkplace();
        $employeePosition            = $employeeContractorWorkplace?->getPosition();

        $response = [
            'id'                 => $act->getId(),
            'name'               => $act->getName(),
            'status'             => $this->prepareStatus($act),
            'number'             => $act->getNumber(),
            'description'        => $act->getDescription(),
            'total_price'        => $act->getTotalPrice(),
            'period_from'        => $act->getPeriodFrom('Y-m-d'),
            'period_to'          => $act->getPeriodTo('Y-m-d'),
            'act_document_id'    => $act->getActDocumentId(),
            'agent'              => [
                'id'   => $agent->getId(),
                'name' => $agent->getName(),
            ],
            'manager_signature'  => [
                'contractor' => [
                    'id'        => $managerContractor->getId(),
                    'full_name' => $managerContractor->getFullName(),
                    'position'  => $managerPosition ? [
                        'id'   => $managerPosition->getId(),
                        'name' => $managerPosition->getName(),
                    ] : null,
                ],
                'signature'  => ($signature?->getManagerSignatureId() && $signature?->getManagerSignatureAt()) ? [
                    'id'                   => $signature->getManagerSignatureId(),
                    'manager_signature_at' => $signature->getManagerSignatureAt(),
                ] : null,
            ],
            'employee_signature' => [
                'contractor' => [
                    'id'        => $employeeContractor->getId(),
                    'full_name' => $employeeContractor->getFullName(),
                    'position'  => $employeePosition ? [
                        'id'   => $employeePosition->getId(),
                        'name' => $employeePosition->getName(),
                    ] : null,
                ],
                'signature'  => ($signature?->getEmployeeSignatureId() && $signature?->getEmployeeSignatureAt()) ? [
                    'id'                    => $signature->getEmployeeSignatureId(),
                    'employee_signature_at' => $signature->getEmployeeSignatureAt(),
                ] : null,
            ],
            'sign_order'         => $act->getSignOrder(),
            'created_at'         => $act->getCreatedAt(),
            'abilities'          => [
                'can_sign'   => ! $this->isInternal && ActService::canSign($act->getManagerContractorId(), $user),
                'can_delete' => ! $signature?->getEmployeeSignatureAt() && ! $signature?->getManagerSignatureAt(),
            ],
        ];

        if ($this->isFullView) {
            return array_merge($response, [
                'source_document_id' => $act->getSourceDocumentId(),
                'payment_id'         => $act->getPaymentId(),
                'job_types'          => array_map(function (ActJobTypeDto $actJobTypeDto) {
                    return $actJobTypeDto->toArray();
                }, $this->getJobTypes()),
            ]);
        }

        return $response;
    }

    public function setIsFullView(bool $isFullView): self
    {
        $this->isFullView = $isFullView;

        return $this;
    }

    public function setIsForContractor(bool $isForContractor): self
    {
        $this->isForContractor = $isForContractor;

        return $this;
    }

    public function setIsInternal(bool $isInternal): self
    {
        $this->isInternal = $isInternal;

        return $this;
    }

    private function prepareData(): array
    {
        if ($this->isFullView) {
            /** @var CreateActPipelineDto|GetActPipelineDto $this */
            $act = $this->getAct();
            $dto = $this;
        } else {
            $act = ActDto::fromArray($this->resource->toArray());
            $dto = GetActPipelineDto::fromArray(array_merge(['act' => $act], $act->getInfo()));
        }

        return [$act, $dto];
    }

    private function prepareStatus(ActDto $act): string
    {
        $status = $act->getStatus();

        if ($status !== StatusEnum::PROCESSING_SIGNATURE) {
            return $status;
        }

        return $this->isForContractor ? StatusEnum::PENDING_COMPANY_SIGNATURE : StatusEnum::PROCESSING_SIGNATURE;
    }
}
