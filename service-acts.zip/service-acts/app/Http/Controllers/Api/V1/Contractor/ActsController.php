<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Contractor;

use Carbon\Carbon;
use Illuminate\Http\Response;
use App\Services\Act\ActService;
use Illuminate\Http\JsonResponse;
use App\Pipelines\V1\Acts\ActsPipeline;
use Illuminate\Support\Facades\Storage;
use NoName\Framework\Response\MetaItems;
use App\Http\Resources\V1\Acts\ActResource;
use App\Dto\Pipelines\Acts\GetActPipelineDto;
use App\Exceptions\Pipelines\FileNotFoundException;
use Symfony\Component\HttpFoundation\StreamedResponse;
use App\Http\Requests\Api\V1\Contractor\Acts\GetRequest;
use App\Http\Requests\Api\V1\Contractor\Acts\CountRequest;
use NoName\Framework\Http\Controllers\Api\ApiController;
use App\Http\Requests\Api\V1\Contractor\Acts\PreviewRequest;
use App\Http\Requests\Api\V1\Contractor\Acts\AllByFiltersRequest;

final class ActsController extends ApiController
{
    public function __construct(private ActsPipeline $pipeline)
    {
    }

    public function get(GetRequest $request, int $id): JsonResponse
    {
        $act = $request->dto();
        $act->setId($id);

        [$dto, $e] = $this->pipeline->get(GetActPipelineDto::fromArray(['act' => $act]));

        if ($e) {
            return $this->errorResponse($e->getError());
        }

        return $this->itemResponse(ActResource::make($dto)->setIsFullView(true));
    }

    public function all(AllByFiltersRequest $request, ActService $service): JsonResponse
    {
        $rows = $service->allByFilters($request->dto());

        $actsCollection = array_map(
            fn ($row) => ActResource::make($row)->setIsForContractor(true),
            $rows->items()
        );

        return $this->listResponse($actsCollection, new MetaItems($rows));
    }

    public function count(CountRequest $request, ActService $service): JsonResponse
    {
        return response()->json([
            'data' => $service->getCountActsByStatuses($request->dto()),
        ]);
    }

    public function preview(PreviewRequest $request, int $id, ActService $actService): StreamedResponse
    {
        $act = $request->dto();
        $act->setId($id);

        if (!$path = $actService->get($act->toArray(), ['file'])?->getFile()?->getPath()) {
            throw new FileNotFoundException();
        }

        return Storage::disk('selectel')->download($path);
    }
}
