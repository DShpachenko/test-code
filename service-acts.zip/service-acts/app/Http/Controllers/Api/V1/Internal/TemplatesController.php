<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Internal;

use App\Dto\Pipelines\Templates\GetTemplateListPipelineDto;
use App\Http\Requests\Api\V1\Internal\Templates\GetTemplateListByFilterRequest;
use App\Http\Resources\V1\Templates\TemplateResource;
use App\Pipelines\V1\Templates\TemplatePipeline;
use Illuminate\Http\JsonResponse;
use App\Services\Act\TemplateService;
use NoName\Framework\Http\Controllers\Api\ApiController;
use App\Http\Requests\Api\V1\Internal\Templates\GetRequest;
use NoName\Framework\Response\MetaItems;

final class TemplatesController extends ApiController
{
    public function __construct(private TemplatePipeline $pipeline)
    {
    }

    public function list(GetTemplateListByFilterRequest $request): JsonResponse
    {
        /** @var GetTemplateListPipelineDto $dto */
        [$dto, $e] = $this->pipeline->list(GetTemplateListPipelineDto::fromArray(['filter' => $request->dto()]));

        if ($e) {
            return $this->errorResponse($e->getError());
        }

        return $this->listResponse(
            TemplateResource::collection($dto->getItems()),
            new MetaItems($dto->getPaginator())
        );
    }

    public function get(GetRequest $request, int $id, TemplateService $service): JsonResponse
    {
        $dto = $request->dto();
        $dto->setId($id);

        $template = $service->get($dto->toArray());

        return $this->itemResponse($template ? [
            'id'                    => $template->getId(),
            'name'                  => $template->getName(),
            'company_id'            => $template->getCompanyId(),
            'agent_id'              => $template->getAgentId(),
            'sign_order'            => $template->getSignOrder(),
            'manager_contractor_id' => $template->getManagerContractorId(),
            'created_at'            => $template->getCreatedAt(),
            'updated_at'            => $template->getUpdatedAt(),
        ] : null);
    }
}
