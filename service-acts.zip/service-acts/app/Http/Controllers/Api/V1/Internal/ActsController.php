<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Internal;

use Illuminate\Http\JsonResponse;
use App\Pipelines\V1\Acts\ActsPipeline;
use App\Http\Resources\V1\Acts\ActResource;
use NoName\Framework\Http\Controllers\Api\ApiController;
use App\Http\Requests\Api\V1\Internal\Acts\CreateFromPaymentImportRequest;

final class ActsController extends ApiController
{
    public function __construct(private ActsPipeline $pipeline)
    {
    }

    public function createFromPaymentImport(CreateFromPaymentImportRequest $request): JsonResponse
    {
        [$dto, $e] = $this->pipeline->createFromPaymentImport($request->dto());

        if ($e) {
            return $this->errorResponse($e->getError());
        }

        return $this->itemResponse(
            ActResource::make($dto)
                       ->setIsFullView(true)
                       ->setIsInternal(true)
        );
    }
}
