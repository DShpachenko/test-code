<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Company;

use Illuminate\Http\JsonResponse;
use App\Services\Act\JobTypeService;
use Illuminate\Support\Facades\Gate;
use App\Dto\Entities\Acts\JobTypeDto;
use App\Http\Requests\Api\V1\Company\JobTypes\AllRequest;
use NoName\Framework\Http\Controllers\Api\ApiController;
use App\Http\Requests\Api\V1\Company\JobTypes\DeleteRequest;
use App\Http\Requests\Api\V1\Company\JobTypes\CreateRequest;
use App\Http\Requests\Api\V1\Company\JobTypes\UpdateRequest;

final class JobTypesController extends ApiController
{
    public function __construct(private JobTypeService $service)
    {
    }

    public function create(CreateRequest $request): JsonResponse
    {
        Gate::authorize('canCreateActJobType');

        return $this->itemResponse($this->service->create($request->dto())?->toCustomArray());
    }

    public function all(AllRequest $request): JsonResponse
    {
        Gate::authorize('canAllActJobTypes');

        $rows = $this->service->list($request->dto()->toArray());

        return $this->listResponse(! is_null($rows) ? $rows->map(function (JobTypeDto $dto) {
            return $dto->toCustomArray();
        }) : []);
    }

    public function update(UpdateRequest $request, int $id): JsonResponse
    {
        Gate::authorize('canUpdateActJobType');

        $dto = $request->dto();

        $this->service->update([
            'id'         => $id,
            'company_id' => $dto->getCompanyId(),
        ], $dto->toArray());

        return $this->itemResponse($this->service->get([
            'id'         => $id,
            'company_id' => $dto->getCompanyId(),
        ])?->toCustomArray());
    }

    public function delete(DeleteRequest $request, int $id): JsonResponse
    {
        Gate::authorize('canDeleteActJobTypes');

        $this->service->delete([
            'id'         => $id,
            'company_id' => $request->dto()->getCompanyId(),
        ]);

        return $this->noContentResponse();
    }
}
