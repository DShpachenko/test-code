<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Company;

use App\Exceptions\Pipelines\FileNotFoundException;
use App\Http\Requests\Api\V1\Company\Acts\PreviewRequest;
use App\Http\Requests\Api\V1\Company\Acts\SignBySimpleSignatureRequest;
use App\Services\Act\ActService;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Gate;
use App\Pipelines\V1\Acts\ActsPipeline;
use Illuminate\Support\Facades\Storage;
use NoName\Framework\Response\MetaItems;
use App\Http\Resources\V1\Acts\ActResource;
use App\Dto\Pipelines\Acts\GetActPipelineDto;
use App\Http\Requests\Api\V1\Company\Acts\GetRequest;
use Symfony\Component\HttpFoundation\StreamedResponse;
use App\Http\Requests\Api\V1\Company\Acts\ExportRequest;
use App\Http\Requests\Api\V1\Company\Acts\DeleteRequest;
use App\Http\Requests\Api\V1\Company\Acts\CreateRequest;
use NoName\Framework\Http\Controllers\Api\ApiController;
use App\Http\Requests\Api\V1\Company\Acts\AllByFiltersRequest;
use NoName\Permissions\Permission;
use App\Http\Requests\Api\V1\Company\Acts\SignatureDocumentsInfoRequest;

final class ActsController extends ApiController
{
    public function __construct(private ActsPipeline $pipeline)
    {
    }

    public function create(CreateRequest $request): JsonResponse
    {
        Gate::authorize('canCreateAct');

        [$dto, $e] = $this->pipeline->create($request->dto());

        if ($e) {
            return $this->errorResponse($e->getError());
        }

        return $this->itemResponse(ActResource::make($dto)->setIsFullView(true));
    }

    public function get(GetRequest $request, int $id): JsonResponse
    {
        Gate::authorize('canGetAct');

        $act = $request->dto();
        $act->setId($id);

        [$dto, $e] = $this->pipeline->get(GetActPipelineDto::fromArray(['act' => $act]));

        if ($e) {
            return $this->errorResponse($e->getError());
        }

        return $this->itemResponse(
            ActResource::make($dto)->setIsFullView(true)
        );
    }

    public function all(AllByFiltersRequest $request, ActService $service): JsonResponse
    {
        Gate::authorize('canAllActs');

        $rows = $service->allByFilters($request->dto());

        return $this->listResponse(
            ActResource::collection($rows),
            new MetaItems($rows)
        );
    }

    public function delete(DeleteRequest $request, int $id): JsonResponse
    {
        Gate::authorize('canDeleteAct');

        $dto = $request->dto();
        $act = $dto->getAct();
        $act->setId($id);
        $dto->setAct($act);

        [$dto, $e] = $this->pipeline->deleteUnsignedAct($dto);

        if ($e) {
            return $this->errorResponse($e->getError());
        }

        return $this->noContentResponse();
    }

    public function export(ExportRequest $request): JsonResponse
    {
        Gate::authorize('canExportAct');

        [$dto, $e] = $this->pipeline->export($request->dto());

        if ($e) {
            return $this->errorResponse($e->getError());
        }

        return $this->noContentResponse();
    }

    public function signBySimpleSignature(
        SignBySimpleSignatureRequest $signRequest,
        AllByFiltersRequest          $filtersRequest
    ): JsonResponse
    {
        Gate::authorize('canAllActs');

        if (! auth()->user()->can(Permission::WRITE_DOCUMENT)) {
            //TODO: временное решение, поменять после PAYMENTS-812
            throw new AuthorizationException();
        }

        $signDataDto = $signRequest->dto();
        $signDataDto->setFilterDto($filtersRequest->dto());

        if ($filterAgentIds = $filtersRequest->dto()->getAgentId()) {
            $agentIds = array_intersect($signDataDto->getAgentIds(), $filterAgentIds);
            $signDataDto->setAgentIds($agentIds);
        }

        [$dto, $e] = $this->pipeline->signBySimpleSignature($signDataDto);

        if ($e) {
            return $this->errorResponse($e->getError());
        }

        return $this->noContentResponse();
    }

    public function signingInfo(SignatureDocumentsInfoRequest $request, ActService $service): JsonResponse
    {
        Gate::authorize('canViewDocumentsInfo');

        return $this->listResponse($service->signingInfo($request->dto()));
    }

    public function preview(PreviewRequest $request, int $id, ActService $actService): StreamedResponse
    {
        Gate::authorize('canPreviewActDocumentFile');

        $act = $request->dto();
        $act->setId($id);

        $act = $actService->get($act->toArray(), ['file']);

        if (! $path = $act?->getFile()?->getPath()) {
            throw new FileNotFoundException();
        }

        return Storage::disk('selectel')->download($path);
    }
}
