<?php

declare(strict_types=1);

namespace App\Http\Controllers\Api\V1\Company;

use App\Dto\Pipelines\Templates\GetTemplateListPipelineDto;
use App\Dto\Pipelines\Templates\GetTemplatePipelineDto;
use App\Http\Requests\Api\V1\Company\Templates\GetTemplateListByFilterRequest;
use App\Http\Requests\Api\V1\Company\Templates\CreateRequest;
use App\Http\Requests\Api\V1\Company\Templates\DeleteRequest;
use App\Http\Requests\Api\V1\Company\Templates\GetRequest;
use App\Http\Requests\Api\V1\Company\Templates\PreviewRequest;
use App\Http\Requests\Api\V1\Company\Templates\UpdateRequest;
use App\Http\Resources\V1\Templates\TemplateResource;
use App\Pipelines\V1\Templates\TemplatePipeline;
use App\Services\Act\TemplateService;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Gate;
use App\Exceptions\Pipelines\FileNotFoundException;
use Illuminate\Support\Facades\Storage;
use NoName\Framework\Http\Controllers\Api\ApiController;
use NoName\Framework\Response\MetaItems;
use Symfony\Component\HttpFoundation\StreamedResponse;

final class TemplatesController extends ApiController
{
    public function __construct(private TemplatePipeline $pipeline)
    {
    }

    public function create(CreateRequest $request): JsonResponse
    {
        Gate::authorize('canCreateTemplate');

        [$dto, $e] = $this->pipeline->create($request->dto());

        if ($e) {
            return $this->errorResponse($e->getError());
        }

        return $this->itemResponse(TemplateResource::make($dto));
    }

    public function get(GetRequest $request, int $id): JsonResponse
    {
        Gate::authorize('canGetTemplate');

        $template = $request->dto();
        $template->setId($id);

        [$dto, $e] = $this->pipeline->get(GetTemplatePipelineDto::fromArray(['template' => $template]));

        if ($e) {
            return $this->errorResponse($e->getError());
        }

        return $this->itemResponse(TemplateResource::make($dto));
    }

    public function list(GetTemplateListByFilterRequest $request): JsonResponse
    {
        Gate::authorize('canListTemplates');

        /** @var GetTemplateListPipelineDto $dto */
        [$dto, $e] = $this->pipeline->list(GetTemplateListPipelineDto::fromArray(['filter' => $request->dto()]));

        if ($e) {
            return $this->errorResponse($e->getError());
        }

        return $this->listResponse(
            TemplateResource::collection($dto->getItems()),
            new MetaItems($dto->getPaginator())
        );
    }

    public function update(UpdateRequest $request, int $id): JsonResponse
    {
        $dto = $request->dto();
        $template = $dto->getTemplate();
        $template->setId($id);
        $dto->setTemplate($template);

        [$dto, $e] = $this->pipeline->update($dto);

        if ($e) {
            return $this->errorResponse($e->getError());
        }

        return $this->itemResponse(TemplateResource::make($dto));
    }

    public function delete(DeleteRequest $request, int $id, TemplateService $templateService): JsonResponse
    {
        Gate::authorize('canDeleteTemplate');

        $template = $request->dto();
        $template->setId($id);

        $templateService->delete($template->toArray());

        return $this->noContentResponse();
    }

    public function preview(PreviewRequest $request, int $id, TemplateService $templateService): StreamedResponse
    {
        Gate::authorize('canGetTemplate');

        $template = $request->dto();
        $template->setId($id);

        $template = $templateService->get($template->toArray(), ['file']);

        if (!$path = $template?->getFile()?->getPath()) {
            throw new FileNotFoundException();
        }

        return Storage::disk('selectel')->download($path);
    }
}
