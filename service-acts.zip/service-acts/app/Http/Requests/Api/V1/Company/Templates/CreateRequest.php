<?php

declare(strict_types=1);

namespace App\Http\Requests\Api\V1\Company\Templates;

use App\Dto\Common\FileDataDto;
use App\Dto\Entities\Acts\TemplateDto;
use App\Dto\Pipelines\Templates\CreateTemplatePipelineDto;
use App\Enums\NoName\Templates\SignOrderEnum;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

final class CreateRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'name'                  => 'required|string|max:250',
            'agent_id'              => 'required|integer',
            'sign_order'            => ['required', Rule::in(SignOrderEnum::allValues())],
            'manager_contractor_id' => ['nullable', 'integer', Rule::requiredIf($this->input('sign_order') !== SignOrderEnum::EMPLOYEE_ONLY)],
            'file'                  => 'required|file|mimes:doc,docx|max:5120',
        ];
    }

    public function dto(): CreateTemplatePipelineDto
    {
        /** @var \NoName\ClientAuthJwt\Contracts\User $user */
        $user = auth()->user();

        $data = $this->only([
            'name',
            'agent_id',
            'sign_order',
            'manager_contractor_id',
        ]);

        $data['company_id'] = $user->getCompanyId();

        $file = $this->file('file');

        return CreateTemplatePipelineDto::fromArray([
            'template'  => TemplateDto::fromArray($data),
            'file_data' => FileDataDto::fromArray([
                'content'   => $file->getContent(),
                'extension' => $file->getClientOriginalExtension(),
                'path'      => $file->getPathname(),
            ]),
        ]);
    }
}
