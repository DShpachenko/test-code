<?php

declare(strict_types=1);

namespace App\Http\Requests\Api\V1\Company\Acts;

use App\Enums\NoName\Acts\TypeEnum;
use Illuminate\Validation\Rule;
use App\Enums\NoName\Acts\StatusEnum;
use Illuminate\Foundation\Http\FormRequest;
use App\Dto\Entities\Acts\ActAllByFiltersDto;

final class AllByFiltersRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'id'                     => 'array|nullable',
            'id.*  '                 => 'integer',
            'status'                 => [
                'string',
                Rule::in(StatusEnum::allValues()),
            ],
            'page'                   => [
                'int',
            ],
            'per_page'               => [
                'int',
                'min:5',
                'max:100',
            ],
            'employee_contractor_id' => [
                'int',
                'min:1',
            ],
            'name'                   => 'string|min:2',
            'period_from'            => 'date|date_format:Y-m-d|before:period_to',
            'period_to'              => 'date|date_format:Y-m-d|after:period_from',
            'agent_id'               => 'array|nullable',
            'agent_id.*'             => 'integer',
        ];
    }

    public function dto(): ActAllByFiltersDto
    {
        return ActAllByFiltersDto::fromArray([
            'id'                     => $this->get('id'),
            'type'                   => TypeEnum::JOB,
            'company_id'             => auth()->user()->getCompanyId(),
            'status'                 => $this->get('status'),
            'page'                   => $this->get('page') ? (int) $this->get('page') : null,
            'per_page'               => $this->get('per_page') ? (int) $this->get('per_page') : null,
            'employee_contractor_id' => $this->get('employee_contractor_id') ?
                (int) $this->get('employee_contractor_id') :
                null,
            'name'                   => $this->get('name'),
            'agent_id'               => $this->get('agent_id'),
            'period_from'            => $this->get('period_from'),
            'period_to'              => $this->get('period_to'),
        ]);
    }
}
