<?php

declare(strict_types=1);

namespace App\Http\Requests\Api\V1\Company\Acts;

use App\Dto\Entities\Acts\ActDto;
use Illuminate\Foundation\Http\FormRequest;

final class PreviewRequest extends FormRequest
{
    public function rules(): array
    {
        return [];
    }

    public function dto(): ActDto
    {
        return ActDto::fromArray([
            'company_id' => auth()->user()->getCompanyId(),
        ]);
    }
}
