<?php

declare(strict_types=1);

namespace App\Http\Requests\Api\V1\Company\Acts;

use App\Enums\NoName\Acts\TypeEnum;
use Illuminate\Validation\Rule;
use App\Dto\Entities\Acts\ExportDto;
use App\Enums\NoName\Acts\StatusEnum;
use Illuminate\Foundation\Http\FormRequest;

final class ExportRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'status'                 => [
                'string',
                Rule::in(StatusEnum::allValues()),
            ],
            'employee_contractor_id' => [
                'int',
                'min:1',
            ],
            'name'                   => 'string|min:2',
            'email'                  => 'required|email',
            'period_from'            => 'date|date_format:Y-m-d|before:period_to',
            'period_to'              => 'date|date_format:Y-m-d|after:period_from',
            'agent_id'               => 'array|nullable',
            'agent_id.*'             => 'integer',
        ];
    }

    public function dto(): ExportDto
    {
        /** @var \NoName\ClientAuthJwt\Dto\UserSet $user */
        $user = auth()->user();

        return ExportDto::fromArray([
            'author_id'  => $user->getId(),
            'company_id' => $user->getCompanyId(),
            'filters'    => [
                'type'                   => TypeEnum::JOB,
                'company_id'             => $user->getCompanyId(),
                'status'                 => $this->get('status'),
                'employee_contractor_id' => $this->get('employee_contractor_id') ?
                    (int) $this->get('employee_contractor_id') :
                    null,
                'name'                   => $this->get('name'),
                'agent_id'               => $this->get('agent_id'),
                'period_from'            => $this->get('period_from'),
                'period_to'              => $this->get('period_to'),
            ],
            'email'      => $this->get('email'),
        ]);
    }
}
