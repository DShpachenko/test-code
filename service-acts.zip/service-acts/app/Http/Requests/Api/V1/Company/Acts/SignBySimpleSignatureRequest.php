<?php

declare(strict_types=1);

namespace App\Http\Requests\Api\V1\Company\Acts;

use App\Dto\Entities\Acts\SignDataDto;
use App\Exceptions\Pipelines\LinkedContractorNotFoundException;
use Illuminate\Foundation\Http\FormRequest;
use NoName\ClientAuthJwt\Contracts\User;

final class SignBySimpleSignatureRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'crypto_session_id' => 'required|string|max:255',
        ];
    }

    /**
     * crypto_session_id - это id криптосессии ПЭП, которая создается этим методом https://noname
     * user_id - это всегда id контрактора (если исполнитель, то просто его id; если кастомер, то id исполнителя, связанного с ним jwtAuthUser()->getLinkedContractor()->getId()
     * user_type - customer или contractor
     *
     * @return SignDataDto
     */
    public function dto(): SignDataDto
    {
        /** @var User $user */
        $user = auth()->user();

        if (is_null($contractor = $user->getLinkedContractor())) {
            throw new LinkedContractorNotFoundException();
        }

        return SignDataDto::fromArray([
            'crypto_session_id' => $this->validated('crypto_session_id'),
            'company_id'        => $user->getCompanyId(),
            'agent_ids'         => $user->getAgentIds(),
            'user_id'           => $contractor->getId(),
            'user_type'         => $user->getType(),
        ]);
    }
}
