<?php

declare(strict_types=1);

namespace App\Http\Requests\Api\V1\Company\Templates;

use App\Dto\Entities\Acts\TemplateDto;
use Illuminate\Foundation\Http\FormRequest;

final class PreviewRequest extends FormRequest
{
    public function rules(): array
    {
        return [];
    }

    public function dto(): TemplateDto
    {
        return TemplateDto::fromArray([
            'company_id' => auth()->user()->getCompanyId(),
        ]);
    }
}
