<?php

declare(strict_types=1);

namespace App\Http\Requests\Api\V1\Company\JobTypes;

use App\Dto\Entities\Acts\JobTypeDto;
use Illuminate\Foundation\Http\FormRequest;

final class DeleteRequest extends FormRequest
{
    public function rules(): array
    {
        return [];
    }

    public function dto(): JobTypeDto
    {
        return JobTypeDto::fromArray([
            'company_id' => auth()->user()->getCompanyId(),
        ]);
    }
}
