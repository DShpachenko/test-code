<?php

declare(strict_types=1);

namespace App\Http\Requests\Api\V1\Company\Acts;

use Illuminate\Validation\Rule;
use App\Enums\NoName\Acts\StatusEnum;
use Illuminate\Foundation\Http\FormRequest;
use App\Dto\Entities\Acts\ActAllByFiltersDto;
use App\Exceptions\Pipelines\LinkedContractorNotFoundException;

final class SignatureDocumentsInfoRequest extends FormRequest
{
    public function rules(): array
    {
        //@todo возможно будет приведение status к массиву
        return [
            'id'                     => 'array|nullable',
            'id.*'                   => 'integer',
            'status'                 => [
                'string',
                Rule::in(StatusEnum::allValues()),
            ],
            'employee_contractor_id' => [
                'int',
                'min:1',
            ],
            'name'                   => 'string|min:2',
            'period_from'            => 'date|date_format:Y-m-d|before:period_to',
            'period_to'              => 'date|date_format:Y-m-d|after:period_from',
            'agent_id'               => 'array|nullable',
            'agent_id.*'             => 'integer',
        ];
    }

    public function dto(): ActAllByFiltersDto
    {
        /** @var \NoName\ClientAuthJwt\Dto\UserSet $user */
        $user = auth()->user();

        if (is_null($contractor = $user->getLinkedContractor())) {
            throw new LinkedContractorNotFoundException();
        }

        return ActAllByFiltersDto::fromArray([
            'id'                     => $this->get('id'),
            'company_id'             => $user->getCompanyId(),
            'status'                 => $this->get('status'),
            'employee_contractor_id' => $this->get('employee_contractor_id') ?
                (int) $this->get('employee_contractor_id') :
                null,
            'name'                   => $this->get('name'),
            'agent_id'               => $this->get('agent_id'),
            'period_from'            => $this->get('period_from'),
            'period_to'              => $this->get('period_to'),
            'manager_contractor_id'  => $contractor->getId(),
        ]);
    }
}
