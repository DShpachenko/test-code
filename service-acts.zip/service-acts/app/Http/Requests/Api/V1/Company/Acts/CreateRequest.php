<?php

declare(strict_types=1);

namespace App\Http\Requests\Api\V1\Company\Acts;

use Illuminate\Validation\Rule;
use App\Dto\Entities\Acts\ActDto;
use Illuminate\Foundation\Http\FormRequest;
use App\Enums\NoName\JobTypes\MeasureEnum;
use App\Dto\Pipelines\Acts\CreateActPipelineDto;

final class CreateRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'employee_contractor_id' => 'required|integer',
            'source_document_id'     => 'required|integer',
            'agent_id'               => 'required|integer',
            'name'                   => 'required|string|min:2',
            'description'            => 'string',
            'period_from'            => 'required|date|date_format:Y-m-d|before_or_equal:period_to',
            'period_to'              => 'required|date|date_format:Y-m-d|after_or_equal:period_from',
            'job_types.*.name'       => 'required|string|min:2|max:512',
            'job_types.*.price'      => 'required|regex:/^\d+(\.\d{1,2})?$/',
            'job_types.*.count'      => 'required|integer',
            'job_types.*.measure_id' => [
                'required',
                Rule::in(MeasureEnum::allValues()),
            ],
            'template_id'            => 'integer|nullable',
        ];
    }

    public function messages()
    {
        return [
            'job_types.*.name' => [
                'max' => trans('exceptions.44')
            ],
        ];
    }

    public function dto(): CreateActPipelineDto
    {
        /** @var \NoName\ClientAuthJwt\Dto\UserSet $user */
        $user = auth()->user();

        $data = $this->only([
            'employee_contractor_id',
            'source_document_id',
            'agent_id',
            'name',
            'description',
            'period_from',
            'period_to',
            'job_types',
            'template_id',
        ]);

        $data['author_id']             = $user->getId();
        $data['manager_contractor_id'] = $user->getLinkedContractor()?->getId();
        $data['company_id']            = $user->getCompanyId();

        return CreateActPipelineDto::fromArray([
            'act'       => ActDto::fromArray($data),
            'job_types' => $data['job_types'],
        ]);
    }
}
