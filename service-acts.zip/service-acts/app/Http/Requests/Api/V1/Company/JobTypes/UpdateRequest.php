<?php

declare(strict_types=1);

namespace App\Http\Requests\Api\V1\Company\JobTypes;

use Illuminate\Validation\Rule;
use App\Dto\Entities\Acts\JobTypeDto;
use Illuminate\Foundation\Http\FormRequest;
use App\Enums\NoName\JobTypes\MeasureEnum;

final class UpdateRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'name' => 'required|string|min:2',
            'price' => 'required|regex:/^\d+(\.\d{1,2})?$/',
            'measure_id' => [
                'required',
                Rule::in(MeasureEnum::allValues()),
            ],
        ];
    }

    public function dto(): JobTypeDto
    {
        $data = $this->only([
            'name',
            'price',
            'measure_id',
        ]);

        return JobTypeDto::fromArray([
            'company_id' => auth()->user()->getCompanyId(),
            'name' => $data['name'],
            'price' => (float)$data['price'],
            'measure_id' => $data['measure_id'],
        ]);
    }
}
