<?php

declare(strict_types=1);

namespace App\Http\Requests\Api\V1\Contractor\Acts;

use App\Dto\Entities\Acts\ActDto;
use App\Enums\NoName\Acts\TypeEnum;
use Illuminate\Foundation\Http\FormRequest;

final class CountRequest extends FormRequest
{
    public function rules(): array
    {
        return [];
    }

    public function dto(): ActDto
    {
        return ActDto::fromArray([
            'company_id' => auth()->user()->getCompanyId(),
            'employee_contractor_id' => auth()->user()->getLinkedContractor()->getId(),
            'type' => TypeEnum::JOB,
        ]);
    }
}
