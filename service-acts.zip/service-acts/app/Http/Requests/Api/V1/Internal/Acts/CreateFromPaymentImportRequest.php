<?php

declare(strict_types=1);

namespace App\Http\Requests\Api\V1\Internal\Acts;

use Illuminate\Validation\Rule;
use App\Dto\Entities\Acts\ActDto;
use App\Dto\Entities\Documents\DocumentDto;
use Illuminate\Foundation\Http\FormRequest;
use App\Enums\NoName\JobTypes\MeasureEnum;
use App\Dto\Pipelines\Acts\CreateActPipelineDto;

final class CreateFromPaymentImportRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'author_id'              => 'required|integer',
            'manager_contractor_id'  => 'required|integer',
            'employee_contractor_id' => 'required|integer',
            'company_id'             => 'required|integer',
            'agent_id'               => 'required|integer',
            'payment_id'             => 'required|integer',
            'document_number'        => 'required|string|max:25|min:1',
            'document_date'          => 'required|date|date_format:Y-m-d|before_or_equal:period_from',
            'name'                   => 'string|min:1|max:255',
            'description'            => 'string',
            'period_from'            => 'required|date|date_format:Y-m-d|before_or_equal:period_to',
            'period_to'              => 'required|date|date_format:Y-m-d|after_or_equal:period_from',
            'total_price'            => 'required|regex:/^\d+(\.\d{1,2})?$/',
            'job_types.*.name'       => 'required|string|min:2|max:512',
            'job_types.*.price'      => 'required|regex:/^\d+(\.\d{1,2})?$/',
            'job_types.*.count'      => 'required|integer',
            'job_types.*.measure_id' => [
                'required',
                Rule::in(MeasureEnum::allValues()),
            ],
            'template_id'            => 'integer|nullable',
        ];
    }

    public function dto(): CreateActPipelineDto
    {
        $data = $this->only([
            'author_id',
            'manager_contractor_id',
            'employee_contractor_id',
            'company_id',
            'agent_id',
            'payment_id',
            'document_number',
            'document_date',
            'name',
            'description',
            'period_from',
            'period_to',
            'job_types',
            'total_price',
            'template_id',
        ]);

        if ($data['template_id'] === 0) {
            $data['template_id'] = null;
        }

        return CreateActPipelineDto::fromArray([
            'act'       => ActDto::fromArray($data),
            'job_types' => $data['job_types'],
            'document'  => [
                'number' => $data['document_number'],
                'date' => $data['document_date'],
            ],
        ]);
    }
}
