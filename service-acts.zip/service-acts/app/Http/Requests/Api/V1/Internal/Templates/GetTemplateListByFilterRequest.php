<?php

declare(strict_types=1);

namespace App\Http\Requests\Api\V1\Internal\Templates;

use App\Dto\Entities\Acts\TemplateListByFilterDto;
use Illuminate\Foundation\Http\FormRequest;

final class GetTemplateListByFilterRequest extends FormRequest
{
    public function rules(): array
    {
        return [
            'company_id' => [
                'required',
                'int',
            ],
            'page'       => [
                'int',
            ],
            'per_page'   => [
                'int',
                'min:5',
                'max:100',
            ],
        ];
    }

    public function dto(): TemplateListByFilterDto
    {
        return TemplateListByFilterDto::fromArray([
            'company_id' => (int) $this->get('company_id'),
            'page'       => $this->get('page') ? (int) $this->get('page') : null,
            'per_page'   => $this->get('per_page') ? (int) $this->get('per_page') : null,
        ]);
    }
}
