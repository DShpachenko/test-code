<?php

declare(strict_types=1);

namespace App\Mail\Acts;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Contracts\Queue\ShouldQueue;

final class ActsExportCompletedNotificationEmail extends Mailable implements ShouldQueue
{
    use Queueable;

    public function __construct(public array $downloadArchiveFileUris) {
        $this->onConnection('database');
        $this->onQueue(config('queue.emails'));
    }

    public function build()
    {
        return $this->subject(__('mail.send_export_mail_title_done'))
                    ->view('emails.acts.exports.completed');
    }
}
