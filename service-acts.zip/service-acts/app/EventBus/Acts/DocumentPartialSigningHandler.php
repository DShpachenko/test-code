<?php

declare(strict_types=1);

namespace App\EventBus\Acts;

use NoName\EventBus\Contracts\Event;
use App\Jobs\Acts\CheckSignedDocumentJob;
use NoName\EventBus\Contracts\EventHandler;

final class DocumentPartialSigningHandler implements EventHandler
{
    public function handle(Event $event)
    {
        $eventData = $event->data();

        dispatch(new CheckSignedDocumentJob($eventData['id']));

        info('dispatch CheckSignedDocumentJob', $eventData);
    }
}
