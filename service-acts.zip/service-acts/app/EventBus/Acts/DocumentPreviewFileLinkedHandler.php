<?php

declare(strict_types=1);

namespace App\EventBus\Acts;

use App\Services\Act\ActService;
use NoName\EventBus\Contracts\Event;
use App\Jobs\Acts\DownloadDocumentFileJob;
use NoName\EventBus\Contracts\EventHandler;

final class DocumentPreviewFileLinkedHandler implements EventHandler
{
    public function __construct(private ActService $actService)
    {
    }

    public function handle(Event $event)
    {
        $eventData = $event->data();

        if ($act = $this->actService->get(['act_document_id' => $eventData['id']])) {
            dispatch(new DownloadDocumentFileJob($act->getId()));

            info('dispatch DownloadDocumentFileJob', $eventData);
        } else {
            info(trans('exceptions.8') . ' DocumentID: ' . $eventData['id']);
        }
    }
}
