<?php

declare(strict_types=1);

namespace App\Jobs\Acts;

use Illuminate\Bus\Queueable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use NoName\EventBusKafka\Event;

final class ActStatusDoneJob implements ShouldQueue
{
    use InteractsWithQueue;
    use Queueable;

    public function __construct(protected int $actId)
    {
        $this->onQueue(config('queue.act_status_update'));
        $this->onConnection('database');
    }

    public function handle(): void
    {
        event_bus(
            new Event('v1.acts', 'signed', [
                'act_id' => $this->actId,
            ])
        );
    }
}
