<?php

declare(strict_types=1);

namespace App\Jobs\Acts;

use App\Dto\Entities\Acts\ExportDto;
use App\Dto\Pipelines\Acts\ArchiveExportPipelineDto;
use App\Pipelines\V1\Acts\ActsPipeline;
use App\Services\Act\ExportService;
use Illuminate\Bus\Queueable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\File;

final class CreateExportArchiveJob implements ShouldQueue
{
    use InteractsWithQueue;
    use Queueable;

    public function __construct(protected int $exportId)
    {
        $this->onQueue(config('queue.create_export_archive'));
        $this->onConnection('database');
    }

    public function handle(
        ExportService $exportService,
        ActsPipeline  $pipeline
    ): void
    {
        $export = $exportService->getById($this->exportId);

        if (!$export) {
            return;
        }

        /** @var $dto ArchiveExportPipelineDto */
        [$dto, $e] = $pipeline->archiveExport(
            ArchiveExportPipelineDto::fromArray(['export' => $export->toArray()])
        );

        if ($e) {
            $this->deleteTmpDirectory($dto, $export);

            throw $e;
        }
    }

    private function deleteTmpDirectory(
        ArchiveExportPipelineDto $dto,
        ExportDto                $export
    ): void
    {
        $tmpDirectory = $dto->getTmpDirectoryPath() ??
            sprintf(
                "%s/exports/%s",
                sys_get_temp_dir(),
                $export->getId()
            );

        File::deleteDirectory($tmpDirectory);
    }
}
