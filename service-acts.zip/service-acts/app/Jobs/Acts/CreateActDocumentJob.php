<?php

declare(strict_types=1);

namespace App\Jobs\Acts;

use Illuminate\Bus\Queueable;
use App\Services\Act\ActService;
use App\Pipelines\V1\Acts\ActsPipeline;
use App\Enums\NoName\Acts\StatusEnum;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Dto\Pipelines\Acts\CreateActPipelineDto;

final class CreateActDocumentJob implements ShouldQueue
{
    use InteractsWithQueue;
    use Queueable;

    public function __construct(private int $actId)
    {
        $this->onQueue(config('queue.create_act_document'));
        $this->onConnection('database');
    }

    public function handle(ActService $actService, ActsPipeline $pipeline): void
    {
        if ($act = $actService->get([
            'id'     => $this->actId,
            'status' => StatusEnum::IN_PROCESSING,
        ])) {
            $actInfo = CreateActPipelineDto::fromArray($act->getInfo());
            $actInfo->setAct($act);

            [$dto, $e] = $pipeline->actGeneration($actInfo);

            if ($e) {
                throw $e;
            }
        }
    }
}
