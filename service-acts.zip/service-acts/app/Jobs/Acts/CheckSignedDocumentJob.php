<?php

declare(strict_types=1);

namespace App\Jobs\Acts;

use Illuminate\Bus\Queueable;
use App\Dto\Entities\Acts\ActDto;
use App\Pipelines\V1\Acts\ActsPipeline;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Dto\Pipelines\Acts\CheckSignedDocumentPipelineDto;

final class CheckSignedDocumentJob implements ShouldQueue
{
    use InteractsWithQueue;
    use Queueable;

    public function __construct(protected int $documentId)
    {
        $this->onQueue(config('queue.signed_document'));
        $this->onConnection('database');
    }

    public function handle(ActsPipeline $pipeline): void
    {
        info('run CheckSignedDocumentJob', ['act_document_id' => $this->documentId]);

        try {
            /** @var CheckSignedDocumentPipelineDto $dto */
            [$dto, $e] = $pipeline->checkSignedDocument(CheckSignedDocumentPipelineDto::fromArray([
                'act' => ActDto::fromArray([
                    'act_document_id' => $this->documentId,
                ])
            ]));

            if ($dto->getAct()) {
                info('success CheckSignedDocumentJob', ['act_document_id' => $this->documentId]);
            } else {
                info('error CheckSignedDocumentJob: Act not found', ['act_document_id' => $this->documentId]);
            }
        } catch (\Exception $e) {
            info('error CheckSignedDocumentJob: ' . $e->getMessage(), ['act_document_id' => $this->documentId]);
        }
    }
}
