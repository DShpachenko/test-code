<?php

declare(strict_types=1);

namespace App\Jobs\Acts;

use Illuminate\Bus\Queueable;
use App\Dto\Entities\Acts\ActDto;
use App\Pipelines\V1\Acts\ActsPipeline;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Dto\Pipelines\Acts\DownloadDocumentFilePipelineDto;

final class DownloadDocumentFileJob implements ShouldQueue
{
    use InteractsWithQueue;
    use Queueable;

    public function __construct(private int $actId)
    {
        $this->onQueue(config('queue.download_document_file'));
        $this->onConnection('database');
    }

    public function handle(ActsPipeline $pipeline): void
    {
        [$dto, $e] = $pipeline->downloadDocumentFile(DownloadDocumentFilePipelineDto::fromArray([
            'act' => ActDto::fromArray(['id' => $this->actId]),
        ]));

        if ($e) {
            throw $e;
        }
    }
}
