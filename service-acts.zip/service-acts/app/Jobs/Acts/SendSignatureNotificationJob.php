<?php

declare(strict_types=1);

namespace App\Jobs\Acts;

use Illuminate\Bus\Queueable;
use NoName\ClientPusher\Push;
use NoName\ClientPusher\User;
use NoName\ClientPusher\Notification;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Dto\Entities\Acts\SignNotificationDto;
use NoName\ClientPusher\Contracts\PusherClient;

final class SendSignatureNotificationJob implements ShouldQueue
{
    use InteractsWithQueue;
    use Queueable;

    public function __construct(protected SignNotificationDto $signNotificationDto)
    {
        $this->onQueue(config('queue.sign_signature_notification'));
        $this->onConnection('database');
    }

    public function handle(PusherClient $client): void
    {
        $client->send(
            new Push(
                User::makeContractor($this->signNotificationDto->getContractorId()),
                (new Notification())
                    ->setTitle(__('act.sign_signature_notification_message_title'))
                    ->setBody(__('act.sign_signature_notification_message_body')),
                [
                    'click_action' => 'no-name://acts?group=pending_employee_signature',
                    'act_id'       => $this->signNotificationDto->getActId(),
                ]
            )
        );
    }
}
