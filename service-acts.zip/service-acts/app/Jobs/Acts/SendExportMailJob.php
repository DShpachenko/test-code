<?php

declare(strict_types=1);

namespace App\Jobs\Acts;

use Illuminate\Bus\Queueable;
use App\Dto\Entities\Acts\ExportDto;
use App\Pipelines\V1\Acts\ActsPipeline;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;

final class SendExportMailJob implements ShouldQueue
{
    use InteractsWithQueue;
    use Queueable;

    public function __construct(private int $exportId)
    {
        $this->onQueue(config('queue.send_export_mail'));
        $this->onConnection('database');
    }

    public function handle(ActsPipeline $pipeline): void
    {
        [$dto, $e] = $pipeline->sendExportMail(ExportDto::fromArray(['id' => $this->exportId]));

        if ($e) {
            throw $e;
        }
    }
}
