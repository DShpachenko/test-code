<?php

declare(strict_types=1);

namespace App\Jobs\Acts;

use App\Dto\DtoInterface;
use App\Dto\Entities\Acts\ActAllByFiltersDto;
use App\Dto\Entities\Acts\SignDataDto;
use App\Repositories\Act\Act\ActRepositoryInterface;
use App\Repositories\Document\Document\DocumentRepositoryInterface;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Support\Str;
use NoName\ClientDocuments\Exceptions\WrongResponseException;

final class SendToSigningActsJob implements ShouldQueue
{
    use InteractsWithQueue;
    use Queueable;

    public function __construct(protected DtoInterface|SignDataDto $dto)
    {
        $this->onQueue(config('queue.signing'));
        $this->onConnection('database');
    }

    public function handle(
        DocumentRepositoryInterface $httpDocumentsRepository,
        ActRepositoryInterface      $actRepository
    ): void
    {
        $documentIds = $actRepository->listByFilters(ActAllByFiltersDto::fromArray([
            'id'         => $this->dto->getActIds(),
            'company_id' => $this->dto->getCompanyId(),
        ]))->pluck('act_document_id')->toArray();

        $logData = array_merge($this->dto->toArray(), [
            'crypto_session_id' => Str::limit($this->dto->getCryptoSessionId() ?? '', 10),
            'document_ids'      => $documentIds,
        ]);
        info('run SendToSigningActsJob', $logData);

        $this->dto->setPreparedFilter([
            'id'             => join(',', $documentIds),
            'agent_id'       => join(',', $this->dto->getAgentIds()),
            'with_invisible' => true,
        ]);

        try {
            $documentSignRequest = $httpDocumentsRepository->createSignRequestBySimpleSignature($this->dto);
            info('result SendToSigningActsJob', array_merge($logData, [
                'document_sig_request_id' => $documentSignRequest->id(),
            ]));
        } catch (WrongResponseException $e) {
            preg_match('/status:\s?(\d{3})/', $e->getMessage(), $matches);
            $responseCode = (int) ($matches[1] ?? 0);
            info('error SendToSigningActsJob', array_merge($logData, [
                'exception' => [
                    'code'    => $responseCode,
                    'message' => Str::limit($e->getMessage(), 1000),
                ],
            ]));

            if ($responseCode > 500) {
                throw $e;
            }
        }
    }
}
