<?php

declare(strict_types=1);

namespace App\Pipelines;

use Exception;
use Throwable;
use App\Dto\DtoInterface;
use App\Exceptions\Handler;
use Illuminate\Pipeline\Pipeline;
use Illuminate\Support\Facades\DB;
use App\Exceptions\BusinessExceptionInterface;
use Symfony\Component\HttpFoundation\Response;
use App\Exceptions\Pipelines\PipelineException;
use NoName\Framework\Contracts\ExceptionErrorable;

abstract class AbstractPipeline
{
    public function __construct(protected Pipeline $pipeline)
    {
    }

    protected function pipeline(array $pipes, DtoInterface $dto): array
    {
        $exception = false;

        try {
            $dto = DB::transaction(function () use ($pipes, $dto) {
                return $this->pipeline
                    ->send($dto)
                    ->through($pipes)
                    ->then(function (DtoInterface $newDto) {
                        return $newDto;
                    });
            });
        } catch (Exception $e) {
            /** @var Handler $exceptionHandler */
            $exceptionHandler = app(Handler::class);

            if ($e instanceof BusinessExceptionInterface) {
                $exceptionHandler->reportWithoutBusinessExceptions($e);
            } else {
                $exceptionHandler->report($e);
            }

            $exception = $this->prepareException($e);
        }

        return [$dto, $exception];
    }

    private function prepareException(Exception $e): PipelineException|Exception|Throwable|ExceptionErrorable
    {
        if (! ($e instanceof ExceptionErrorable)) {
            /**
             * Обработка ошибок на уровне БД, когда возвращается код ошибки от БД
             * в формате строки
             */
            $code = (is_int($e->getCode()) && $e->getCode() !== 0) ? $e->getCode() : Response::HTTP_NOT_FOUND;

            return new PipelineException($e->getMessage(), $code);
        }

        return $e;
    }
}
