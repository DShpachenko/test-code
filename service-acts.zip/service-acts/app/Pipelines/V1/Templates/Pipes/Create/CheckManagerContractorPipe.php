<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Templates\Pipes\Create;

use App\Dto\DtoInterface;
use App\Dto\Pipelines\Templates\CreateTemplatePipelineDto;
use App\Enums\NoName\Templates\SignOrderEnum;
use App\Exceptions\Pipelines\AlienContractorException;
use App\Exceptions\Pipelines\ManagerContractorException;
use App\Exceptions\Pipelines\RequiredFieldMissingException;
use App\Pipelines\PipeInterface;
use App\Services\Taxi\ContractorService;
use Closure;

final class CheckManagerContractorPipe implements PipeInterface
{
    public function __construct(private ContractorService $service)
    {
    }

    public function handle(DtoInterface|CreateTemplatePipelineDto $dto, Closure $next): DtoInterface
    {
        $template = $dto->getTemplate();

        if ($template->getSignOrder() === SignOrderEnum::EMPLOYEE_ONLY) {
            $template->setManagerContractorId(null);
            $dto->setManagerContractor(null);

            return $next($dto);
        }

        if (is_null($template->getManagerContractorId())) {
            throw new RequiredFieldMissingException(trans('exceptions.26'));
        }

        if (! $contractor = $this->service->get(['id' => $template->getManagerContractorId()])) {
            throw new ManagerContractorException();
        }

        if ($template->getCompanyId() !== $contractor->getCompanyId()) {
            throw new AlienContractorException();
        }

        //if ($template->getAgentId() !== $contractor->getAgentId()) {
        //    throw new ManagerContractorException(trans('exceptions.23'));
        //}

        $dto->setManagerContractor($contractor);

        return $next($dto);
    }
}
