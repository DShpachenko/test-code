<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Templates\Pipes\Create;

use App\Dto\DtoInterface;
use App\Dto\Entities\Acts\TemplateFileDto;
use App\Dto\Pipelines\Templates\CreateTemplatePipelineDto;
use App\Exceptions\Pipelines\RequiredFieldMissingException;
use App\Pipelines\PipeInterface;
use App\Services\Act\TemplateFileService;
use Closure;
use Illuminate\Support\Carbon;

final class CreateTemplateFilePipe implements PipeInterface
{
    public function __construct(private TemplateFileService $templateFileService)
    {
    }

    public function handle(DtoInterface|CreateTemplatePipelineDto $dto, Closure $next): DtoInterface
    {
        $templateId    = $dto->getTemplate()?->getId();
        $storageFileId = $dto->getStorageFile()?->getId();

        if (is_null($templateId)) {
            throw new RequiredFieldMissingException(trans('exceptions.27'));
        }

        if (is_null($storageFileId)) {
            throw new RequiredFieldMissingException(trans('exceptions.28'));
        }

        $this->templateFileService->delete(['template_id' => $templateId]);

        $this->templateFileService->create(TemplateFileDto::fromArray([
            'template_id' => $templateId,
            'file_id'     => $storageFileId,
            'created_at'  => Carbon::now()->format('Y-m-d H:i:s'),
        ]));

        return $next($dto);
    }
}
