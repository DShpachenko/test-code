<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Templates\Pipes\Create;

use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use NoName\TemplateProcessor\Facades\Templates;
use App\Exceptions\Pipelines\TemplateVariablesException;
use App\Dto\Pipelines\Templates\CreateTemplatePipelineDto;

final class CheckTemplateVariablesPipe implements PipeInterface
{
    public function handle(DtoInterface|CreateTemplatePipelineDto $dto, Closure $next): DtoInterface
    {
        $templateVariables = Templates::newDocxTemplate($dto->getFileData()->getPath())->getVariables();

        if (count($templateVariables) === 0) {
            throw new TemplateVariablesException(trans('exceptions.41'));
        }

        if (
            !in_array('cell1', $templateVariables) ||
            !in_array('cell2', $templateVariables) ||
            //!in_array('cell3', $templateVariables) ||
            !in_array('cell4', $templateVariables) ||
            !in_array('cell5', $templateVariables)
            //!in_array('cell6', $templateVariables)
        ) {
            throw new TemplateVariablesException();
        }

        return $next($dto);
    }
}
