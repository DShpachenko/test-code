<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Templates\Pipes\Create;

use App\Dto\DtoInterface;
use App\Dto\Pipelines\Templates\CreateTemplatePipelineDto;
use App\Exceptions\Pipelines\AlienAgentException;
use App\Exceptions\Pipelines\RequiredFieldMissingException;
use App\Pipelines\PipeInterface;
use App\Services\Taxi\AgentService;
use Closure;

final class CheckAgentPipe implements PipeInterface
{
    public function __construct(private AgentService $service)
    {
    }

    public function handle(DtoInterface|CreateTemplatePipelineDto $dto, Closure $next): DtoInterface
    {
        $template = $dto->getTemplate();

        if (is_null($template->getAgentId())) {
            throw new RequiredFieldMissingException(trans('exceptions.25'));
        }

        $agent = $this->service->get(['id' => $template->getAgentId()]);

        if (is_null($agent) || $template->getCompanyId() !== $agent->getCompanyId()) {
            throw new AlienAgentException();
        }

        $dto->setAgent($agent);

        return $next($dto);
    }
}
