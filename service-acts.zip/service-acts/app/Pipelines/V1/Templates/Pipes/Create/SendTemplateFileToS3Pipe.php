<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Templates\Pipes\Create;

use App\Dto\DtoInterface;
use App\Dto\Entities\Storage\FileDto;
use App\Dto\Pipelines\Templates\CreateTemplatePipelineDto;
use App\Enums\NoName\Storage\File\TypeEnum;
use App\Exceptions\Pipelines\RequiredFieldMissingException;
use App\Exceptions\Pipelines\SendFileToS3Exception;
use App\Helpers\FileHelper;
use App\Pipelines\PipeInterface;
use App\Services\Storage\FileService;
use Closure;
use Illuminate\Support\Facades\Storage;

final class SendTemplateFileToS3Pipe implements PipeInterface
{
    public function __construct(private FileService $fileService)
    {
    }

    public function handle(DtoInterface|CreateTemplatePipelineDto $dto, Closure $next): DtoInterface
    {
        if (is_null($fileData = $dto->getFileData())) {
            throw new RequiredFieldMissingException('exceptions.30');
        }

        $path = FileHelper::generateFilePath(
            $fileData->getContent(),
            $fileData->getExtension(),
            TypeEnum::ACT_TEMPLATE
        );

        if (! Storage::disk('selectel')->put($path, $fileData->getContent())) {
            throw new SendFileToS3Exception();
        }

        $dto->setStorageFile($this->fileService->create(FileDto::fromArray([
            'type' => TypeEnum::ACT_TEMPLATE,
            'path' => $path,
        ])));

        return $next($dto);
    }
}
