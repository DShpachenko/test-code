<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Templates\Pipes\Create;

use App\Dto\DtoInterface;
use App\Dto\Pipelines\Templates\CreateTemplatePipelineDto;
use App\Enums\NoName\Templates\SignOrderEnum;
use App\Exceptions\Pipelines\InvalidTemplateDataException;
use App\Exceptions\Pipelines\RequiredFieldMissingException;
use App\Pipelines\PipeInterface;
use App\Services\Act\TemplateService;
use Closure;

final class CreateTemplatePipe implements PipeInterface
{
    public function __construct(private TemplateService $service)
    {
    }

    public function handle(DtoInterface|CreateTemplatePipelineDto $dto, Closure $next): DtoInterface
    {
        if (is_null($template = $dto->getTemplate())) {
            throw new RequiredFieldMissingException(trans('exceptions.29'));
        }

        if (! in_array($template->getSignOrder(), SignOrderEnum::allValues())) {
            throw new InvalidTemplateDataException(trans('exceptions.32'));
        }

        if (empty($template->getName())) {
            throw new InvalidTemplateDataException(trans('exceptions.33'));
        }

        $dto->setTemplate($this->service->create($template));

        return $next($dto);
    }
}
