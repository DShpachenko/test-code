<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Templates\Pipes\Get;

use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use App\Services\Taxi\ContractorService;
use App\Dto\Pipelines\Templates\GetTemplatePipelineDto;

final class ManagerContractorPipe implements PipeInterface
{
    public function __construct(private ContractorService $service)
    {
    }

    public function handle(DtoInterface|GetTemplatePipelineDto $dto, Closure $next): DtoInterface
    {
        if ($managerContractorId = $dto->getTemplate()->getManagerContractorId()) {
            $dto->setManagerContractor($this->service->get(['id' => $managerContractorId]));
        }

        return $next($dto);
    }
}
