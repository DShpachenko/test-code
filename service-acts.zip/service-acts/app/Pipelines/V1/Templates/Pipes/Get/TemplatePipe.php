<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Templates\Pipes\Get;

use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use App\Services\Act\TemplateService;
use App\Exceptions\Pipelines\ObjectNotFoundException;
use App\Dto\Pipelines\Templates\GetTemplatePipelineDto;

final class TemplatePipe implements PipeInterface
{
    public function __construct(private TemplateService $service)
    {
    }

    public function handle(DtoInterface|GetTemplatePipelineDto $dto, Closure $next): DtoInterface
    {
        if (!$template = $this->service->get($dto->getTemplate()->toArray())) {
            throw new ObjectNotFoundException();
        }

        $dto->setTemplate($template);

        return $next($dto);
    }
}
