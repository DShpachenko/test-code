<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Templates\Pipes\Get;

use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use App\Services\Taxi\AgentService;
use App\Dto\Pipelines\Templates\GetTemplatePipelineDto;

final class AgentPipe implements PipeInterface
{
    public function __construct(private AgentService $service)
    {
    }

    public function handle(DtoInterface|GetTemplatePipelineDto $dto, Closure $next): DtoInterface
    {
        $dto->setAgent($this->service->get(['id' => $dto->getTemplate()->getAgentId()]));

        return $next($dto);
    }
}
