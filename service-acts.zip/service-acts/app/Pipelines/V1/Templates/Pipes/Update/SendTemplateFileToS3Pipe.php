<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Templates\Pipes\Update;

use Closure;
use App\Dto\DtoInterface;
use App\Helpers\FileHelper;
use App\Pipelines\PipeInterface;
use App\Dto\Entities\Storage\FileDto;
use App\Services\Storage\FileService;
use Illuminate\Support\Facades\Storage;
use App\Enums\NoName\Storage\File\TypeEnum;
use App\Exceptions\Pipelines\SendFileToS3Exception;
use App\Dto\Pipelines\Templates\CreateTemplatePipelineDto;

final class SendTemplateFileToS3Pipe implements PipeInterface
{
    public function __construct(private FileService $fileService)
    {
    }

    public function handle(DtoInterface|CreateTemplatePipelineDto $dto, Closure $next): DtoInterface
    {
        if ($fileData = $dto->getFileData()) {
            $path = FileHelper::generateFilePath(
                $fileData->getContent(),
                $fileData->getExtension(),
                TypeEnum::ACT_TEMPLATE
            );

            if (! Storage::disk('selectel')->put($path, $fileData->getContent())) {
                throw new SendFileToS3Exception();
            }

            $dto->setStorageFile($this->fileService->create(FileDto::fromArray([
                'type' => TypeEnum::ACT_TEMPLATE,
                'path' => $path,
            ])));
        }

        return $next($dto);
    }
}
