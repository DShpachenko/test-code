<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Templates\Pipes\Update;

use Closure;
use App\Dto\DtoInterface;
use Illuminate\Support\Carbon;
use App\Pipelines\PipeInterface;
use App\Services\Act\TemplateFileService;
use App\Dto\Entities\Acts\TemplateFileDto;
use App\Dto\Pipelines\Templates\CreateTemplatePipelineDto;

final class TemplateFilePipe implements PipeInterface
{
    public function __construct(private TemplateFileService $templateFileService)
    {
    }

    public function handle(DtoInterface|CreateTemplatePipelineDto $dto, Closure $next): DtoInterface
    {
        if ($storageFileDto = $dto->getStorageFile()) {
            $templateId    = $dto->getTemplate()->getId();
            $storageFileId = $storageFileDto->getId();

            $this->templateFileService->delete(['template_id' => $templateId]);

            $this->templateFileService->create(TemplateFileDto::fromArray([
                'template_id' => $templateId,
                'file_id'     => $storageFileId,
                'created_at'  => Carbon::now()->format('Y-m-d H:i:s'),
            ]));
        }

        return $next($dto);
    }
}
