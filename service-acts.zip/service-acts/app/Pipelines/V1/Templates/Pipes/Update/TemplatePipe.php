<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Templates\Pipes\Update;

use App\Exceptions\Pipelines\ObjectNotFoundException;
use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use App\Services\Act\TemplateService;
use App\Enums\NoName\Templates\SignOrderEnum;
use App\Dto\Pipelines\Templates\CreateTemplatePipelineDto;
use App\Exceptions\Pipelines\InvalidTemplateDataException;
use App\Exceptions\Pipelines\RequiredFieldMissingException;

final class TemplatePipe implements PipeInterface
{
    public function __construct(private TemplateService $service)
    {
    }

    public function handle(DtoInterface|CreateTemplatePipelineDto $dto, Closure $next): DtoInterface
    {
        if (is_null($template = $dto->getTemplate())) {
            throw new RequiredFieldMissingException(trans('exceptions.29'));
        }

        if (! in_array($template->getSignOrder(), SignOrderEnum::allValues())) {
            throw new InvalidTemplateDataException(trans('exceptions.32'));
        }

        if (empty($template->getName())) {
            throw new InvalidTemplateDataException(trans('exceptions.33'));
        }

        if ($this->checkForEmptyData($dto)) {
            throw new InvalidTemplateDataException(trans('exceptions.35'));
        }

        if (!$this->service->get([
            'id'         => $template->getId(),
            'company_id' => $template->getCompanyId(),
        ])) {
            throw new ObjectNotFoundException();
        }

        $this->service->update([
            'id'         => $template->getId(),
            'company_id' => $template->getCompanyId(),
        ], [
            'name'                  => $template->getName(),
            'agent_id'              => $template->getAgentId(),
            'sign_order'            => $template->getSignOrder(),
            'manager_contractor_id' => $template->getManagerContractorId(),
        ]);

        return $next($dto);
    }

    private function checkForEmptyData(CreateTemplatePipelineDto $dto): bool
    {
        $template = $dto->getTemplate();

        if (
            !$template->getName() &&
            !$template->getAgentId() &&
            !$template->getSignOrder() &&
            !$template->getManagerContractorId() &&
            !$dto->getFileData()
        ) {
            return true;
        }

        return false;
    }
}
