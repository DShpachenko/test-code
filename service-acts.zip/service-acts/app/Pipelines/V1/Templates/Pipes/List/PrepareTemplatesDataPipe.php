<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Templates\Pipes\List;

use App\Dto\DtoInterface;
use App\Dto\Entities\Acts\TemplateDto;
use App\Dto\Entities\Taxi\AgentDto;
use App\Dto\Entities\Taxi\ContractorDto;
use App\Dto\Pipelines\Templates\GetTemplateListPipelineDto;
use App\Dto\Pipelines\Templates\GetTemplatePipelineDto;
use App\Exceptions\Pipelines\RequiredFieldMissingException;
use App\Models\Acts\Template;
use App\Pipelines\PipeInterface;
use Closure;
use NoName\ClientAgents\Facades\Agents;
use NoName\ClientContractors\Facades\Contractors;

final class PrepareTemplatesDataPipe implements PipeInterface
{
    public function handle(DtoInterface|GetTemplateListPipelineDto $dto, Closure $next): DtoInterface
    {
        if (is_null($paginator = $dto->getPaginator())) {
            throw new RequiredFieldMissingException(trans('exceptions.36'));
        }

        $templates = $paginator->items();

        $agentIds             = [];
        $managerContractorIds = [];

        foreach ($templates as $template) {
            $agentIds[] = $template->agent_id;
            if (isset($template->manager_contractor_id)) {
                $managerContractorIds[] = $template->manager_contractor_id;
            }
        }

        Agents::prefetch(array_unique($agentIds));
        Contractors::prefetch(array_unique($managerContractorIds));

        $preparedItems = array_map(
            function (Template $row) {
                $agent             = Agents::getById($row->agent_id);
                $managerContractor = $row->manager_contractor_id ? Contractors::getById($row->manager_contractor_id) : null;

                return GetTemplatePipelineDto::fromArray([
                    'template'           => TemplateDto::fromArray($row->toArray()),
                    'agent'              => AgentDto::fromArray([
                        'id'         => $agent->id(),
                        'company_id' => $agent->companyId(),
                        'name'       => $agent->name(),
                    ]),
                    'manager_contractor' => $managerContractor ? ContractorDto::fromArray([
                        'id'          => $managerContractor->id(),
                        'company_id'  => $managerContractor->companyId(),
                        'agent_id'    => $managerContractor->agentId(),
                        'last_name'   => $managerContractor->lastName(),
                        'first_name'  => $managerContractor->firstName(),
                        'middle_name' => $managerContractor->middleName(),
                    ]) : null,
                ]);
            },
            $templates
        );

        $dto->setItems($preparedItems);

        return $next($dto);
    }
}
