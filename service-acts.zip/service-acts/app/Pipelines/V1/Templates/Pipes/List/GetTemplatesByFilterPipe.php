<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Templates\Pipes\List;

use App\Dto\DtoInterface;
use App\Dto\Pipelines\Templates\GetTemplateListPipelineDto;
use App\Pipelines\PipeInterface;
use App\Services\Act\TemplateService;
use Closure;

final class GetTemplatesByFilterPipe implements PipeInterface
{
    public function __construct(private TemplateService $service)
    {
    }

    public function handle(DtoInterface|GetTemplateListPipelineDto $dto, Closure $next): DtoInterface
    {
        $paginator = $this->service->list($dto->getFilter());

        $dto->setPaginator($paginator);

        return $next($dto);
    }
}
