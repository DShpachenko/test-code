<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Templates;

use App\Dto\Pipelines\Templates\CreateTemplatePipelineDto;
use App\Dto\Pipelines\Templates\GetTemplateListPipelineDto;
use App\Dto\Pipelines\Templates\GetTemplatePipelineDto;
use App\Pipelines\AbstractPipeline;
use App\Pipelines\V1\Templates\Pipes\Create\CheckTemplateVariablesPipe;
use App\Pipelines\V1\Templates\Pipes\List\GetTemplatesByFilterPipe;
use App\Pipelines\V1\Templates\Pipes\List\PrepareTemplatesDataPipe;
use App\Pipelines\V1\Templates\Pipes\Create\CreateTemplateFilePipe;
use App\Pipelines\V1\Templates\Pipes\Create\CreateTemplatePipe;
use App\Pipelines\V1\Templates\Pipes\Create\CheckAgentPipe;
use App\Pipelines\V1\Templates\Pipes\Create\CheckManagerContractorPipe;
use App\Pipelines\V1\Templates\Pipes\Create\SendTemplateFileToS3Pipe;
use App\Pipelines\V1\Templates\Pipes\Get\AgentPipe as GetAgentPipe;
use App\Pipelines\V1\Templates\Pipes\Get\ManagerContractorPipe as GetManagerContractorPipe;
use App\Pipelines\V1\Templates\Pipes\Get\TemplatePipe as GetTemplatePipe;
use App\Pipelines\V1\Templates\Pipes\Update\TemplatePipe as UpdateTemplatePipe;
use App\Pipelines\V1\Templates\Pipes\Update\SendTemplateFileToS3Pipe as UpdateSendTemplateFileToS3Pipe;
use App\Pipelines\V1\Templates\Pipes\Update\TemplateFilePipe as UpdateTemplateFilePipe;

final class TemplatePipeline extends AbstractPipeline
{
    public function create(CreateTemplatePipelineDto $dto): array
    {
        return $this->pipeline([
            CheckAgentPipe::class,
            CheckManagerContractorPipe::class,
            CheckTemplateVariablesPipe::class,
            CreateTemplatePipe::class,
            SendTemplateFileToS3Pipe::class,
            CreateTemplateFilePipe::class,
        ], $dto);
    }

    public function get(GetTemplatePipelineDto $dto): array
    {
        return $this->pipeline([
            GetTemplatePipe::class,
            GetAgentPipe::class,
            GetManagerContractorPipe::class,
        ], $dto);
    }

    public function list(GetTemplateListPipelineDto $dto): array
    {
        return $this->pipeline([
            GetTemplatesByFilterPipe::class,
            PrepareTemplatesDataPipe::class,
        ], $dto);
    }

    public function update(CreateTemplatePipelineDto $dto): array
    {
        return $this->pipeline([
            CheckAgentPipe::class,
            CheckManagerContractorPipe::class,
            CheckTemplateVariablesPipe::class,
            UpdateTemplatePipe::class,
            UpdateSendTemplateFileToS3Pipe::class,
            UpdateTemplateFilePipe::class,
        ], $dto);
    }
}
