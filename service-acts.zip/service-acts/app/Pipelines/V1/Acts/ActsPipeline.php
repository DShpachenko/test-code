<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts;

use App\Dto\Entities\Acts\ActDto;
use App\Dto\Entities\Acts\ExportDto;
use App\Dto\Entities\Acts\SignDataDto;
use App\Dto\Pipelines\Acts\ArchiveExportPipelineDto;
use App\Dto\Pipelines\Acts\CheckSignedDocumentPipelineDto;
use App\Dto\Pipelines\Acts\CreateActPipelineDto;
use App\Dto\Pipelines\Acts\DeleteActPipelineDto;
use App\Dto\Pipelines\Acts\DownloadDocumentFilePipelineDto;
use App\Dto\Pipelines\Acts\GetActPipelineDto;
use App\Enums\NoName\Exports\TypeEnum;
use App\Pipelines\AbstractPipeline;
use App\Pipelines\V1\Acts\Pipes\ActGeneration\ActJobTypePipe as ActGenerationActJobTypePipe;
use App\Pipelines\V1\Acts\Pipes\ActGeneration\ActPipe as ActGenerationActPipe;
use App\Pipelines\V1\Acts\Pipes\ActGeneration\TemplatePipe as ActGenerationTemplatePipe;
use App\Pipelines\V1\Acts\Pipes\ActGeneration\CustomerPipe as ActGenerationCustomerPipe;
use App\Pipelines\V1\Acts\Pipes\ActGeneration\DocumentPipe as ActGenerationDocumentPipe;
use App\Pipelines\V1\Acts\Pipes\ArchiveExport\CreateArchivesPipe;
use App\Pipelines\V1\Acts\Pipes\ArchiveExport\CreateExportFilesPipe;
use App\Pipelines\V1\Acts\Pipes\ArchiveExport\CreateFilesPipe;
use App\Pipelines\V1\Acts\Pipes\ArchiveExport\DeleteTemporaryFilesPipe;
use App\Pipelines\V1\Acts\Pipes\ArchiveExport\DownloadActsFromS3Pipe;
use App\Pipelines\V1\Acts\Pipes\ArchiveExport\SendArchivesToS3Pipe;
use App\Pipelines\V1\Acts\Pipes\CancelProcessingSignature\ChangeActStatusPipe;
use App\Pipelines\V1\Acts\Pipes\CheckSignedDocument\CheckActPipe as CheckSignedDocumentCheckActPipe;
use App\Pipelines\V1\Acts\Pipes\CheckSignedDocument\CheckSignaturePipe as CheckSignedDocumentCheckSignaturePipe;
use App\Pipelines\V1\Acts\Pipes\Create\ActJobTypePipe as CreateActJobTypePipe;
use App\Pipelines\V1\Acts\Pipes\Create\ActSignaturePipe as CreateActSignaturePipe;
use App\Pipelines\V1\Acts\Pipes\Create\ActPipe as CreateActPipe;
use App\Pipelines\V1\Acts\Pipes\Create\CheckAgentPipe as CreateCheckAgentPipe;
use App\Pipelines\V1\Acts\Pipes\Create\CheckManagerContractorPipe as CreateCheckManagerContractorPipe;
use App\Pipelines\V1\Acts\Pipes\Create\TemplatePipe as CreateTemplatePipe;
use App\Pipelines\V1\Acts\Pipes\Create\CheckContractorPipe as CreateCheckContractorPipe;
use App\Pipelines\V1\Acts\Pipes\Create\CheckDocumentPipe as CreateCheckDocumentPipe;
use App\Pipelines\V1\Acts\Pipes\Create\ContractorsWorkplacePipe as CreateContractorsWorkplacePipe;
use App\Pipelines\V1\Acts\Pipes\DownloadDocumentFile\CreateActFilePipe;
use App\Pipelines\V1\Acts\Pipes\DownloadDocumentFile\DownloadDocumentFilePipe;
use App\Pipelines\V1\Acts\Pipes\DownloadDocumentFile\SendDocumentToS3Pipe;
use App\Pipelines\V1\Acts\Pipes\Export\CreateExportPipe;
use App\Pipelines\V1\Acts\Pipes\Get\ActPipe as GetActPipe;
use App\Pipelines\V1\Acts\Pipes\DeleteUnsignedAct\DeleteActPipe as DeleteUnsignedActPipe;
use App\Pipelines\V1\Acts\Pipes\DeleteUnsignedAct\CheckSignaturePipe as CheckSignatureDeletingActPipe;
use App\Pipelines\V1\Acts\Pipes\Get\ActJobTypesPipe as GetActJobTypesPipe;
use App\Pipelines\V1\Acts\Pipes\DownloadDocumentFile\ActPipe as DownloadActPipe;
use App\Pipelines\V1\Acts\Pipes\SendExportMail\GetExportPipe as SendExportMailGetExportPipe;
use App\Pipelines\V1\Acts\Pipes\SendExportMail\CreateMailPipe as SendExportMailCreateMailPipe;
use App\Pipelines\V1\Acts\Pipes\Signing\PrepareActsForSignBySimpleSignaturePipe;
use App\Pipelines\V1\Acts\Pipes\Signing\SendToSignBySimpleSignaturePipe;

final class ActsPipeline extends AbstractPipeline
{
    public function create(CreateActPipelineDto $dto): array
    {
        return $this->pipeline([
            CreateCheckManagerContractorPipe::class,
            CreateTemplatePipe::class,
            CreateCheckAgentPipe::class,
            CreateCheckContractorPipe::class,
            CreateCheckDocumentPipe::class,
            CreateContractorsWorkplacePipe::class,
            CreateActPipe::class,
            CreateActSignaturePipe::class,
            CreateActJobTypePipe::class,
        ], $dto);
    }

    public function actGeneration(CreateActPipelineDto $dto): array
    {
        return $this->pipeline([
            ActGenerationCustomerPipe::class,
            ActGenerationActJobTypePipe::class,
            ActGenerationTemplatePipe::class,
            ActGenerationDocumentPipe::class,
            ActGenerationActPipe::class,
        ], $dto);
    }

    public function get(GetActPipelineDto $dto): array
    {
        return $this->pipeline([
            GetActPipe::class,
            GetActJobTypesPipe::class,
        ], $dto);
    }

    public function checkSignedDocument(CheckSignedDocumentPipelineDto $dto): array
    {
        return $this->pipeline([
            CheckSignedDocumentCheckActPipe::class,
            CheckSignedDocumentCheckSignaturePipe::class,
        ], $dto);
    }

    public function createFromPaymentImport(CreateActPipelineDto $dto): array
    {
        return $this->pipeline([
            CreateTemplatePipe::class,
            CreateCheckAgentPipe::class,
            CreateCheckContractorPipe::class,
            CreateContractorsWorkplacePipe::class,
            CreateActPipe::class,
            CreateActSignaturePipe::class,
            CreateActJobTypePipe::class,
        ], $dto);
    }

    public function deleteUnsignedAct(DeleteActPipelineDto $dto): array
    {
        return $this->pipeline([
            CheckSignatureDeletingActPipe::class,
            DeleteUnsignedActPipe::class,
        ], $dto);
    }

    public function export(ExportDto $dto): array
    {
        $dto->setType(TypeEnum::JOB_ZIP_TO_EMAIL);

        return $this->pipeline([
            CreateExportPipe::class,
        ], $dto);
    }

    public function signBySimpleSignature(SignDataDto $dto): array
    {
        return $this->pipeline([
            PrepareActsForSignBySimpleSignaturePipe::class,
            SendToSignBySimpleSignaturePipe::class,
        ], $dto);
    }

    public function archiveExport(ArchiveExportPipelineDto $dto): array
    {
        return $this->pipeline([
            DownloadActsFromS3Pipe::class,
            CreateArchivesPipe::class,
            SendArchivesToS3Pipe::class,
            DeleteTemporaryFilesPipe::class,
            CreateFilesPipe::class,
            CreateExportFilesPipe::class
        ], $dto);
    }

    public function downloadDocumentFile(DownloadDocumentFilePipelineDto $dto): array
    {
        return $this->pipeline([
            DownloadActPipe::class,
            DownloadDocumentFilePipe::class,
            SendDocumentToS3Pipe::class,
            CreateActFilePipe::class,
        ], $dto);
    }

    public function sendExportMail(ExportDto $dto): array
    {
        return $this->pipeline([
            SendExportMailGetExportPipe::class,
            SendExportMailCreateMailPipe::class,
        ], $dto);
    }

    public function cancelProcessingSignature(ActDto $dto): array
    {
        return $this->pipeline([
            ChangeActStatusPipe::class,
        ], $dto);
    }
}
