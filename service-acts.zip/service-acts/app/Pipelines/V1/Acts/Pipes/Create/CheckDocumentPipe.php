<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\Create;

use Closure;
use Carbon\Carbon;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use App\Services\Document\DocumentService;
use App\Dto\Entities\Documents\DocumentDto;
use App\Dto\Pipelines\Acts\CreateActPipelineDto;
use App\Exceptions\Pipelines\AlienDocumentException;
use App\Exceptions\Pipelines\InvalidDocumentDateException;

final class CheckDocumentPipe implements PipeInterface
{
    public function __construct(private DocumentService $service)
    {
    }

    public function handle(DtoInterface|CreateActPipelineDto $dto, Closure $next): DtoInterface
    {
        $act      = $dto->getAct();
        $document = $this->service->findById($act->getSourceDocumentId());

        if ($act->getCompanyId() !== $document->company()->id()) {
            throw new AlienDocumentException();
        }

        if (Carbon::parse($document->date()) > Carbon::parse($act->getPeriodFrom())) {
            throw new InvalidDocumentDateException();
        }

        $dto->setDocument(DocumentDto::fromArray([
            'id'            => $document->id(),
            'name'          => $document->name(),
            'number'        => $document->number(),
            'manual_number' => $document->manualNumber(),
            'date'          => $document->date(),
        ]));

        return $next($dto);
    }
}
