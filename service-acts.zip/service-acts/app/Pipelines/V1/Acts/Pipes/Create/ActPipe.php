<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\Create;

use App\Enums\NoName\Acts\TypeEnum;
use App\Exceptions\Pipelines\DoubleActCreationWithPaymentException;
use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use App\Services\Act\ActService;
use App\Dto\Entities\Acts\ActJobTypeDto;
use App\Dto\Pipelines\Acts\CreateActPipelineDto;

final class ActPipe implements PipeInterface
{
    public function __construct(private ActService $service)
    {
    }

    public function handle(DtoInterface|CreateActPipelineDto $dto, Closure $next): DtoInterface
    {
        $info = $dto->toArray();

        unset($info['act']);
        unset($info['job_types']);

        $act = $dto->getAct();

        $act->setType(TypeEnum::JOB);

        if (!$act->getTotalPrice()) {
            $act->setTotalPrice($this->calculateTotalPrice($dto->getJobTypes()));
        }

        $act->setNumber($this->service->getMaxActNumber($act->getCompanyId(), $act->getType()) + 1);
        $act->setInfo($info);

        if (!$act->getName()) {
            $act->setName(__('act.default_name'));
        }

        if ($paymentId = $act->getPaymentId()) {
            if ($this->service->get(['payment_id' => $paymentId])) {
                throw new DoubleActCreationWithPaymentException();
            }
        }

        $dto->setAct($this->service->create($act));

        return $next($dto);
    }

    private function calculateTotalPrice(array $actJobTypes): float|null
    {
        $totalPrice = 0;

        /** @var ActJobTypeDto $actJobType */
        foreach ($actJobTypes as $actJobType) {
            $totalPrice += $actJobType->getPrice() * $actJobType->getCount();
        }

        return $totalPrice;
    }
}
