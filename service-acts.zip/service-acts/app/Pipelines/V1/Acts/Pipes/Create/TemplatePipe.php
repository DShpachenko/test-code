<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\Create;

use App\Enums\NoName\Templates\SignOrderEnum;
use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use App\Services\Act\TemplateService;
use App\Dto\Pipelines\Acts\CreateActPipelineDto;
use App\Exceptions\Pipelines\AlienTemplateException;
use App\Exceptions\Pipelines\ObjectNotFoundException;

final class TemplatePipe implements PipeInterface
{
    public function __construct(private TemplateService $service)
    {
    }

    public function handle(DtoInterface|CreateActPipelineDto $dto, Closure $next): DtoInterface
    {
        $act = $dto->getAct();

        if ($templateId = $act->getTemplateId()) {
            if (!$template = $this->service->get(['id' => $templateId])) {
                throw new ObjectNotFoundException(trans('exceptions.42'));
            }

            if ($act->getCompanyId() !== $template->getCompanyId()) {
                throw new AlienTemplateException();
            }

            if ($managerContractorId = $template->getManagerContractorId()) {
                $act->setManagerContractorId($managerContractorId);
            }

            $act->setSignOrder($template->getSignOrder());
            $dto->setAct($act);

            $dto->setTemplate($template);
        } else {
            $act->setSignOrder(SignOrderEnum::ARBITRARY);
            $dto->setAct($act);
        }

        return $next($dto);
    }
}
