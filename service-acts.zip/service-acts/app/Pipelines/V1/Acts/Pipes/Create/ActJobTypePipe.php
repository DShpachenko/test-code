<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\Create;

use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use App\Jobs\Acts\CreateActDocumentJob;
use App\Services\Act\ActJobTypeService;
use App\Dto\Entities\Acts\ActJobTypeDto;
use App\Dto\Pipelines\Acts\CreateActPipelineDto;

final class ActJobTypePipe implements PipeInterface
{
    public function __construct(private ActJobTypeService $service)
    {
    }

    public function handle(DtoInterface|CreateActPipelineDto $dto, Closure $next): DtoInterface
    {
        $actId = $dto->getAct()->getId();
        $jobTypes = $dto->getJobTypes();
        $updatedJobTypes = [];

        /** @var ActJobTypeDto $actJobType */
        foreach ($jobTypes as $actJobType) {
            $actJobType->setActId($actId);
            $updatedJobTypes[] = $this->service->create($actJobType);
        }

        $dto->setJobTypes($updatedJobTypes);

        dispatch(new CreateActDocumentJob($actId));

        return $next($dto);
    }
}
