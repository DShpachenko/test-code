<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\Create;

use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use App\Services\Act\ActSignatureService;
use App\Dto\Entities\Acts\ActSignatureDto;
use App\Dto\Pipelines\Acts\CreateActPipelineDto;

final class ActSignaturePipe implements PipeInterface
{
    public function __construct(private ActSignatureService $service)
    {
    }

    public function handle(DtoInterface|CreateActPipelineDto $dto, Closure $next): DtoInterface
    {
        $this->service->create(ActSignatureDto::fromArray([
            'act_id' => $dto->getAct()->getId(),
        ]));

        return $next($dto);
    }
}
