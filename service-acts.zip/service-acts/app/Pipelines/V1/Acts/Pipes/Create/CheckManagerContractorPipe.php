<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\Create;

use App\Exceptions\Pipelines\ObjectNotFoundException;
use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use App\Services\Taxi\CustomerService;
use App\Dto\Pipelines\Acts\CreateActPipelineDto;

/**
 * Данный пайп предназначен для заполнения manager_contractor_id в случае если за автором акта не закреплен штатник
 */
final class CheckManagerContractorPipe implements PipeInterface
{
    public function __construct(private CustomerService $customerService)
    {
    }

    public function handle(DtoInterface|CreateActPipelineDto $dto, Closure $next): DtoInterface
    {
        $act = $dto->getAct();

        if (! $act->getManagerContractorId()) {
            $customer = $this->customerService->get(['id' => $act->getAuthorId()]);

            if (!$customer) {
                throw new ObjectNotFoundException();
            }

            if ($contractorId = $customer->getContractorId()) {
                $act->setManagerContractorId($contractorId);
            } else {
                $rootCustomer = $this->customerService->get(['id' => $customer->getRootCustomerId()]);
                $act->setManagerContractorId($rootCustomer->getContractorId());
            }

            $dto->setAct($act);
        }

        return $next($dto);
    }
}
