<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\Create;

use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use App\Dto\Entities\Acts\ActDto;
use App\Services\Taxi\PositionService;
use App\Dto\Entities\Taxi\ContractorDto;
use App\Dto\Pipelines\Acts\CreateActPipelineDto;
use App\Dto\Entities\Taxi\ContractorsWorkplaceDto;
use App\Services\Taxi\ContractorsWorkplaceService;

final class ContractorsWorkplacePipe implements PipeInterface
{
    public function __construct(
        private ContractorsWorkplaceService $service,
        private PositionService             $positionService
    )
    {
    }

    public function handle(DtoInterface|CreateActPipelineDto $dto, Closure $next): DtoInterface
    {
        $dto->setEmployeeContractorsWorkplace($this->employeeWorkplace($dto->getEmployeeContractor()));
        $dto->setManagerContractorsWorkplace($this->managerWorkplace($dto->getAct()));

        return $next($dto);
    }

    private function managerWorkplace(ActDto $act): ?ContractorsWorkplaceDto
    {
        $managerContractorWorkplaceDto = $this->service->get([
            'contractor_id' => $act->getManagerContractorId(),
            'company_id'    => $act->getCompanyId(),
            'agent_id'      => $act->getAgentId(),
        ]);

        if (
            $managerContractorWorkplaceDto &&
            $position = $this->positionService->get(['id' => $managerContractorWorkplaceDto->getPositionId()])
        ) {
            $managerContractorWorkplaceDto->setPosition($position);
        }

        return $managerContractorWorkplaceDto;
    }

    public function employeeWorkplace(ContractorDto $employeeContractor): ?ContractorsWorkplaceDto
    {
        $employeeContractorWorkPlaceDto = $this->service->get([
            'contractor_id' => $employeeContractor->getId(),
            'company_id'    => $employeeContractor->getCompanyId(),
            'agent_id'      => $employeeContractor->getAgentId(),
        ]);

        if (
            $employeeContractorWorkPlaceDto &&
            $position = $this->positionService->get(['id' => $employeeContractorWorkPlaceDto->getPositionId()])
        ) {
            $employeeContractorWorkPlaceDto->setPosition($position);
        }

        return $employeeContractorWorkPlaceDto;
    }
}
