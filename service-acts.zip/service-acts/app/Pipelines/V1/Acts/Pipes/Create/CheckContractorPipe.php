<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\Create;

use App\Dto\Entities\Acts\TemplateDto;
use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use App\Dto\Entities\Acts\ActDto;
use App\Dto\Entities\Taxi\ContractorDto;
use App\Services\Taxi\ContractorService;
use App\Dto\Pipelines\Acts\CreateActPipelineDto;
use App\Exceptions\Pipelines\AlienContractorException;
use App\Exceptions\Pipelines\ManagerContractorException;
use App\Exceptions\Pipelines\EmployeeContractorException;

final class CheckContractorPipe implements PipeInterface
{
    public function __construct(private ContractorService $service)
    {
    }

    public function handle(DtoInterface|CreateActPipelineDto $dto, Closure $next): DtoInterface
    {
        $act = $dto->getAct();

        $dto->setEmployeeContractor($this->employeeContractor($act));
        $dto->setManagerContractor($this->managerContractor($act, $dto->getTemplate()));

        return $next($dto);
    }

    private function employeeContractor(ActDto $act): ContractorDto
    {
        if (!$contractor = $this->service->get(['id' => $act->getEmployeeContractorId()])) {
            throw new EmployeeContractorException();
        }

        if ($act->getCompanyId() !== $contractor->getCompanyId()) {
            throw new AlienContractorException();
        }

        return $contractor;
    }

    private function managerContractor(ActDto $act, ?TemplateDto $template): ContractorDto
    {
        $templateManagerContractorId = $template?->getManagerContractorId();
        $managerContractorId = $templateManagerContractorId ?? $act->getManagerContractorId();

        if (!$contractor = $this->service->get(['id' => $managerContractorId])) {
            throw new ManagerContractorException();
        }

        if ($act->getCompanyId() !== $contractor->getCompanyId()) {
            throw new AlienContractorException();
        }

        return $contractor;
    }
}
