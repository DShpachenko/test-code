<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\Create;

use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use App\Services\Taxi\AgentService;
use App\Dto\Pipelines\Acts\CreateActPipelineDto;
use App\Exceptions\Pipelines\AlienAgentException;

final class CheckAgentPipe implements PipeInterface
{
    public function __construct(private AgentService $service)
    {
    }

    public function handle(DtoInterface|CreateActPipelineDto $dto, Closure $next): DtoInterface
    {
        $act   = $dto->getAct();
        $actTemplate = $dto->getTemplate();

        $agentId = $actTemplate ? $actTemplate->getAgentId() : $act->getAgentId();

        $agent = $this->service->get(['id' => $agentId]);

        if ($act->getCompanyId() !== $agent->getCompanyId()) {
            throw new AlienAgentException();
        }

        $dto->setAgent($agent);

        return $next($dto);
    }
}
