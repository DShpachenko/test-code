<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\Signing;

use App\Dto\DtoInterface;
use App\Dto\Entities\Acts\SignDataDto;
use App\Jobs\Acts\SendToSigningActsJob;
use App\Pipelines\PipeInterface;
use Closure;

final class SendToSignBySimpleSignaturePipe implements PipeInterface
{
    public function handle(DtoInterface|SignDataDto $dto, Closure $next): DtoInterface
    {
        $chunkSize = (int) config('signing.simple_signature.chunk_to_signing');
        $allActIds = $dto->getActIds();
        $dto->resetFilterDto();

        foreach (array_chunk($allActIds, $chunkSize) as $chunkIds) {
            $dto->setActIds($chunkIds);
            dispatch(new SendToSigningActsJob($dto));
        }

        return $next($dto);
    }
}
