<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\Signing;

use App\Dto\DtoInterface;
use App\Dto\Entities\Acts\SignDataDto;
use App\Enums\NoName\Acts\StatusEnum;
use App\Exceptions\Pipelines\ObjectNotFoundException;
use App\Pipelines\PipeInterface;
use App\Services\Act\ActService;
use Closure;

final class PrepareActsForSignBySimpleSignaturePipe implements PipeInterface
{
    public function __construct(private ActService $actService)
    {
    }

    public function handle(DtoInterface|SignDataDto $dto, Closure $next): DtoInterface
    {
        $filterDto = $dto->filterDto();
        $filterDto->setStatus([
            StatusEnum::PENDING_COMPANY_SIGNATURE,
            StatusEnum::PENDING_EMPLOYEE_SIGNATURE,
            StatusEnum::PROCESSING_SIGNATURE,
        ]);

        $acts   = $this->actService->listByFilters($filterDto);
        $actIds = $acts->pluck('act_id')->toArray();
        if (empty($actIds)) {
            throw new ObjectNotFoundException();
        }

        $this->actService->updateByIds($actIds, [
            'status' => StatusEnum::PROCESSING_SIGNATURE,
        ]);

        $dto->setActIds($actIds);

        return $next($dto);
    }
}
