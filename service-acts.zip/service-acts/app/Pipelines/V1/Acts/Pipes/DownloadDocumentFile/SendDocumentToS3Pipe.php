<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\DownloadDocumentFile;

use Closure;
use App\Dto\DtoInterface;
use App\Helpers\FileHelper;
use App\Pipelines\PipeInterface;
use App\Dto\Entities\Storage\FileDto;
use App\Services\Storage\FileService;
use Illuminate\Support\Facades\Storage;
use App\Enums\NoName\Storage\File\TypeEnum;
use App\Dto\Entities\Documents\DocumentFileDto;
use App\Dto\Pipelines\Acts\DownloadDocumentFilePipelineDto;

final class SendDocumentToS3Pipe implements PipeInterface
{
    public function __construct(private FileService $fileService)
    {
    }

    public function handle(DtoInterface|DownloadDocumentFilePipelineDto $dto, Closure $next): DtoInterface
    {
        $documentFile = $dto->getDocumentFile();
        $path         = $this->calculatePath($documentFile);

        Storage::disk('selectel')->put($path, $documentFile->getContent());

        $dto->setFile($this->fileService->create(FileDto::fromArray([
            'type' => TypeEnum::DOCUMENT_FILE,
            'path' => $path,
        ])));

        return $next($dto);
    }

    private function calculatePath(DocumentFileDto $dto): string
    {
        return TypeEnum::DOCUMENT_FILE . FileHelper::getPath() . $dto->getName();
    }
}
