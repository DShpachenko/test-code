<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\DownloadDocumentFile;

use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use App\Services\Document\DocumentService;
use App\Dto\Pipelines\Acts\DownloadDocumentFilePipelineDto;

final class DownloadDocumentFilePipe implements PipeInterface
{
    public function __construct(private DocumentService $documentService)
    {
    }

    public function handle(DtoInterface|DownloadDocumentFilePipelineDto $dto, Closure $next): DtoInterface
    {
        $documentId = $dto->getAct()->getActDocumentId();

        // защита от того, что может отсутствовать печатная форма у не подписанного
        // документа, в таком случае качаем оригинальный файл документа
        try {
            $file = $this->documentService->downloadDocument($documentId);
        } catch (\Exception|\Throwable $e) {
            $file = $this->documentService->downloadOriginDocument($documentId);
        }

        $dto->setDocumentFile($file);

        return $next($dto);
    }
}
