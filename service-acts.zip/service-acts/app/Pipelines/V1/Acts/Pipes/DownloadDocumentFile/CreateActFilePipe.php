<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\DownloadDocumentFile;

use Closure;
use App\Dto\DtoInterface;
use Illuminate\Support\Carbon;
use App\Pipelines\PipeInterface;
use App\Services\Act\ActFileService;
use App\Dto\Entities\Acts\ActFileDto;
use App\Dto\Pipelines\Acts\DownloadDocumentFilePipelineDto;

final class CreateActFilePipe implements PipeInterface
{
    public function __construct(private ActFileService $actFileService)
    {
    }

    public function handle(DtoInterface|DownloadDocumentFilePipelineDto $dto, Closure $next): DtoInterface
    {
        $actId = $dto->getAct()->getId();

        // удаляю по акту все имеющиеся связки документов,
        // по 1 акту в момент времени должен быть только 1
        // актуальный документ
        $this->actFileService->delete(['act_id' => $actId]);

        $this->actFileService->create(ActFileDto::fromArray([
            'act_id'     => $actId,
            'file_id'    => $dto->getFile()->getId(),
            'created_at' => Carbon::now()->format('Y-m-d H:i:s'),
        ]));

        return $next($dto);
    }
}
