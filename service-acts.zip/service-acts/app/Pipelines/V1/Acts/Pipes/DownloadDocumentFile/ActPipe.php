<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\DownloadDocumentFile;

use Closure;
use App\Dto\DtoInterface;
use App\Services\Act\ActService;
use App\Pipelines\PipeInterface;
use App\Exceptions\Pipelines\ObjectNotFoundException;
use App\Dto\Pipelines\Acts\DownloadDocumentFilePipelineDto;

final class ActPipe implements PipeInterface
{
    public function __construct(private ActService $actService)
    {
    }

    public function handle(DtoInterface|DownloadDocumentFilePipelineDto $dto, Closure $next): DtoInterface
    {
        if (!$act = $this->actService->get($dto->getAct()->toArray())) {
            throw new ObjectNotFoundException();
        }

        $dto->setAct($act);

        return $next($dto);
    }
}
