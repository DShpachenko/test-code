<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\Export;

use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use App\Services\Act\ExportService;
use App\Dto\Entities\Acts\ExportDto;
use App\Jobs\Acts\CreateExportArchiveJob;

final class CreateExportPipe implements PipeInterface
{
    public function __construct(private ExportService $service)
    {
    }

    public function handle(DtoInterface|ExportDto $dto, Closure $next): DtoInterface
    {
        $export = $this->service->create($dto);

        dispatch(new CreateExportArchiveJob($export->getId()));

        return $next($export);
    }
}
