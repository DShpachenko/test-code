<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\ArchiveExport;

use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use App\Jobs\Acts\SendExportMailJob;
use App\Services\Act\ExportFileService;
use App\Dto\Entities\Acts\ExportFileDto;
use App\Dto\Pipelines\Acts\ArchiveExportPipelineDto;

final class CreateExportFilesPipe implements PipeInterface
{
    public function __construct(private ExportFileService $exportFileService)
    {
    }

    public function handle(DtoInterface|ArchiveExportPipelineDto $dto, Closure $next): ArchiveExportPipelineDto
    {
        $exportId = $dto->getExport()->getId();

        foreach ($dto->getS3Archives() as $archive) {
            $this->exportFileService->create(
                ExportFileDto::fromArray([
                    'file_id'    => $archive->getId(),
                    'export_id'  => $exportId,
                    'created_at' => now()->format('Y-m-d H:i:s'),
                ])
            );
        }

        dispatch(new SendExportMailJob($exportId));

        return $next($dto);
    }
}
