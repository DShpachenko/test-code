<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\ArchiveExport;

use App\Dto\Entities\Acts\ActDto;
use App\Dto\Entities\Acts\ExportDto;
use App\Dto\Pipelines\Acts\ArchiveExportPipelineDto;
use App\Enums\NoName\Exports\StatusEnum;
use App\Exceptions\Pipelines\ExportArchiveException;
use App\Models\Acts\Act;
use App\Services\Act\ActService;
use App\Services\Act\ExportService;
use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Storage;

final class DownloadActsFromS3Pipe implements PipeInterface
{
    public function __construct(
        private ActService    $actService,
        private ExportService $exportService
    )
    {
    }

    public function handle(DtoInterface|ArchiveExportPipelineDto $dto, Closure $next): ArchiveExportPipelineDto
    {
        $export = $dto->getExport();
        if (empty($export)) {
            throw new ExportArchiveException();
        }

        if ($export->getStatus() !== StatusEnum::NEW) {
            throw new ExportArchiveException();
        }

        $export = $dto->getExport();
        $export->setStatus(StatusEnum::ARCHIVE_CREATION);
        $this->exportService->update(['id' => $export->getId()], ['status' => StatusEnum::ARCHIVE_CREATION]);

        $actsPart = 1;

        $this->actService->allByFiltersWithChunk(
            $export->getFilters(),
            config('export.acts.files_in_archive'),
            $this->downloadFiles(
                $dto,
                $export,
                $actsPart
            ),
            ['file']
        );

        $dto->setTmpDirectoryPath($this->makeTmpExportDirectoryPath($export));

        return $next($dto);
    }

    private function downloadFiles(ArchiveExportPipelineDto $dto, ExportDto $export, int $actsPart): callable
    {
        return function (Collection $items) use (&$dto, &$actsPart, $export) {
            $dto->addActDirectoryTmpPath($this->makeTmpActsDirectoryPath($export, $actsPart));

            $items->each(function (Act $item) use (&$actsPart, $export) {
                $act = ActDto::fromArray($item->toArray());

                $this->downloadFile($export, $act, $actsPart);
            });

            $actsPart++;
        };
    }

    private function downloadFile(
        ExportDto $export,
        ActDto    $act,
        int       $actsPart
    ): void
    {
        $actFile        = $act->getFile();
        $actFileContent = Storage::disk('selectel')->get($actFile?->getPath());

        if (empty($actFileContent)) {
            throw new ExportArchiveException();
        }

        $tmpFileName = $this->makeTmpActFilePath(
            $export,
            $act,
            $actsPart,
            $actFile->getPath()
        );

        $tmpActsDirectory = $this->makeTmpActsDirectoryPath($export, $actsPart);
        if (! is_dir($tmpActsDirectory)) {
            mkdir($tmpActsDirectory, 0777, true);
        }

        file_put_contents($tmpFileName, $actFileContent);
    }

    private function makeTmpActFilePath(
        ExportDto $export,
        ActDto    $act,
        int       $actsPart,
        string    $actFilePath,
    ): string
    {
        return $this->makeTmpActsDirectoryPath($export, $actsPart) .
            DIRECTORY_SEPARATOR .
            $this->makeTmpActFileName($act, $actFilePath);
    }

    private function makeTmpActsDirectoryPath(
        ExportDto $export,
        int       $actsPart
    ): string
    {
        $tmpExportDirectoryPath = $this->makeTmpExportDirectoryPath($export);

        return sprintf(
            "%s/acts/%s",
            $tmpExportDirectoryPath,
            $actsPart
        );
    }

    private function makeTmpExportDirectoryPath(ExportDto $export): string
    {
        return sprintf(
            "%s/exports/%s",
            sys_get_temp_dir(),
            $export->getId()
        );
    }

    private function makeTmpActFileName(ActDto $act, string $actFilePath): string
    {
        $actNameTemplate = config('export.acts.file.name_template', 'акт_%s');
        $actName         = sprintf($actNameTemplate, $act->getActDocumentId());
        $actFileType     = substr($actFilePath, strpos($actFilePath, '.') + 1, strlen($actFilePath));

        return sprintf(
            "%s.%s",
            $actName,
            $actFileType
        );
    }
}
