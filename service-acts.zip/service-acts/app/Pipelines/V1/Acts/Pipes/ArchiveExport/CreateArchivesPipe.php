<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\ArchiveExport;

use App\Dto\Entities\Storage\FileDto;
use App\Dto\Pipelines\Acts\ArchiveExportPipelineDto;
use App\Enums\NoName\Storage\File\TypeEnum;
use App\Exceptions\Pipelines\ExportArchiveException;
use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use Symfony\Component\Process\Process;

final class CreateArchivesPipe implements PipeInterface
{
    public function handle(DtoInterface|ArchiveExportPipelineDto $dto, Closure $next): ArchiveExportPipelineDto
    {
        ini_set('memory_limit', config('export.acts.memory_limit'));

        $this->createArchiveDirectory($dto->getTmpDirectoryPath());

        $directoryNumber = 1;

        $actDirectoryPaths = $dto->getActTmpDirectoryPaths();
        foreach ($actDirectoryPaths as $actDirectoryPath) {
            $tmpArchive = $this->createArchive(
                $dto->getTmpDirectoryPath(),
                $actDirectoryPath,
                $directoryNumber
            );
            $dto->addTmpArchive($tmpArchive);
            $directoryNumber++;
        }

        return $next($dto);
    }

    private function createArchiveDirectory(string $exportTmpDirectoryPath): void
    {
        $tmpArchiveDirectoryPath = $this->makeTmpArchiveDirectory($exportTmpDirectoryPath);

        if (! is_dir($tmpArchiveDirectoryPath)) {
            mkdir($tmpArchiveDirectoryPath, 0777, true);
        } elseif (! is_writable($tmpArchiveDirectoryPath)) {
            throw new ExportArchiveException(trans('exceptions.17'));
        }
    }

    private function createArchive(
        string $exportTmpDirectoryPath,
        string $actDirectoryPath,
        int    $actsPartNumber
    ): FileDto
    {
        $archivePath = $this->makeTmpArchivePath($exportTmpDirectoryPath, $actsPartNumber);

        (new Process(['zip', '-r', '-j', $archivePath, $actDirectoryPath]))->run();

        return FileDto::fromArray([
            'type' => TypeEnum::DOCUMENTS_ARCHIVE,
            'path' => $archivePath,
        ]);
    }

    private function makeTmpArchivePath(
        string $exportTmpDirectoryPath,
        int    $actsPartNumber
    ): string
    {
        return $this->makeTmpArchiveDirectory($exportTmpDirectoryPath) .
            DIRECTORY_SEPARATOR .
            $this->makeArchiveName($actsPartNumber);
    }

    private function makeTmpArchiveDirectory(
        string $exportTmpDirectoryPath
    ): string
    {
        return sprintf(
            "%s/acts/archives",
            $exportTmpDirectoryPath
        );
    }

    private function makeArchiveName(int $actsPartNumber): string
    {
        $archiveNameTemplate = config('export.acts.archive.name_template', 'акты_%s');
        $archiveName         = sprintf($archiveNameTemplate, $actsPartNumber);
        $archiveType         = config('export.acts.archive.type', 'zip');

        return sprintf(
            "%s.%s",
            $archiveName,
            $archiveType
        );
    }
}
