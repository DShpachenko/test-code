<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\ArchiveExport;

use App\Dto\Pipelines\Acts\ArchiveExportPipelineDto;
use App\Services\Storage\FileService;
use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;

final class CreateFilesPipe implements PipeInterface
{
    public function __construct(private FileService $fileService)
    {
    }

    public function handle(DtoInterface|ArchiveExportPipelineDto $dto, Closure $next): ArchiveExportPipelineDto
    {
        $files = [];

        foreach ($dto->getS3Archives() as $archive) {
            $files[] = $this->fileService->create($archive);
        }

        $dto->setS3Archives($files);

        return $next($dto);
    }
}
