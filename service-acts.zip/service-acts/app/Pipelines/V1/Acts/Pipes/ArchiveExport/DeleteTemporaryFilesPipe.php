<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\ArchiveExport;

use App\Dto\Pipelines\Acts\ArchiveExportPipelineDto;
use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use Illuminate\Support\Facades\File;

final class DeleteTemporaryFilesPipe implements PipeInterface
{
    public function handle(DtoInterface|ArchiveExportPipelineDto $dto, Closure $next): ArchiveExportPipelineDto
    {
        $this->deleteTmpDirectory($dto->getTmpDirectoryPath());

        return $next($dto);
    }

    private function deleteTmpDirectory(string $directoryPath)
    {
        File::deleteDirectory($directoryPath);
    }
}
