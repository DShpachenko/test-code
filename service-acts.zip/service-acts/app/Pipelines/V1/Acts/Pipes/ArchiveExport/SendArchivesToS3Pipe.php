<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\ArchiveExport;

use App\Dto\Entities\Acts\ExportDto;
use App\Dto\Entities\Storage\FileDto;
use App\Dto\Pipelines\Acts\ArchiveExportPipelineDto;
use App\Enums\NoName\Storage\File\TypeEnum;
use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use Illuminate\Support\Facades\Storage;

final class SendArchivesToS3Pipe implements PipeInterface
{
    public function handle(DtoInterface|ArchiveExportPipelineDto $dto, Closure $next): ArchiveExportPipelineDto
    {
        $archives = [];

        $archiveNumber = 1;

        foreach ($dto->getTmpArchives() as $actArchive) {
            $archive = $this->sendArchiveToS3(
                $dto->getExport(),
                $actArchive,
                $archiveNumber
            );

            $archives[] = $archive;

            $archiveNumber++;
        }

        $dto->setS3Archives($archives);

        return $next($dto);
    }

    private function sendArchiveToS3(
        ExportDto $export,
        FileDto   $tmpArchive,
        int       $archiveNumber
    ): FileDto
    {
        $archiveContent = file_get_contents($tmpArchive->getPath());

        $archiveS3Path = $this->calculateArchiveS3Path($export, $archiveNumber);

        Storage::disk('selectel')->put($archiveS3Path, $archiveContent);

        return FileDto::fromArray([
            'type' => TypeEnum::DOCUMENTS_ARCHIVE,
            'path' => $archiveS3Path,
        ]);
    }

    private function calculateArchiveS3Path(
        ExportDto $export,
        int       $archiveNumber
    ): string
    {
        $archiveType = config('export.acts.archive.type', 'zip');

        $archiveName = sprintf(
            config('export.acts.archive.name_template', 'акты_%s'),
            $archiveNumber
        );

        $archiveNameWithType = sprintf(
            "%s.%s",
            $archiveName,
            $archiveType
        );

        return TypeEnum::DOCUMENTS_ARCHIVE .
            DIRECTORY_SEPARATOR .
            $export->getId() .
            DIRECTORY_SEPARATOR .
            $archiveNameWithType;
    }
}
