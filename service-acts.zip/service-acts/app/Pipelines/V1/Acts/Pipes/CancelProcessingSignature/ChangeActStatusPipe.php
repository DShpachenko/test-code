<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\CancelProcessingSignature;

use App\Dto\Entities\Acts\ActDto;
use App\Enums\NoName\Acts\StatusEnum;
use App\Services\Act\ActService;
use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;

final class ChangeActStatusPipe implements PipeInterface
{
    public function __construct(private ActService $actService)
    {
    }

    public function handle(DtoInterface|ActDto $dto, Closure $next): DtoInterface
    {
        if ($dto->getStatus() !== StatusEnum::PROCESSING_SIGNATURE) {
            return $next($dto);
        }

        $actWithNewStatus = $this->changeActStatus($dto);

        $this->actService->update(['id' => $dto->getId()], ['status' => $actWithNewStatus->getStatus()]);

        return $next($dto);
    }

    private function changeActStatus(ActDto $act): ActDto
    {
        if (!$act->getSignature()?->getEmployeeSignatureId()) {
            $act->setStatus(StatusEnum::PENDING_EMPLOYEE_SIGNATURE);
            return $act;
        }

        if (!$act->getSignature()?->getManagerSignatureId()) {
            $act->setStatus(StatusEnum::PENDING_COMPANY_SIGNATURE);
            return $act;
        }

        $act->setStatus(StatusEnum::DONE);

        return $act;
    }
}
