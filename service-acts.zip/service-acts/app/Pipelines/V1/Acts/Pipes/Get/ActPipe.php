<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\Get;

use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use App\Services\Act\ActService;
use App\Dto\Pipelines\Acts\GetActPipelineDto;

final class ActPipe implements PipeInterface
{
    public function __construct(private ActService $service)
    {
    }

    public function handle(DtoInterface|GetActPipelineDto $dto, Closure $next): DtoInterface
    {
        $act = $this->service->get($dto->getAct()->toArray());

        if ($act) {
            $dto = GetActPipelineDto::fromArray(array_merge(['act' => $act], $act->getInfo()));
        } else {
            $dto->setAct(null);
        }

        return $next($dto);
    }

}
