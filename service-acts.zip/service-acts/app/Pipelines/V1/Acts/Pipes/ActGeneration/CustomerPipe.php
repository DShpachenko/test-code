<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\ActGeneration;

use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use App\Services\Taxi\CustomerService;
use App\Exceptions\Pipelines\CustomerException;
use App\Dto\Pipelines\Acts\CreateActPipelineDto;

final class CustomerPipe implements PipeInterface
{
    public function __construct(private CustomerService $service)
    {
    }

    public function handle(DtoInterface|CreateActPipelineDto $dto, Closure $next): DtoInterface
    {
        $act = $dto->getAct();

        if (! $customer = $this->service->get([
            'company_id'     => $act->getCompanyId(),
            'rootCustomerId' => null,
        ])) {
            throw new CustomerException();
        }

        $dto->setCustomer($customer);

        return $next($dto);
    }
}
