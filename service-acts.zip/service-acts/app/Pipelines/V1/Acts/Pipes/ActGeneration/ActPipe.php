<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\ActGeneration;

use Closure;
use App\Dto\DtoInterface;
use App\Services\Act\ActService;
use App\Pipelines\PipeInterface;
use App\Enums\NoName\Acts\StatusEnum;
use App\Dto\Entities\Acts\SignNotificationDto;
use App\Jobs\Acts\SendSignatureNotificationJob;
use App\Dto\Pipelines\Acts\CreateActPipelineDto;

final class ActPipe implements PipeInterface
{
    public function __construct(private ActService $service)
    {
    }

    public function handle(DtoInterface|CreateActPipelineDto $dto, Closure $next): DtoInterface
    {
        $act = $dto->getAct();
        $this->service->update([
            'id' => $act->getId(),
        ], [
            'status'          => StatusEnum::PENDING_EMPLOYEE_SIGNATURE,
            'act_document_id' => $act->getActDocumentId(),
        ]);

        if (app()->environment('production')) {
            dispatch(new SendSignatureNotificationJob(new SignNotificationDto(
                $act->getEmployeeContractorId(),
                $act->getId(),
            )));
        }

        return $next($dto);
    }
}
