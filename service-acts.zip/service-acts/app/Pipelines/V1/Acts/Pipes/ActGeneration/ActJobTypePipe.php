<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\ActGeneration;

use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use App\Services\Act\ActJobTypeService;
use App\Dto\Pipelines\Acts\CreateActPipelineDto;

final class ActJobTypePipe implements PipeInterface
{
    public function __construct(private ActJobTypeService $actJobTypeService)
    {
    }

    public function handle(DtoInterface|CreateActPipelineDto $dto, Closure $next): DtoInterface
    {
        $dto->setJobTypes($this->actJobTypeService->list([
            'act_id' => $dto->getAct()->getId(),
        ])?->toArray());

        return $next($dto);
    }
}
