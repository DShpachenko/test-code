<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\ActGeneration;

use Closure;
use App\Dto\DtoInterface;
use Illuminate\Support\Str;
use Illuminate\Support\Carbon;
use App\Pipelines\PipeInterface;
use App\Dto\Entities\Acts\ActDto;
use Illuminate\Support\Facades\File;
use App\Jobs\Acts\DownloadDocumentFileJob;
use App\Services\Document\DocumentService;
use App\Services\Act\ActGenerationService;
use NoName\ClientDocuments\Dto\Document;
use App\Dto\Pipelines\Acts\CreateActPipelineDto;
use NoName\ClientDocuments\Dto\CreateDocumentData;
use NoName\ClientDocuments\Dto\CreateSignatureData;

final class DocumentPipe implements PipeInterface
{
    public function __construct(
        private ActGenerationService $service,
        private DocumentService $documentService,
    ) {
    }

    public function handle(DtoInterface|CreateActPipelineDto $dto, Closure $next): DtoInterface
    {
        $path = $this->service->generate($dto);
        $act = $dto->getAct();
        $content = file_get_contents($path);
        File::delete($path);
        $document = $this->createDocument($content, $act, $dto);
        $act->setActDocumentId($document->id());
        $act->setDocumentHash($document->hash());
        $dto->setAct($act);

        dispatch(new DownloadDocumentFileJob($act->getId()));

        return $next($dto);
    }

    private function createDocument(string $content, ActDto $act, CreateActPipelineDto $dto): Document
    {
        return $this->documentService->create(new CreateDocumentData(
            $act->getCompanyId(),
            $act->getAgentId(),
            null,
            $act->getName(),
            Carbon::parse($act->getCreatedAt())->format('d.m.Y'),
            $act->getSignOrder(),
            [new CreateSignatureData(
                $act->getManagerContractorId(),
                $dto->getManagerContractorsWorkplace()?->getPosition()?->getId(),
            )],
            [new CreateSignatureData(
                $dto->getEmployeeContractor()->getId(),
                $dto->getEmployeeContractorsWorkplace()?->getPosition()?->getId(),
            )],
            Str::random() . '.' . ActGenerationService::DOCX_FORMAT,
            $content,
            null,
            null,
            null,
            true
        ));
    }
}
