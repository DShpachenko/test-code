<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\DeleteUnsignedAct;

use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use App\Services\Act\ActService;
use Illuminate\Support\Facades\Log;
use App\Dto\Pipelines\Acts\DeleteActPipelineDto;

final class DeleteActPipe implements PipeInterface
{
    public function __construct(private ActService $actService)
    {
    }

    public function handle(DtoInterface|DeleteActPipelineDto $dto, Closure $next): DtoInterface
    {
        $act = $dto->getAct();

        $this->actService->delete([
            'id'         => $act->getId(),
            'company_id' => $act->getCompanyId(),
        ]);

        Log::info(sprintf('Deleted act_id %d by user_id %d', $act->getId(), $dto->getUserId()));

        return $next($dto);
    }
}
