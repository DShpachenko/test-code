<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\DeleteUnsignedAct;

use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use App\Services\Act\ActSignatureService;
use App\Dto\Pipelines\Acts\DeleteActPipelineDto;
use App\Exceptions\Pipelines\ForbiddenDeletingSignedActException;

final class CheckSignaturePipe implements PipeInterface
{
    public function __construct(private ActSignatureService $actSignatureService)
    {
    }

    public function handle(DtoInterface|DeleteActPipelineDto $dto, Closure $next): DtoInterface
    {
        $act = $dto->getAct();

        $actSignature = $this->actSignatureService->get(['act_id' => $act->getId()]);

        if (
            !is_null($actSignature->getManagerSignatureAt()) ||
            !is_null($actSignature->getEmployeeSignatureAt())
        ) {
            throw new ForbiddenDeletingSignedActException();
        }

        return $next($dto);
    }
}
