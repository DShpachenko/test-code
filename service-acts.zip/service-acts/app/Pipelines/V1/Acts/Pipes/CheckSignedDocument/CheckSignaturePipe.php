<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\CheckSignedDocument;

use App\Enums\NoName\Templates\SignOrderEnum;
use Closure;
use App\Dto\DtoInterface;
use App\Services\Act\ActService;
use App\Pipelines\PipeInterface;
use App\Jobs\Acts\ActStatusDoneJob;
use App\Enums\NoName\Acts\StatusEnum;
use App\Services\Act\ActSignatureService;
use App\Services\Document\DocumentService;
use App\Dto\Entities\Acts\ActSignatureDto;
use NoName\ClientDocuments\Dto\Document;
use App\Jobs\Acts\DownloadDocumentFileJob;
use App\Dto\Pipelines\Acts\CheckSignedDocumentPipelineDto;

final class CheckSignaturePipe implements PipeInterface
{
    private const DOCUMENT_STATUS_SIGNED = 'signed';

    public function __construct(
        private ActSignatureService $actSignatureService,
        private ActService          $actService,
        private DocumentService     $service,
    )
    {
    }

    public function handle(DtoInterface|CheckSignedDocumentPipelineDto $dto, Closure $next): DtoInterface
    {
        if ($act = $dto->getAct()) {
            $actSignature = $act->getSignature();
            $document     = $this->service->findById($act->getActDocumentId());

            $checkEmployee = $this->checkEmployee($actSignature, $document);
            $checkManager  = $this->checkManager($actSignature, $document);

            $isSignatureProcessing = $act->getStatus() === StatusEnum::PROCESSING_SIGNATURE;

            if ($checkEmployee || $checkManager) {
                $this->actSignatureService->update(['id' => $actSignature->getId()], $actSignature->toArray());

                $status = null;

                if ($act->getSignOrder() === SignOrderEnum::ARBITRARY) {
                    if ($checkEmployee && ! $checkManager) {
                        $status = $isSignatureProcessing ?
                            StatusEnum::PROCESSING_SIGNATURE : StatusEnum::PENDING_COMPANY_SIGNATURE;
                    } elseif (! $checkEmployee && $checkManager) {
                        $status = StatusEnum::PENDING_EMPLOYEE_SIGNATURE;
                    } elseif ($checkEmployee && $checkManager) {
                        $status = StatusEnum::DONE;

                        dispatch(new ActStatusDoneJob($act->getId()));
                    }
                } elseif ($act->getSignOrder() === SignOrderEnum::EMPLOYEE_ONLY) {
                    if ($checkEmployee) {
                        $status = StatusEnum::DONE;

                        dispatch(new ActStatusDoneJob($act->getId()));
                    }
                }

                $act->setStatus($status);
                $dto->setAct($act);

                $this->actService->update(['id' => $act->getId()], ['status' => $status]);

                dispatch(new DownloadDocumentFileJob($act->getId()));
            }
        }

        return $next($dto);
    }

    private function checkEmployee(ActSignatureDto &$actSignature, Document $document): bool
    {
        if (! $actSignature->getEmployeeSignatureAt()) {
            if ($document->employeeSignatures()[0]->status()->value() === self::DOCUMENT_STATUS_SIGNED) {
                $actSignature->setEmployeeSignatureAt($document->employeeSignatures()[0]->signedAt()->toDateTimeString());
                $actSignature->setEmployeeSignatureId($document->employeeSignatures()[0]->id());

                return true;
            }

            return false;
        }

        return true;
    }

    private function checkManager(ActSignatureDto &$actSignature, Document $document): bool
    {
        if (! $actSignature->getManagerSignatureAt()) {
            if ($document->managerSignatures()[0]->status()->value() === self::DOCUMENT_STATUS_SIGNED) {
                $actSignature->setManagerSignatureAt($document->managerSignatures()[0]->signedAt()->toDateTimeString());
                $actSignature->setManagerSignatureId($document->managerSignatures()[0]->id());

                return true;
            }

            return false;
        }

        return true;
    }
}
