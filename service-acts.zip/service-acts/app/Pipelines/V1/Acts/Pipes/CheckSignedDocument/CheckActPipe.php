<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\CheckSignedDocument;

use Closure;
use App\Dto\DtoInterface;
use App\Services\Act\ActService;
use App\Pipelines\PipeInterface;
use App\Enums\NoName\Acts\StatusEnum;
use App\Exceptions\Pipelines\ActByDocumentException;
use App\Exceptions\Pipelines\ActStatusIsDoneException;
use App\Dto\Pipelines\Acts\CheckSignedDocumentPipelineDto;

final class CheckActPipe implements PipeInterface
{
    public function __construct(private ActService $service)
    {
    }

    public function handle(DtoInterface|CheckSignedDocumentPipelineDto $dto, Closure $next): DtoInterface
    {
        $documentId = $dto->getAct()->getActDocumentId();

        if (!$act = $this->service->get(['act_document_id' => $documentId])) {
            $dto->setAct(null);

            return $next($dto);
            // временно убрал, что бы не загружало лимиты сентри
            //throw new ActByDocumentException(trans('exceptions.8') . ' DocumentID: ' . $documentId);
        }

        if ($act->getStatus() === StatusEnum::DONE) {
            throw new ActStatusIsDoneException();
        }

        $dto->setAct($act);

        return $next($dto);
    }
}
