<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\SendExportMail;

use Closure;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use App\Services\Act\ExportService;
use App\Dto\Entities\Acts\ExportDto;
use App\Exceptions\Pipelines\ObjectNotFoundException;

final class GetExportPipe implements PipeInterface
{
    public function __construct(private ExportService $service)
    {
    }

    public function handle(DtoInterface|ExportDto $dto, Closure $next): DtoInterface
    {
        if (!$export = $this->service->get($dto->toArray(), ['files'])) {
            throw new ObjectNotFoundException();
        }

        return $next($export);
    }

}
