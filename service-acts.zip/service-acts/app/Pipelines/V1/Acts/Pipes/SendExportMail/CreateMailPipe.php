<?php

declare(strict_types=1);

namespace App\Pipelines\V1\Acts\Pipes\SendExportMail;

use Closure;
use Carbon\Carbon;
use App\Dto\DtoInterface;
use App\Pipelines\PipeInterface;
use Illuminate\Support\Collection;
use App\Services\Act\ExportService;
use App\Dto\Entities\Acts\ExportDto;
use Illuminate\Support\Facades\Mail;
use App\Dto\Entities\Storage\FileDto;
use Illuminate\Support\Facades\Storage;
use App\Enums\NoName\Exports\StatusEnum;
use App\Mail\Acts\ActsExportCompletedNotificationEmail;

final class CreateMailPipe implements PipeInterface
{
    public function __construct(private ExportService $service)
    {
    }

    public function handle(DtoInterface|ExportDto $dto, Closure $next): DtoInterface
    {
        Mail::to($dto->getEmail())
            ->queue(new ActsExportCompletedNotificationEmail($this->createTmpLinks($dto->getFiles())));

        $this->service->update(['id' => $dto->getId()], ['status' => StatusEnum::DONE]);

        return $next($dto);
    }

    private function createTmpLinks(Collection $files): array
    {
        $time = Carbon::now()->addDays((int) env('TTL_S3_TMP_LINK_DAYS'));

        return $files->map(function (FileDto $file) use ($time) {
            return Storage::disk('selectel')->temporaryUrl($file->getPath(), $time);
        })->toArray();
    }
}
