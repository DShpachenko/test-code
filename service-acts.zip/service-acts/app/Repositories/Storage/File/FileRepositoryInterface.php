<?php

declare(strict_types=1);

namespace App\Repositories\Storage\File;

use App\Dto\Entities\Storage\FileDto;

interface FileRepositoryInterface
{
    public function create(FileDto $dto): FileDto;

    public function update(array $condition, array $data): void;

    public function get(array $filters): ?FileDto;
}
