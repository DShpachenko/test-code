<?php

declare(strict_types=1);

namespace App\Repositories\Storage\File;

use App\Models\Storage\File;
use App\Dto\Entities\Storage\FileDto;

final class PgSqlFileRepositoryInterface implements FileRepositoryInterface
{
    public function __construct(private File $model)
    {
    }

    public function create(FileDto $dto): FileDto
    {
        $object = $this->model
            ->newQuery()
            ->create(array_filter($dto->toArray()));

        return FileDto::fromArray($object->toArray());
    }

    public function update(array $condition, array $data): void
    {
        $this->model
            ->newQuery()
            ->where($condition)
            ->update($data);
    }

    public function get(array $filters): ?FileDto
    {
        $object = $this->model
            ->newQuery()
            ->where($filters)
            ->first();

        return $object ? FileDto::fromArray($object->toArray()) : null;
    }
}
