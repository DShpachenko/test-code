<?php

declare(strict_types=1);

namespace App\Repositories\Taxi\Contractor;

use App\Dto\Entities\Taxi\ContractorDto;

interface ContractorRepositoryInterface
{
    public function get(array $filters): ?ContractorDto;
}
