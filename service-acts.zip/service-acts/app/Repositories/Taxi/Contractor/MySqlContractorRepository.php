<?php

declare(strict_types=1);

namespace App\Repositories\Taxi\Contractor;

use App\Models\Taxi\Contractor;
use App\Dto\Entities\Taxi\ContractorDto;

final class MySqlContractorRepository implements ContractorRepositoryInterface
{
    public function __construct(private Contractor $model)
    {
    }

    public function get(array $filters): ?ContractorDto
    {
        $object = $this->model
            ->newQuery()
            ->where($filters)
            ->first();

        return $object ? ContractorDto::fromArray($object->toArray()) : null;
    }
}
