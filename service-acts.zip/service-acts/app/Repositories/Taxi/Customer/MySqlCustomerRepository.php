<?php

declare(strict_types=1);

namespace App\Repositories\Taxi\Customer;

use App\Models\Taxi\Customer;
use App\Dto\Entities\Taxi\CustomerDto;

final class MySqlCustomerRepository implements CustomerRepositoryInterface
{
    public function __construct(private Customer $model)
    {
    }

    public function get(array $filters): ?CustomerDto
    {
        $object = $this->model
            ->newQuery()
            ->where($filters)
            ->first();

        return $object ? CustomerDto::fromArray($object->toArray()) : null;
    }
}
