<?php

declare(strict_types=1);

namespace App\Repositories\Taxi\Customer;

use App\Dto\Entities\Taxi\CustomerDto;

interface CustomerRepositoryInterface
{
    public function get(array $filters): ?CustomerDto;
}
