<?php

declare(strict_types=1);

namespace App\Repositories\Taxi\Agent;

use App\Models\Taxi\Agent;
use App\Dto\Entities\Taxi\AgentDto;

final class MySqlAgentRepository implements AgentRepositoryInterface
{
    public function __construct(private Agent $model)
    {
    }

    public function get(array $filters): ?AgentDto
    {
        $object = $this->model
            ->newQuery()
            ->where($filters)
            ->first();

        return $object ? AgentDto::fromArray($object->toArray()) : null;
    }
}
