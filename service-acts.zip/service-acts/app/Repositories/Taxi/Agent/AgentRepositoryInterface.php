<?php

declare(strict_types=1);

namespace App\Repositories\Taxi\Agent;

use App\Dto\Entities\Taxi\AgentDto;

interface AgentRepositoryInterface
{
    public function get(array $filters): ?AgentDto;
}
