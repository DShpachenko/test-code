<?php

declare(strict_types=1);

namespace App\Repositories\Taxi\Position;

use App\Dto\Entities\Taxi\PositionDto;

interface PositionRepositoryInterface
{
    public function get(array $filters): ?PositionDto;
}

