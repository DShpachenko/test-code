<?php

declare(strict_types=1);

namespace App\Repositories\Taxi\Position;

use App\Models\Taxi\Position;
use App\Dto\Entities\Taxi\PositionDto;

final class MySqlPositionRepository implements PositionRepositoryInterface
{
    public function __construct(private Position $model)
    {
    }

    public function get(array $filters): ?PositionDto
    {
        $object = $this->model
            ->newQuery()
            ->where($filters)
            ->first();

        return $object ? PositionDto::fromArray($object->toArray()) : null;
    }
}
