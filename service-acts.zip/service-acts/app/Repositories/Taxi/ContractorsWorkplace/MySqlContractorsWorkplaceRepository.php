<?php

declare(strict_types=1);

namespace App\Repositories\Taxi\ContractorsWorkplace;

use App\Models\Taxi\ContractorsWorkplaces;
use App\Dto\Entities\Taxi\ContractorsWorkplaceDto;

final class MySqlContractorsWorkplaceRepository implements ContractorsWorkplaceRepositoryInterface
{
    public function __construct(private ContractorsWorkplaces $model)
    {
    }

    public function get(array $filters): ?ContractorsWorkplaceDto
    {
        $object = $this->model
            ->newQuery()
            ->where($filters)
            ->first();

        return $object ? ContractorsWorkplaceDto::fromArray($object->toArray()) : null;
    }
}
