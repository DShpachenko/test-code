<?php

declare(strict_types=1);

namespace App\Repositories\Taxi\ContractorsWorkplace;

use App\Dto\Entities\Taxi\ContractorsWorkplaceDto;

interface ContractorsWorkplaceRepositoryInterface
{
    public function get(array $filters): ?ContractorsWorkplaceDto;
}
