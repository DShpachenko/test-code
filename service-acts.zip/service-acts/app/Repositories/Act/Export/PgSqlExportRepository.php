<?php

declare(strict_types=1);

namespace App\Repositories\Act\Export;

use App\Models\Acts\Export;
use App\Dto\Entities\Acts\ExportDto;

final class PgSqlExportRepository implements ExportRepositoryInterface
{
    public function __construct(private Export $model)
    {
    }

    public function create(ExportDto $dto): ExportDto
    {
        $object = $this->model
            ->newQuery()
            ->create(array_filter($dto->toArray()));

        return ExportDto::fromArray($object->toArray());
    }

    public function update(array $condition, array $data): void
    {
        $this->model
            ->newQuery()
            ->where($condition)
            ->update($data);
    }

    public function get(array $filters, ?array $with = null): ?ExportDto
    {
        $query = $this->model
            ->newQuery()
            ->where($filters);

        if ($with) {
            $query->with($with);
        }

        $object = $query->first();

        return $object ? ExportDto::fromArray($object->toArray()) : null;
    }

    public function getById(int $exportId, ?array $with = null): ?ExportDto
    {
        $object = $this->model
            ->newQuery()
            ->where('id', $exportId)
            ->with($with ?? [])
            ->first();

        return $object ? ExportDto::fromArray($object->toArray()) : null;
    }
}
