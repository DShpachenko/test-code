<?php

declare(strict_types=1);

namespace App\Repositories\Act\Export;

use App\Dto\Entities\Acts\ExportDto;

interface ExportRepositoryInterface
{
    public function create(ExportDto $dto): ExportDto;

    public function update(array $condition, array $data): void;

    public function get(array $filters, ?array $with): ?ExportDto;

    public function getById(int $exportId, ?array $with = null): ?ExportDto;
}
