<?php

declare(strict_types=1);

namespace App\Repositories\Act\ActPosition;

use App\Dto\Entities\Acts\ActPositionDto;

interface ActPositionRepositoryInterface
{
    public function create(ActPositionDto $dto): ActPositionDto;

    public function list(array $filters): array;

    public function delete(array $filters): void;
}
