<?php

declare(strict_types=1);

namespace App\Repositories\Act\ActPosition;

use App\Dto\Entities\Acts\ActPositionDto;
use App\Models\Acts\ActPosition;

final class PgSqlActPositionRepository implements ActPositionRepositoryInterface
{
    public function __construct(private ActPosition $model)
    {
    }

    public function create(ActPositionDto $dto): ActPositionDto
    {
        $object = $this->model
            ->newQuery()
            ->create($dto->toArray());

        return ActPositionDto::fromArray($object->toArray());
    }

    public function list(array $filters): array
    {
        $rows = $this->model
            ->newQuery()
            ->where($filters)
            ->orderBy('id')
            ->get()
            ->toArray();

        return array_map(function (array $row) {
            return ActPositionDto::fromArray($row);
        }, $rows);
    }

    public function delete(array $filters): void
    {
        $this->model
            ->newQuery()
            ->where($filters)
            ->delete();
    }
}
