<?php

declare(strict_types=1);

namespace App\Repositories\Act\Act;

use App\Models\Acts\Act;
use App\Dto\Entities\Acts\ActDto;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use App\Enums\NoName\Acts\StatusEnum;
use Illuminate\Database\Eloquent\Builder;
use App\Dto\Entities\Acts\ActAllByFiltersDto;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

final class PgSqlActRepository implements ActRepositoryInterface
{
    public function __construct(private Act $model)
    {
    }

    public function create(ActDto $dto): ActDto
    {
        $object = $this->model
            ->newQuery()
            ->create($dto->toArray());

        return ActDto::fromArray($object->toArray());
    }

    public function update(array $condition, array $data): void
    {
        $this->model
            ->newQuery()
            ->where($condition)
            ->update($data);
    }

    public function updateByIds(array $ids, array $data): int
    {
        return $this->model
            ->newQuery()
            ->whereIn('acts.id', $ids)
            ->update($data);
    }

    public function get(array $filters, array $with = []): ?ActDto
    {
        $object = $this->model
            ->newQuery()
            ->where($filters)
            ->with($with)
            ->first();

        return $object ? ActDto::fromArray($object->toArray()) : null;
    }

    public function list(array $filters, array $with = []): ?Collection
    {
        $rows = $this->model
            ->newQuery()
            ->where($filters)
            ->with($with)
            ->get()
            ->toArray();

        return $rows ? Collection::make($rows)->map(function (array $row) {
            return ActDto::fromArray($row);
        }) : null;
    }

    public function delete(array $filters): void
    {
        $this->model
            ->newQuery()
            ->where($filters)
            ->delete();
    }

    public function getMaxActNumber(int $companyId, string $type = null): int
    {
        return $this->model
                ->newQuery()
                ->where('company_id', $companyId)
                ->when($type, function (Builder $query, string $type) {
                    $query->where('type', $type);
                })
                ->max('number') ?? 0;
    }

    public function allByFilters(ActAllByFiltersDto $dto): LengthAwarePaginator
    {
        return $this->filtersBuilder($dto, $this->model->newQuery())
            ->with('signature')
            ->where('company_id', $dto->getCompanyId())
            ->orderByDesc('acts.id')
            ->paginate($dto->getPerPage(), ['acts.*'], 'page', $dto->getPage());
    }

    public function listByFilters(ActAllByFiltersDto $dto, array $with = []): Collection
    {
        $query = $this->filtersBuilder($dto, $this->model->newQuery());

        if (! empty($with)) {
            $query->with($with);
        }

        return $query
            ->where('company_id', $dto->getCompanyId())
            ->get();
    }

    public function getCountActsByStatuses(array $filters): array
    {
        $items = [];
        $this->model
            ->newQuery()
            ->select(['status', DB::raw('count(id) as count')])
            ->where($filters)
            ->groupBy('status')
            ->get()
            ->map(function (Act $item) use (&$items) {
                $items[$item->status] = $item->count;
            });

        return $items;
    }

    public function getCountByFilters(ActAllByFiltersDto $dto): int
    {
        return $this->filtersBuilder($dto, $this->model->newQuery())->count();
    }

    public function allByFiltersWithChunk(ActAllByFiltersDto $dto, int $count, callable $callback, array $with = []): void
    {
        $query = $this->filtersBuilder($dto, $this->model->newQuery());

        if (! empty($with)) {
            $query->with($with);
        }

        $query->chunk($count, $callback);
    }

    private function filtersBuilder(ActAllByFiltersDto $dto, Builder $query): Builder
    {
        $query
            ->select(['acts.*', 'act_signatures.act_id', 'act_signatures.manager_signature_id', 'act_signatures.employee_signature_id', 'act_signatures.manager_signature_at', 'act_signatures.employee_signature_at'])
            ->join('acts.act_signatures', 'acts.acts.id', '=', 'acts.act_signatures.act_id');

        if ($id = $dto->getId()) {
            $query->whereIn('acts.acts.id', $id);
        }

        if ($type = $dto->getType()) {
            $query->where('acts.acts.type', $type);
        }

        if ($companyId = $dto->getCompanyId()) {
            $query->where('company_id', '=', $companyId);
        }

        if ($status = $dto->getStatus()) {
            //@todo костыль со статусами, логику необходимо убрать из репозитория в сервис / пайп / команду
            // необходимо узнать от куда "ноги растут" у данной логики и зарефакторить
            // должно быть исправлено в рамках - https://NoNameteam.atlassian.net/browse/PAYMENTS-1717
            if (in_array(StatusEnum::PENDING_COMPANY_SIGNATURE, $status) && $dto->getStatusLogic()) {
                $query->whereIn('status', StatusEnum::isPendingSignature());
                $query->whereNull('acts.act_signatures.manager_signature_at');
            } else {
                $query->whereIn('status', $status);
            }
        }

        if ($name = $dto->getName()) {
            $query->where('name', 'like', '%' . $name . '%');
        }

        if ($agentId = $dto->getAgentId()) {
            $query->whereIn('agent_id', $agentId);
        }

        if ($periodFrom = $dto->getPeriodFrom()) {
            $query->where('period_from', '>=', $periodFrom);
        }

        if ($periodTo = $dto->getPeriodTo()) {
            $query->where('period_to', '<=', $periodTo);
        }

        if ($employeeContractorId = $dto->getEmployeeContractorId()) {
            $query->where('employee_contractor_id', $employeeContractorId);
        }

        if ($managerContractorId = $dto->getManagerContractorId()) {
            $query->where('manager_contractor_id', $managerContractorId);
        }

        if ($documentHash = $dto->getDocumentHash()) {
            $query->where($documentHash);
        }

        if ($agentsOrBranchOffices = $dto->getAgentsOrBranchOffices()) {
            $query->where(function(Builder $query) use ($agentsOrBranchOffices) {
                $agentIds        = $agentsOrBranchOffices['agent_ids'] ?? [];
                $branchOfficeIds = $agentsOrBranchOffices['branch_office_ids'] ?? [];

                if (!empty($agentIds)) {
                    $query->where(function(Builder $query) use ($agentIds) {
                        $query->whereIn('agent_id', $agentIds)->whereNull('branch_office_id');
                    });
                }

                if (!empty($branchOfficeIds)) {
                    $query->orWhereIn('branch_office_id', $branchOfficeIds);
                }
            });
        }

        return $query;
    }
}
