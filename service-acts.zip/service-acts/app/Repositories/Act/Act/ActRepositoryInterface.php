<?php

declare(strict_types=1);

namespace App\Repositories\Act\Act;

use App\Dto\Entities\Acts\ActDto;
use Illuminate\Support\Collection;
use App\Dto\Entities\Acts\ActAllByFiltersDto;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface ActRepositoryInterface
{
    public function create(ActDto $dto): ActDto;

    public function update(array $condition, array $data): void;

    public function updateByIds(array $ids, array $data): int;

    public function get(array $filters, array $with = []): ?ActDto;

    public function list(array $filters, array $with = []): ?Collection;

    public function listByFilters(ActAllByFiltersDto $dto): Collection;

    public function allByFilters(ActAllByFiltersDto $dto): LengthAwarePaginator;

    public function delete(array $filters): void;

    public function getMaxActNumber(int $companyId, string $type = null): int;

    public function getCountActsByStatuses(array $filters): array;

    public function getCountByFilters(ActAllByFiltersDto $dto): int;

    public function allByFiltersWithChunk(ActAllByFiltersDto $dto, int $count, callable $callback, array $with): void;
}
