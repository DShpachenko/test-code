<?php

declare(strict_types=1);

namespace App\Repositories\Act\JobType;

use App\Models\Acts\JobType;
use Illuminate\Support\Collection;
use App\Dto\Entities\Acts\JobTypeDto;

final class PgSqlJobTypeRepository implements JobTypeRepositoryInterface
{
    public function __construct(private JobType $model)
    {
    }

    public function create(JobTypeDto $dto): JobTypeDto
    {
        $object = $this->model
            ->newQuery()
            ->create($dto->toArray());

        return JobTypeDto::fromArray($object->toArray());
    }

    public function update(array $condition, array $data): void
    {
        $this->model
            ->newQuery()
            ->where($condition)
            ->update($data);
    }

    public function get(array $filters): ?JobTypeDto
    {
        $object = $this->model
            ->newQuery()
            ->where($filters)
            ->first();

        return $object ? JobTypeDto::fromArray($object->toArray()) : null;
    }

    public function list(array $filters): ?Collection
    {
        $rows = $this->model
            ->newQuery()
            ->where($filters)
            ->get()
            ->toArray();

        return $rows ? Collection::make($rows)->map(function (array $row) {
            return JobTypeDto::fromArray($row);
        }) : null;
    }

    public function delete(array $filters): void
    {
        $this->model
            ->newQuery()
            ->where($filters)
            ->delete();
    }
}
