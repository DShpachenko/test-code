<?php

declare(strict_types=1);

namespace App\Repositories\Act\JobType;

use Illuminate\Support\Collection;
use App\Dto\Entities\Acts\JobTypeDto;

interface JobTypeRepositoryInterface
{
    public function create(JobTypeDto $dto): JobTypeDto;

    public function update(array $condition, array $data): void;

    public function get(array $filters): ?JobTypeDto;

    public function list(array $filters): ?Collection;

    public function delete(array $filters): void;
}
