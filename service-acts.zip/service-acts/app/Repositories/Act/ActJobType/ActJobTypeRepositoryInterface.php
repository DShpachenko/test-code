<?php

declare(strict_types=1);

namespace App\Repositories\Act\ActJobType;

use Illuminate\Support\Collection;
use App\Dto\Entities\Acts\ActJobTypeDto;

interface ActJobTypeRepositoryInterface
{
    public function create(ActJobTypeDto $dto): ActJobTypeDto;

    public function list(array $filters): ?Collection;
}
