<?php

declare(strict_types=1);

namespace App\Repositories\Act\ActJobType;

use App\Models\Acts\ActJobType;
use Illuminate\Support\Collection;
use App\Dto\Entities\Acts\ActJobTypeDto;

final class PgSqlActJobTypeRepository implements ActJobTypeRepositoryInterface
{
    public function __construct(private ActJobType $model)
    {
    }

    public function create(ActJobTypeDto $dto): ActJobTypeDto
    {
        $object = $this->model
            ->newQuery()
            ->create($dto->toArray());

        return ActJobTypeDto::fromArray($object->toArray());
    }

    public function list(array $filters): ?Collection
    {
        $rows = $this->model
            ->newQuery()
            ->where($filters)
            ->get()
            ->toArray();

        return $rows ? Collection::make($rows)->map(function (array $row) {
            return ActJobTypeDto::fromArray($row);
        }) : null;
    }
}
