<?php

declare(strict_types=1);

namespace App\Repositories\Act\ActSignature;

use App\Dto\Entities\Acts\ActSignatureDto;

interface ActSignatureRepositoryInterface
{
    public function create(ActSignatureDto $dto): ActSignatureDto;

    public function update(array $condition, array $data): void;

    public function get(array $filters): ?ActSignatureDto;

    public function allByFiltersWithChunk(array $filters, int $count, callable $callback, array $with): void;
}
