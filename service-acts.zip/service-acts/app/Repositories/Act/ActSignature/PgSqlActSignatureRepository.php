<?php

declare(strict_types=1);

namespace App\Repositories\Act\ActSignature;

use App\Models\Acts\ActSignature;
use App\Dto\Entities\Acts\ActSignatureDto;

final class PgSqlActSignatureRepository implements ActSignatureRepositoryInterface
{
    public function __construct(private ActSignature $model)
    {
    }

    public function create(ActSignatureDto $dto): ActSignatureDto
    {
        $object = $this->model
            ->newQuery()
            ->create(array_filter($dto->toArray()));

        return ActSignatureDto::fromArray($object->toArray());
    }

    public function update(array $condition, array $data): void
    {
        $this->model
            ->newQuery()
            ->where($condition)
            ->update($data);
    }

    public function get(array $filters): ?ActSignatureDto
    {
        $object = $this->model
            ->newQuery()
            ->where($filters)
            ->first();

        return $object ? ActSignatureDto::fromArray($object->toArray()) : null;
    }

    public function allByFiltersWithChunk(array $filters, int $count, callable $callback, array $with = []): void
    {
        $this->model
            ->newQuery()
            ->where($filters)
            ->with($with)
            ->chunk($count, $callback);
    }
}
