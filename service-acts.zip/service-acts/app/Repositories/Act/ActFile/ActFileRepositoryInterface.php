<?php

declare(strict_types=1);

namespace App\Repositories\Act\ActFile;

use App\Dto\Entities\Acts\ActFileDto;

interface ActFileRepositoryInterface
{
    public function create(ActFileDto $dto): void;

    public function update(array $condition, array $data): void;

    public function get(array $filters): ?ActFileDto;

    public function delete(array $filters): void;
}
