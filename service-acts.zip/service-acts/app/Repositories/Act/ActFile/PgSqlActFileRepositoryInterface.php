<?php

declare(strict_types=1);

namespace App\Repositories\Act\ActFile;

use App\Models\Acts\ActFile;
use App\Dto\Entities\Acts\ActFileDto;

final class PgSqlActFileRepositoryInterface implements ActFileRepositoryInterface
{
    public function __construct(private ActFile $model)
    {
    }

    public function create(ActFileDto $dto): void
    {
        $this->model
            ->newQuery()
            ->insert($dto->toArray());
    }

    public function update(array $condition, array $data): void
    {
        $this->model
            ->newQuery()
            ->where($condition)
            ->update($data);
    }

    public function get(array $filters): ?ActFileDto
    {
        $object = $this->model
            ->newQuery()
            ->where($filters)
            ->first();

        return $object ? ActFileDto::fromArray($object->toArray()) : null;
    }

    public function delete(array $filters): void
    {
        $this->model
            ->newQuery()
            ->where($filters)
            ->delete();
    }
}
