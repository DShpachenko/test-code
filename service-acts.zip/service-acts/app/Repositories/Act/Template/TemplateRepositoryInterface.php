<?php

declare(strict_types=1);

namespace App\Repositories\Act\Template;

use App\Dto\Entities\Acts\TemplateListByFilterDto;
use App\Dto\Entities\Acts\TemplateDto;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

interface TemplateRepositoryInterface
{
    public function create(TemplateDto $dto): TemplateDto;

    public function list(TemplateListByFilterDto $dto): LengthAwarePaginator;

    public function get(array $filters, array $with = [], bool $withTrashed = false): ?TemplateDto;

    public function update(array $condition, array $data): void;

    public function delete(array $filters): void;
}
