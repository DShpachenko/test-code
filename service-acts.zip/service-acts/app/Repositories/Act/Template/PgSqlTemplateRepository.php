<?php

declare(strict_types=1);

namespace App\Repositories\Act\Template;

use App\Models\Acts\Template;
use App\Dto\Entities\Acts\TemplateDto;
use App\Dto\Entities\Acts\TemplateListByFilterDto;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

final class PgSqlTemplateRepository implements TemplateRepositoryInterface
{
    public function __construct(private Template $model)
    {
    }

    public function create(TemplateDto $dto): TemplateDto
    {
        $object = $this->model
            ->newQuery()
            ->create($dto->toArray());

        return TemplateDto::fromArray($object->toArray());
    }

    public function list(TemplateListByFilterDto $dto): LengthAwarePaginator
    {
        $query = $this->model
            ->newQuery();

        if ($companyId = $dto->getCompanyId()) {
            $query->where('company_id', $companyId);
        }

        if ($agentIds = $dto->getAgentIds()) {
            $query->whereIn('agent_id', $agentIds);
        }

        return $query
            ->orderByDesc('id')
            ->paginate($dto->getPerPage(), ['*'], 'page', $dto->getPage());
    }

    public function get(array $filters, array $with = [], bool $withTrashed = false): ?TemplateDto
    {
        $builder = $withTrashed ? Template::withTrashed() : $this->model;

        $object = $builder
            ->newQuery()
            ->where($filters)
            ->with($with)
            ->first();

        return $object ? TemplateDto::fromArray($object->toArray()) : null;
    }

    public function update(array $condition, array $data): void
    {
        $this->model
            ->newQuery()
            ->where($condition)
            ->update($data);
    }

    public function delete(array $filters): void
    {
        $this->model
            ->newQuery()
            ->where($filters)
            ->delete();
    }
}
