<?php

declare(strict_types=1);

namespace App\Repositories\Act\ExportFile;

use App\Dto\Entities\Acts\ExportFileDto;

interface ExportFileRepositoryInterface
{
    public function create(ExportFileDto $dto): void;

    public function get(array $filters): ?ExportFileDto;
}
