<?php

declare(strict_types=1);

namespace App\Repositories\Act\ExportFile;

use App\Dto\Entities\Acts\ExportFileDto;
use App\Models\Acts\ExportFile;

final class PgSqlExportFileRepository implements ExportFileRepositoryInterface
{
    public function __construct(private ExportFile $model)
    {
    }

    public function create(ExportFileDto $dto): void
    {
        $this->model
            ->newQuery()
            ->insert(array_filter($dto->toArray()));
    }

    public function get(array $filters): ?ExportFileDto
    {
        $object = $this->model
            ->newQuery()
            ->where($filters)
            ->first();

        return $object ? ExportFileDto::fromArray($object->toArray()) : null;
    }
}
