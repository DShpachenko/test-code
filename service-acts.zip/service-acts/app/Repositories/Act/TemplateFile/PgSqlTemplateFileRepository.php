<?php

declare(strict_types=1);

namespace App\Repositories\Act\TemplateFile;

use App\Dto\Entities\Acts\TemplateFileDto;
use App\Models\Acts\TemplateFile;

final class PgSqlTemplateFileRepository implements TemplateFileRepositoryInterface
{
    public function __construct(private TemplateFile $model)
    {
    }

    public function create(TemplateFileDto $dto): void
    {
        $this->model
            ->newQuery()
            ->insert($dto->toArray());
    }

    public function delete(array $filters): void
    {
        $this->model
            ->newQuery()
            ->where($filters)
            ->delete();
    }
}
