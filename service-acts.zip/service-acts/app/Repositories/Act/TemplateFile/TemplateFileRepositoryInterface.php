<?php

declare(strict_types=1);

namespace App\Repositories\Act\TemplateFile;

use App\Dto\Entities\Acts\TemplateFileDto;

interface TemplateFileRepositoryInterface
{
    public function create(TemplateFileDto $dto): void;

    public function delete(array $filters): void;
}
