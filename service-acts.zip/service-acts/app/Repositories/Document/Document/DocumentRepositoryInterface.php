<?php

declare(strict_types=1);

namespace App\Repositories\Document\Document;

use App\Dto\Entities\Acts\SignDataDto;
use NoName\ClientDocuments\Dto\Document;
use App\Dto\Entities\Documents\DocumentFileDto;
use NoName\ClientDocuments\Dto\CreateDocumentData;
use NoName\ClientDocuments\Dto\DocumentSignRequest;

interface DocumentRepositoryInterface
{
    public function create(CreateDocumentData $documentData): Document;

    public function findById(int $id): Document;

    public function downloadDocument(int $id): DocumentFileDto;

    public function downloadOriginDocument(int $id): DocumentFileDto;

    public function createSignRequestBySimpleSignature(SignDataDto $signDataDto): DocumentSignRequest;
}
