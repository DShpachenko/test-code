<?php

declare(strict_types=1);

namespace App\Repositories\Document\Document;

use App\Dto\Entities\Acts\SignDataDto;
use Illuminate\Support\Facades\Http;
use NoName\ClientDocuments\Dto\Document;
use NoName\ClientDocuments\Dto\DocumentSignRequest;
use NoName\ClientDocuments\Facades\Documents;
use App\Dto\Entities\Documents\DocumentFileDto;
use NoName\ClientDocuments\Dto\CreateDocumentData;

final class HttpClientDocumentRepository implements DocumentRepositoryInterface
{
    public function create(CreateDocumentData $documentData): Document
    {
        return Documents::create($documentData);
    }

    public function findById(int $id): Document
    {
        return Documents::findById($id);
    }

    public function downloadDocument(int $id): DocumentFileDto
    {
        //@todo временная реализация до решения проблемы с пакетом сервиса документов PAYMENTS-956
        $uri = rtrim(env('SERVICE_DOCUMENTS_URL'), '/') . '/internal/v2/documents/' . $id . '/preview/download';

        $response = Http::acceptJson()
                        ->timeout((int) env('SERVICE_DOCUMENTS_ACTION_VIEW_DOCUMENT_TIMEOUT'))
                        ->retry(
                            (int) env('SERVICE_DOCUMENTS_ACTION_VIEW_DOCUMENT_RETRY_TIMES'),
                            (int) env('SERVICE_DOCUMENTS_ACTION_VIEW_DOCUMENT_RETRY_SLEEP')
                        )
                        ->withHeaders(['Application-Key' => env('SERVICE_DOCUMENTS_KEY')])
                        ->get($uri)
                        ->throw();

        $name = str_replace(['filename="', '"'], '', $response->headers()['Content-Disposition'])[0];

        return new DocumentFileDto($name, $response->body());
    }

    public function downloadOriginDocument(int $id): DocumentFileDto
    {
        //@todo временная реализация до решения проблемы с пакетом сервиса документов PAYMENTS-956
        $uri = rtrim(env('SERVICE_DOCUMENTS_URL'), '/') . '/internal/v2/documents/' . $id . '/download';

        $response = Http::acceptJson()
                        ->timeout((int) env('SERVICE_DOCUMENTS_ACTION_VIEW_DOCUMENT_TIMEOUT'))
                        ->retry(
                            (int) env('SERVICE_DOCUMENTS_ACTION_VIEW_DOCUMENT_RETRY_TIMES'),
                            (int) env('SERVICE_DOCUMENTS_ACTION_VIEW_DOCUMENT_RETRY_SLEEP')
                        )
                        ->withHeaders(['Application-Key' => env('SERVICE_DOCUMENTS_KEY')])
                        ->get($uri)
                        ->throw();

        $name = str_replace(['filename="', '"'], '', $response->headers()['Content-Disposition'])[0];

        return new DocumentFileDto($name, $response->body());
    }

    public function createSignRequestBySimpleSignature(SignDataDto $signDataDto): DocumentSignRequest
    {
        return Documents::createSignRequestBySimple(
            $signDataDto->getCryptoSessionId(),
            $signDataDto->getUserId(),
            $signDataDto->getUserType(),
            $signDataDto->getCompanyId(),
            $signDataDto->getPreparedFilter()
        );
    }
}
