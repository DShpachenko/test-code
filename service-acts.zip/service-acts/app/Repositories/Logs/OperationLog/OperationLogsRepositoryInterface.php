<?php

declare(strict_types=1);

namespace App\Repositories\Logs\OperationLog;

interface OperationLogsRepositoryInterface
{
    public function create(string $action, ?int $customerId, ?int $entityId, array $info): void;
}
