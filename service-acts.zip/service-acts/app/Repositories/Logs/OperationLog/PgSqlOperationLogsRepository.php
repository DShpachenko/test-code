<?php

declare(strict_types=1);

namespace App\Repositories\Logs\OperationLog;

use App\Models\Logs\OperationLog;

final class PgSqlOperationLogsRepository implements OperationLogsRepositoryInterface
{
    public function __construct(private OperationLog $model)
    {
    }

    public function create(string $action, ?int $customerId, ?int $entityId, array $info): void
    {
        $this->model
            ->newQuery()
            ->create([
                'customer_id' => $customerId,
                'action'      => $action,
                'entity_id'   => $entityId,
                'info'        => $info,
                'created_at'  => now(),
            ]);
    }
}
