<?php

declare(strict_types=1);

namespace App\Dto\Entities\Taxi;

use App\Dto\DtoInterface;

final class PositionDto implements DtoInterface
{
    public function __construct(
        private int|null $id,
        private string|null $name
    )
    {
    }

    public static function fromArray(array $arguments): DtoInterface|PositionDto
    {
        return new self(
            $arguments['id'] ?? null,
            $arguments['name'] ?? null,
        );
    }

    public function toArray(): array
    {
        return [
            'id' => $this->id,
            'name' => $this->name,
        ];
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }
}
