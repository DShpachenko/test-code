<?php

declare(strict_types=1);

namespace App\Dto\Entities\Taxi;

use App\Dto\DtoInterface;
use Illuminate\Support\Str;

final class ContractorDto implements DtoInterface
{
    public function __construct(
        private int|null    $id,
        private int|null    $companyId,
        private int|null    $agentId,
        private string|null $lastName,
        private string|null $firstName,
        private string|null $middleName,
        private string|null $phone,
        private string|null $email,
        private string|null $inn,
        private int|null    $legalFormId,
    )
    {
    }

    public function toArray(): array
    {
        return [
            'id'            => $this->id,
            'company_id'    => $this->companyId,
            'agent_id'      => $this->agentId,
            'last_name'     => $this->lastName,
            'first_name'    => $this->firstName,
            'middle_name'   => $this->middleName,
            'phone'         => $this->phone,
            'email'         => $this->email,
            'inn'           => $this->inn,
            'legal_form_id' => $this->legalFormId,
        ];
    }

    public static function fromArray(array $arguments): DtoInterface|ContractorDto
    {
        return new self(
            $arguments['id'] ?? null,
            $arguments['company_id'] ? (int) $arguments['company_id'] : null,
            $arguments['agent_id'] ? (int) $arguments['agent_id'] : null,
            $arguments['last_name'] ?? null,
            $arguments['first_name'] ?? null,
            $arguments['middle_name'] ?? null,
            $arguments['phone'] ?? null,
            $arguments['email'] ?? null,
            $arguments['inn'] ?? null,
            $arguments['legal_form_id'] ?? null,
        );
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCompanyId(): ?int
    {
        return $this->companyId;
    }

    public function getAgentId(): ?int
    {
        return $this->agentId;
    }

    public function getFullName(): string
    {
        return $this->lastName . ' ' . $this->firstName . ' ' . $this->middleName;
    }

    public function getShortName(): string
    {
        $name = $this->lastName;

        if ($this->firstName) {
            $name .= ' ' . Str::substr($this->firstName, 0, 1) . '.';
        }

        if ($this->middleName) {
            $name .= ' ' . Str::substr($this->middleName, 0, 1) . '.';
        }

        return trim($name);

    }

    public function getInn(): ?string
    {
        return $this->inn;
    }

    public function getPhone(): ?string
    {
        return $this->phone;
    }

    public function getEmail(): ?string
    {
        return $this->email;
    }

    public function getLegalFormId(): ?int
    {
        return $this->legalFormId;
    }
}
