<?php

declare(strict_types=1);

namespace App\Dto\Entities\Taxi;

use App\Dto\DtoInterface;

final class CustomerDto implements DtoInterface
{
    public function __construct(
        private int|null    $id,
        private int|null    $companyId,
        private string|null $email,
        private string|null $phone,
        private int|null    $rootCustomerId,
        private int|null    $contractorId,
    )
    {
    }

    public function toArray(): array
    {
        return [
            'id'               => $this->id,
            'company_id'       => $this->companyId,
            'email'            => $this->email,
            'phone'            => $this->phone,
            'rootCustomerId' => $this->rootCustomerId,
            'contractor_id'    => $this->contractorId,
        ];
    }

    public static function fromArray(array $arguments): DtoInterface|CustomerDto
    {
        return new self(
            $arguments['id'] ?? null,
            $arguments['company_id'] ?? null,
            $arguments['email'] ?? null,
            $arguments['phone'] ?? null,
            $arguments['rootCustomerId'] ?? null,
            $arguments['contractor_id'] ?? null,
        );
    }

    public function getEmail(): ?string
    {
        return $this->email;
    }

    public function getPhone(): ?string
    {
        return $this->phone;
    }

    public function getRootCustomerId(): ?int
    {
        return $this->rootCustomerId;
    }

    public function getContractorId(): ?int
    {
        return $this->contractorId;
    }
}
