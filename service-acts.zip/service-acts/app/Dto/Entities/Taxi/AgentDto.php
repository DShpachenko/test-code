<?php

declare(strict_types=1);

namespace App\Dto\Entities\Taxi;

use App\Dto\DtoInterface;

final class AgentDto implements DtoInterface
{
    public function __construct(
        private int|null    $id,
        private int|null    $companyId,
        private string|null $name,
        private string|null $info,
    )
    {
    }

    public function toArray(): array
    {
        return [
            'id'         => $this->id,
            'company_id' => $this->companyId,
            'name'       => $this->name,
            'info'       => $this->info,
        ];
    }

    public static function fromArray(array $arguments): DtoInterface|AgentDto
    {
        return new self(
            $arguments['id'] ?? null,
            $arguments['company_id'] ? (int) $arguments['company_id'] : null,
            $arguments['name'] ?? null,
            $arguments['info'] ?? null,
        );
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCompanyId(): ?int
    {
        return $this->companyId;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function getInfo(): ?string
    {
        return $this->info;
    }

    public function getInfoDto(): ?AgentInfoDto
    {
        return AgentInfoDto::fromArray(json_decode($this->info, true));
    }
}
