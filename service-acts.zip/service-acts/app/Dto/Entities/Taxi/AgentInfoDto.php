<?php

declare(strict_types=1);

namespace App\Dto\Entities\Taxi;

use App\Dto\DtoInterface;
use Carbon\Carbon;

final class AgentInfoDto implements DtoInterface
{
    public function __construct(
        private string|null $inn,
        private string|null $ogrn,
        private string|null $ogrnDate,
        private string|null $address,
        private string|null $city,
        private string|null $kpp,
        private string|null $managementName,
        private string|null $managementPost,
        private string|null $individualEntrepreneurSurname,
        private string|null $individualEntrepreneurName,
        private string|null $individualEntrepreneurPatronymic,
    )
    {
    }

    public function toArray(): array
    {
        return [
            'inn'                                => $this->inn,
            'ogrn'                               => $this->ogrn,
            'address'                            => $this->address,
            'city'                               => $this->city,
            'kpp'                                => $this->kpp,
            'ogrn_date'                          => $this->ogrnDate,
            'management_name'                    => $this->managementName,
            'management_post'                    => $this->managementPost,
            'individual_entrepreneur_surname'    => $this->individualEntrepreneurSurname,
            'individual_entrepreneur_name'       => $this->individualEntrepreneurName,
            'individual_entrepreneur_patronymic' => $this->individualEntrepreneurPatronymic,
        ];
    }

    public static function fromArray(array $arguments): DtoInterface|AgentInfoDto
    {
        return new self(
            $arguments['inn'] ?? null,
            $arguments['ogrn'] ?? null,
            $arguments['ogrn_date'] ?? null,
            $arguments['address'] ?? null,
            $arguments['city'] ?? null,
            $arguments['kpp'] ?? null,
            $arguments['management_name'] ?? null,
            $arguments['management_post'] ?? null,
            $arguments['individual_entrepreneur_surname'] ?? null,
            $arguments['individual_entrepreneur_name'] ?? null,
            $arguments['individual_entrepreneur_patronymic'] ?? null,
        );
    }

    public function getInn(): ?string
    {
        return $this->inn;
    }

    public function getOgrn(): ?string
    {
        return $this->ogrn;
    }

    public function getOgrnDate(string $format = 'Y-m-d H:i:s'): ?string
    {
        return $this->ogrnDate ? Carbon::parse($this->ogrnDate)->format($format) : null;
    }

    public function getCity(): ?string
    {
        return $this->city;
    }

    public function getAddress(): ?string
    {
        return $this->address;
    }

    public function getKpp(): ?string
    {
        return $this->kpp;
    }

    public function getManagementName(): ?string
    {
        return $this->managementName;
    }

    public function getManagementPost(): ?string
    {
        return $this->managementPost;
    }

    public function getIndividualEntrepreneurSurname(): ?string
    {
        return $this->individualEntrepreneurSurname;
    }

    public function getIndividualEntrepreneurName(): ?string
    {
        return $this->individualEntrepreneurName;
    }

    public function getIndividualEntrepreneurPatronymic(): ?string
    {
        return $this->individualEntrepreneurPatronymic;
    }
}
