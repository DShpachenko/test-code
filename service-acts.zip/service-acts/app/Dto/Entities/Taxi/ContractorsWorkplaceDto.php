<?php

declare(strict_types=1);

namespace App\Dto\Entities\Taxi;

use App\Dto\DtoInterface;

final class ContractorsWorkplaceDto implements DtoInterface
{
    public function __construct(
        private int|null         $contractorId,
        private int|null         $companyId,
        private int|null         $agentId,
        private int|null         $positionId,
        private PositionDto|null $position,
    )
    {
    }

    public function toArray(): array
    {
        return [
            'contractor_id' => $this->contractorId,
            'company_id'    => $this->companyId,
            'agent_id'      => $this->agentId,
            'position'      => $this->position?->toArray(),
        ];
    }

    public static function fromArray(array $arguments): DtoInterface|ContractorsWorkplaceDto
    {
        return new self(
            $arguments['contractor_id'] ? (int) $arguments['contractor_id'] : null,
            $arguments['company_id'] ? (int) $arguments['company_id'] : null,
            $arguments['agent_id'] ? (int) $arguments['agent_id'] : null,
            isset($arguments['position_id']) ? (int) $arguments['position_id'] : null,
            isset($arguments['position']) ? PositionDto::fromArray($arguments['position']) : null,
        );
    }

    public function getPositionId(): ?int
    {
        return $this->positionId;
    }

    public function getPosition(): ?PositionDto
    {
        return $this->position;
    }

    public function setPosition(?PositionDto $position): void
    {
        $this->position = $position;
    }
}
