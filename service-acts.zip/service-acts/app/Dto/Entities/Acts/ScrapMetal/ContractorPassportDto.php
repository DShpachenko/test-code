<?php

declare(strict_types=1);

namespace App\Dto\Entities\Acts\ScrapMetal;

use App\Dto\DtoInterface;

final class ContractorPassportDto implements DtoInterface
{
    public function __construct(
        private string $fullNumber,
        private string $issueDate,
        private string $lastName,
        private string $firstName,
        private ?string $middleName,
        private string $registrationAddress,
    ) {}

    public function toArray(): array
    {
        return [
            'full_number'          => $this->fullNumber,
            'issue_date'           => $this->issueDate,
            'last_name'            => $this->lastName,
            'first_name'           => $this->firstName,
            'middle_name'          => $this->middleName,
            'registration_address' => $this->registrationAddress,
        ];
    }

    public static function fromArray(array $arguments): ContractorPassportDto
    {
        return new self(
            $arguments['full_number'],
            $arguments['issue_date'],
            $arguments['last_name'],
            $arguments['first_name'],
            $arguments['middle_name'],
            $arguments['registration_address'],
        );
    }

    public function getFullNumber(): string
    {
        return $this->fullNumber;
    }

    public function getIssueDate(): string
    {
        return $this->issueDate;
    }

    public function getFullName(): string
    {
        return implode(' ', array_filter([$this->lastName, $this->firstName, $this->middleName]));
    }

    public function getRegistrationAddress(): string
    {
        return $this->registrationAddress;
    }

    public function getLastName(): string
    {
        return $this->lastName;
    }

    public function getFirstName(): string
    {
        return $this->firstName;
    }

    public function getMiddleName(): ?string
    {
        return $this->middleName;
    }
}
