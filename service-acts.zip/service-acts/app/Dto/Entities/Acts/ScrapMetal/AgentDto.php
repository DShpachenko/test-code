<?php

declare(strict_types=1);

namespace App\Dto\Entities\Acts\ScrapMetal;

use App\Dto\DtoInterface;

final class AgentDto implements DtoInterface
{
    public function __construct(
        private string $name,
        private string $address,
        private string $okpo,
        private ?string $branchOfficeAddress,
    ) {}

    public function toArray(): array
    {
        return [
            'name'    => $this->name,
            'address' => $this->address,
            'okpo'    => $this->okpo,
            'branch_office' => [
                'address' => $this->branchOfficeAddress,
            ],
        ];
    }

    public static function fromArray(array $arguments): AgentDto
    {
        return new self(
            $arguments['name'],
            $arguments['address'],
            $arguments['okpo'],
            $arguments['branch_office']['address'],
        );
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getAddress(): string
    {
        return $this->address;
    }

    public function getOkpo(): string
    {
        return $this->okpo;
    }

    public function getBranchOfficeAddress(): ?string
    {
        return $this->branchOfficeAddress;
    }
}
