<?php

declare(strict_types=1);

namespace App\Dto\Entities\Acts\ScrapMetal;

use App\Dto\DtoInterface;

final class ActInfoDto implements DtoInterface
{
    public function __construct(
        private ContractorDto $contractor,
        private AgentDto $agent,
        private ?TransportDto $transport,
    ) {}

    public function toArray(): array
    {
        return [
            'scrap_metal' => [
                'contractor' => $this->contractor->toArray(),
                'agent'      => $this->agent->toArray(),
                'transport'  => $this->transport?->toArray(),
            ],
        ];
    }

    public static function fromArray(array $arguments): ActInfoDto
    {
        $info = $arguments['scrap_metal'];

        return new self(
            ContractorDto::fromArray($info['contractor']),
            AgentDto::fromArray($info['agent']),
            empty($info['transport']) ? null : TransportDto::fromArray($info['transport'])
        );
    }

    public function getContractor(): ContractorDto
    {
        return $this->contractor;
    }

    public function getAgent(): AgentDto
    {
        return $this->agent;
    }

    public function getTransport(): ?TransportDto
    {
        return $this->transport;
    }
}
