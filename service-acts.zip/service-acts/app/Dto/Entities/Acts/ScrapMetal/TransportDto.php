<?php

declare(strict_types=1);

namespace App\Dto\Entities\Acts\ScrapMetal;

use App\Dto\DtoInterface;

final class TransportDto implements DtoInterface
{
    public function __construct(
        private ?string $mark,
        private ?string $number,
    ) {}

    public function toArray(): array
    {
        return [
            'mark'   => $this->mark,
            'number' => $this->number,
        ];
    }

    public static function fromArray(array $arguments): TransportDto
    {
        return new self(
            $arguments['mark'] ?? null,
            $arguments['number'] ?? null,
        );
    }

    public function getMark(): ?string
    {
        return $this->mark;
    }

    public function getNumber(): ?string
    {
        return $this->number;
    }
}
