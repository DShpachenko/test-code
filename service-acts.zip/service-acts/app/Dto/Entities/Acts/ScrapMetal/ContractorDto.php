<?php

declare(strict_types=1);

namespace App\Dto\Entities\Acts\ScrapMetal;

use App\Dto\DtoInterface;

final class ContractorDto implements DtoInterface
{
    public function __construct(
        protected ?string $inn,
        protected ContractorPassportDto $passport,
    ) {}

    public function toArray(): array
    {
        return [
            'inn'      => $this->inn,
            'passport' => $this->passport->toArray(),
        ];
    }

    public static function fromArray(array $arguments): ContractorDto
    {
        return new self(
            $arguments['inn'] ?? null,
            ContractorPassportDto::fromArray($arguments['passport']),
        );
    }

    public function getPassport(): ContractorPassportDto
    {
        return $this->passport;
    }

    public function getInn(): ?string
    {
        return $this->inn;
    }
}
