<?php

declare(strict_types=1);

namespace App\Dto\Entities\Acts;

use App\Dto\DtoInterface;

final class SignDataDto implements DtoInterface
{
    private array               $actIds    = [];
    private ?ActAllByFiltersDto $filterDto = null;
    private array               $preparedFilter;

    public function __construct(
        private string|null $cryptoSessionId,
        private int|null    $companyId,
        private array|null  $agentIds,
        private int|null    $userId,
        private string|null $userType,
    )
    {
    }

    public function toArray(): array
    {
        return [
            'company_id' => $this->companyId,
            'agent_ids'  => $this->agentIds,
            'user_id'    => $this->userId,
            'user_type'  => $this->userType,
            'act_ids'    => $this->actIds,
        ];
    }

    public static function fromArray(array $arguments): DtoInterface|SignDataDto
    {
        return new self(
            $arguments['crypto_session_id'] ?? null,
            $arguments['company_id'] ?? null,
            $arguments['agent_ids'] ?? null,
            $arguments['user_id'] ?? null,
            $arguments['user_type'] ?? null,

        );
    }

    public function getActIds(): array
    {
        return $this->actIds ?? [];
    }

    public function setActIds(array $actIds): void
    {
        $this->actIds = $actIds;
    }

    public function filterDto(): ?ActAllByFiltersDto
    {
        return $this->filterDto;
    }

    public function setFilterDto(ActAllByFiltersDto $filterDto): void
    {
        $this->filterDto = $filterDto;
    }

    public function resetFilterDto(): void
    {
        $this->filterDto = null;
    }

    public function setAgentIds(array $agentIds): void
    {
        $this->agentIds = $agentIds;
    }

    public function getAgentIds(): array
    {
        return $this->agentIds ?? [];
    }

    public function getCryptoSessionId(): ?string
    {
        return $this->cryptoSessionId;
    }

    public function getUserId(): ?int
    {
        return $this->userId;
    }

    public function getUserType(): ?string
    {
        return $this->userType;
    }

    public function getCompanyId(): ?int
    {
        return $this->companyId;
    }

    public function getPreparedFilter(): array
    {
        return $this->preparedFilter;
    }

    public function setPreparedFilter(array $filter): void
    {
        $this->preparedFilter = $filter;
    }
}
