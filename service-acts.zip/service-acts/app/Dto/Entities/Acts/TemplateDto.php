<?php

declare(strict_types=1);

namespace App\Dto\Entities\Acts;

use App\Dto\DtoInterface;
use App\Dto\Entities\Storage\FileDto;

final class TemplateDto implements DtoInterface
{
    public function __construct(
        private int|null     $id,
        private int|null     $companyId,
        private int|null     $agentId,
        private string|null  $name,
        private string|null  $sign_order,
        private int|null     $managerContractorId,
        private string|null  $createdAt,
        private string|null  $updatedAt,
        private FileDto|null $file,
    )
    {
    }

    public function toArray(): array
    {
        return [
            'id'                    => $this->id,
            'company_id'            => $this->companyId,
            'agent_id'              => $this->agentId,
            'name'                  => $this->name,
            'sign_order'            => $this->sign_order,
            'manager_contractor_id' => $this->managerContractorId,
            'created_at'            => $this->createdAt,
            'updated_at'            => $this->updatedAt,
            'file'                  => $this->file?->toArray(),
        ];
    }

    public static function fromArray(array $arguments): self
    {
        return new self(
            isset($arguments['id']) ? intval($arguments['id']) : null,
            isset($arguments['company_id']) ? intval($arguments['company_id']) : null,
            isset($arguments['agent_id']) ? intval($arguments['agent_id']) : null,
            $arguments['name'] ?? null,
            $arguments['sign_order'] ?? null,
            isset($arguments['manager_contractor_id']) ? intval($arguments['manager_contractor_id']) : null,
            $arguments['created_at'] ?? null,
            $arguments['updated_at'] ?? null,
            isset($arguments['file']) ? FileDto::fromArray($arguments['file']) : null,
        );
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function setId(?int $id): void
    {
        $this->id = $id;
    }

    public function getCompanyId(): ?int
    {
        return $this->companyId;
    }

    public function setCompanyId(?int $companyId): void
    {
        $this->companyId = $companyId;
    }

    public function getAgentId(): ?int
    {
        return $this->agentId;
    }

    public function setAgentId(?int $agentId): void
    {
        $this->agentId = $agentId;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(?string $name): void
    {
        $this->name = $name;
    }

    public function getSignOrder(): ?string
    {
        return $this->sign_order;
    }

    public function setSignOrder(?string $sign_order): void
    {
        $this->sign_order = $sign_order;
    }

    public function getManagerContractorId(): ?int
    {
        return $this->managerContractorId;
    }

    public function setManagerContractorId(?int $managerContractorId): void
    {
        $this->managerContractorId = $managerContractorId;
    }

    public function getCreatedAt(): ?string
    {
        return $this->createdAt;
    }

    public function setCreatedAt(?string $createdAt): void
    {
        $this->createdAt = $createdAt;
    }

    public function getUpdatedAt(): ?string
    {
        return $this->updatedAt;
    }

    public function setUpdatedAt(?string $updatedAt): void
    {
        $this->updatedAt = $updatedAt;
    }

    public function getFile(): ?FileDto
    {
        return $this->file;
    }
}
