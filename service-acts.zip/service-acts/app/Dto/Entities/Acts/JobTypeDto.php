<?php

declare(strict_types=1);

namespace App\Dto\Entities\Acts;

use App\Dto\DtoInterface;
use App\Enums\NoName\JobTypes\MeasureEnum;

final class JobTypeDto implements DtoInterface
{
    public function __construct(
        private int|null    $id,
        private int|null    $companyId,
        private string|null $name,
        private float|null  $price,
        private int|null    $measureId,
        private string|null $createdAt,
        private string|null $updatedAt
    )
    {
    }

    public function toArray(): array
    {
        return [
            'id'         => $this->id,
            'company_id' => $this->companyId,
            'name'       => $this->name,
            'price'      => $this->price,
            'measure_id' => $this->measureId,
            'created_at' => $this->createdAt,
            'updated_at' => $this->updatedAt,
        ];
    }

    public function toCustomArray(): array
    {
        return [
            'id'      => $this->id,
            'name'    => $this->name,
            'price'   => $this->price,
            'measure' => [
                'value' => $this->measureId,
                'title' => $this->getMeasureTitle(),
            ],
        ];
    }

    public static function fromArray(array $arguments): self
    {
        return new self(
            $arguments['id'] ?? null,
            $arguments['company_id'] ?? null,
            $arguments['name'] ?? null,
            $arguments['price'] ?? null,
            $arguments['measure_id'] ?? null,
            $arguments['created_at'] ?? null,
            $arguments['updated_at'] ?? null,
        );
    }

    public function setId(int $id): void
    {
        $this->id = $id;
    }

    public function getCompanyId(): ?int
    {
        return $this->companyId;
    }

    public function getMeasureTitle(): ?string
    {
        return $this->measureId ? MeasureEnum::title($this->measureId) : null;
    }
}
