<?php

declare(strict_types=1);

namespace App\Dto\Entities\Acts;

use App\Dto\DtoInterface;
use Illuminate\Support\Collection;
use App\Dto\Entities\Storage\FileDto;

final class ExportDto implements DtoInterface
{
    public function __construct(
        private int|null                    $id,
        private string|null                 $type,
        private int|null                    $companyId,
        private int|null                    $authorId,
        private ActAllByFiltersDto|null     $filters,
        private string|null                 $email,
        private string|null                 $status,
        private ExportStatusDetailsDto|null $statusDetails,
        private string|null                 $createdAt,
        private string|null                 $updatedAt,
        private Collection|null             $files,
    )
    {
    }

    public function toArray(): array
    {
        return [
            'id'             => $this->id,
            'type'           => $this->type,
            'author_id'      => $this->authorId,
            'company_id'     => $this->companyId,
            'filters'        => $this->filters?->toArray(),
            'email'          => $this->email,
            'status'         => $this->status,
            'status_details' => $this->statusDetails?->toArray(),
            'created_at'     => $this->createdAt,
            'updated_at'     => $this->updatedAt,
            'files'          => $this->files,
        ];
    }

    public static function fromArray(array $arguments): DtoInterface|ExportDto
    {
        return new self(
            $arguments['id'] ?? null,
            $arguments['type'] ?? null,
            $arguments['company_id'] ?? null,
            $arguments['author_id'] ?? null,
            isset($arguments['filters']) ? ActAllByFiltersDto::fromArray($arguments['filters']) : null,
            $arguments['email'] ?? null,
            $arguments['status'] ?? null,
            isset($arguments['status_details']) ? ExportStatusDetailsDto::fromArray($arguments['status_details']) : null,
            $arguments['created_at'] ?? null,
            $arguments['updated_at'] ?? null,
            isset($arguments['files']) ? Collection::make($arguments['files'])->map(function (array $file) {
                return FileDto::fromArray($file);
            }) : null,
        );
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function setId(?int $id): void
    {
        $this->id = $id;
    }

    public function getType(): ?string
    {
        return $this->type;
    }

    public function setType(?string $type): ExportDto
    {
        $this->type = $type;

        return $this;
    }

    public function getAuthorId(): ?int
    {
        return $this->authorId;
    }

    public function setAuthorId(?int $authorId): void
    {
        $this->authorId = $authorId;
    }

    public function getFilters(): ?ActAllByFiltersDto
    {
        return $this->filters;
    }

    public function setFilters(?ActAllByFiltersDto $filters): void
    {
        $this->filters = $filters;
    }

    public function getEmail(): ?string
    {
        return $this->email;
    }

    public function setEmail(?string $email): void
    {
        $this->email = $email;
    }

    public function getStatus(): ?string
    {
        return $this->status;
    }

    public function setStatus(?string $status): void
    {
        $this->status = $status;
    }

    public function getFiles(): ?Collection
    {
        return $this->files;
    }

    public function setFiles(?Collection $files): void
    {
        $this->files = $files;
    }

    public function getStatusDetails(): ?ExportStatusDetailsDto
    {
        return $this->statusDetails;
    }

    public function setStatusDetails(?ExportStatusDetailsDto $statusDetails): void
    {
        $this->statusDetails = $statusDetails;
    }
}
