<?php

declare(strict_types=1);

namespace App\Dto\Entities\Acts;

use App\Dto\DtoInterface;

final class TemplateFileDto implements DtoInterface
{
    public function __construct(
        private int|null    $templateId,
        private int|null    $fileId,
        private string|null $createdAt
    )
    {
    }

    public function toArray(): array
    {
        return [
            'template_id' => $this->templateId,
            'file_id'     => $this->fileId,
            'created_at'  => $this->createdAt,
        ];
    }

    public static function fromArray(array $arguments): TemplateFileDto
    {
        return new self(
            $arguments['template_id'] ?? null,
            $arguments['file_id'] ?? null,
            $arguments['created_at'] ?? null,
        );
    }
}
