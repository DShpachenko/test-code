<?php

declare(strict_types=1);

namespace App\Dto\Entities\Acts;

use App\Dto\DtoInterface;

final class ActJobTypeDto implements DtoInterface
{
    public function __construct(
        private int|null    $id,
        private int|null    $actId,
        private string|null $name,
        private float|null  $price,
        private int|null    $count,
        private int|null    $measureId,
        private string|null $createdAt,
        private string|null $updatedAt
    )
    {
    }

    public function toArray(): array
    {
        return [
            'id'         => $this->id,
            'act_id'     => $this->actId,
            'name'       => $this->name,
            'price'      => $this->price,
            'count'      => $this->count,
            'measure_id' => $this->measureId,
            'created_at' => $this->createdAt,
            'updated_at' => $this->updatedAt,
        ];
    }

    public static function fromArray(array $arguments): self
    {
        return new self(
            $arguments['id'] ?? null,
            $arguments['act_id'] ?? null,
            $arguments['name'] ?? null,
            $arguments['price'] ?? null,
            $arguments['count'] ?? null,
            $arguments['measure_id'] ?? null,
            $arguments['created_at'] ?? null,
            $arguments['updated_at'] ?? null,
        );
    }

    public static function fromArrayItems(array $array): array
    {
        return array_map(function (array $item) {
            return self::fromArray($item);
        }, $array);
    }

    public function setId(?int $id): void
    {
        $this->id = $id;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function getPrice(): ?float
    {
        return $this->price;
    }

    public function getCount(): ?int
    {
        return $this->count;
    }

    public function setActId(?int $actId): void
    {
        $this->actId = $actId;
    }

    public function getMeasureId(): ?int
    {
        return $this->measureId;
    }

    /**
     * format: Y-m-d H:i:s
     *
     * @param string|null $createdAt
     *
     * @return void
     */
    public function setCreatedAt(?string $createdAt): void
    {
        $this->createdAt = $createdAt;
    }

    /**
     * format: Y-m-d H:i:s
     *
     * @param string|null $updatedAt
     *
     * @return void
     */
    public function setUpdatedAt(?string $updatedAt): void
    {
        $this->updatedAt = $updatedAt;
    }
}
