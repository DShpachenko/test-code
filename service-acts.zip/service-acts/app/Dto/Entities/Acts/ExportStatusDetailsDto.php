<?php

declare(strict_types=1);

namespace App\Dto\Entities\Acts;

use App\Dto\DtoInterface;

final class ExportStatusDetailsDto implements DtoInterface
{
    public function __construct(
        private string|null $description,      // дополнительная информация для отображения пользователю
        private string|null $details           // дополнительная информация для дебага, например детали ошибки
    )
    {
    }

    public function toArray(): array
    {
        return [
            'description' => $this->description,
            'details'     => $this->details,
        ];
    }

    public static function fromArray(array $arguments): self
    {
        return new self(
            $arguments['description'] ?? null,
            $arguments['details'] ?? null,
        );
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }
}
