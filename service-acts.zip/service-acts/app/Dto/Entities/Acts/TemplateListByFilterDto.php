<?php

declare(strict_types=1);

namespace App\Dto\Entities\Acts;

use App\Dto\DtoInterface;

final class TemplateListByFilterDto implements DtoInterface
{
    public function __construct(
        private int|null   $companyId,
        private int|null   $page,
        private int|null   $perPage,
        private array|null $agentIds,
    )
    {
    }

    public static function fromArray(array $arguments): DtoInterface|TemplateListByFilterDto
    {
        return new self(
            $arguments['company_id'] ?? null,
            $arguments['page'] ?? null,
            $arguments['per_page'] ?? null,
            $arguments['agent_ids'] ?? null,
        );
    }

    public function toArray(): array
    {
        return [
            'company_id' => $this->companyId,
            'page'       => $this->page,
            'per_page'   => $this->perPage,
            'agent_ids'  => $this->agentIds,
        ];
    }

    public function getCompanyId(): ?int
    {
        return $this->companyId;
    }

    public function setCompanyId(?int $companyId): void
    {
        $this->companyId = $companyId;
    }

    public function getPage(): ?int
    {
        return $this->page;
    }

    public function setPage(?int $page): void
    {
        $this->page = $page;
    }

    public function getPerPage(): ?int
    {
        return $this->perPage;
    }

    public function setPerPage(?int $perPage): void
    {
        $this->perPage = $perPage;
    }

    public function getAgentIds(): ?array
    {
        return $this->agentIds;
    }
}
