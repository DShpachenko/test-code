<?php

declare(strict_types=1);

namespace App\Dto\Entities\Acts;

use App\Dto\DtoInterface;

final class ActSignatureDto implements DtoInterface
{
    public function __construct(
        private int|null    $id,
        private int|null    $actId,
        private int|null    $managerSignatureId,
        private int|null    $employeeSignatureId,
        private string|null $managerSignatureAt,
        private string|null $employeeSignatureAt,
        private string|null $createdAt,
        private string|null $updatedAt
    )
    {
    }

    public function toArray(): array
    {
        return [
            'id'                    => $this->id,
            'act_id'                => $this->actId,
            'manager_signature_id'  => $this->managerSignatureId,
            'employee_signature_id' => $this->employeeSignatureId,
            'manager_signature_at'  => $this->managerSignatureAt,
            'employee_signature_at' => $this->employeeSignatureAt,
            'created_at'            => $this->createdAt,
            'updated_at'            => $this->updatedAt,
        ];
    }

    public static function fromArray(array $arguments): DtoInterface|ActSignatureDto
    {
        return new self(
            $arguments['id'] ?? null,
            $arguments['act_id'] ?? null,
            $arguments['manager_signature_id'] ?? null,
            $arguments['employee_signature_id'] ?? null,
            $arguments['manager_signature_at'] ?? null,
            $arguments['employee_signature_at'] ?? null,
            $arguments['created_at'] ?? null,
            $arguments['updated_at'] ?? null,
        );
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function setId(?int $id): void
    {
        $this->id = $id;
    }

    public function getActId(): ?int
    {
        return $this->actId;
    }

    public function setManagerSignatureId(?int $managerSignatureId): void
    {
        $this->managerSignatureId = $managerSignatureId;
    }

    public function getManagerSignatureId(): ?int
    {
        return $this->managerSignatureId;
    }

    public function getManagerSignatureAt(): ?string
    {
        return $this->managerSignatureAt;
    }

    public function setManagerSignatureAt(?string $managerSignatureAt): void
    {
        $this->managerSignatureAt = $managerSignatureAt;
    }

    public function getEmployeeSignatureId(): ?int
    {
        return $this->employeeSignatureId;
    }

    public function setEmployeeSignatureId(?int $employeeSignatureId): void
    {
        $this->employeeSignatureId = $employeeSignatureId;
    }

    public function getEmployeeSignatureAt(): ?string
    {
        return $this->employeeSignatureAt;
    }

    public function setEmployeeSignatureAt(?string $employeeSignatureAt): void
    {
        $this->employeeSignatureAt = $employeeSignatureAt;
    }
}
