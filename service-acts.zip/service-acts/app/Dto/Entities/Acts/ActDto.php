<?php

declare(strict_types=1);

namespace App\Dto\Entities\Acts;

use App\Dto\Entities\Acts\ScrapMetal\ActInfoDto;
use App\Dto\Entities\Storage\FileDto;
use App\Enums\NoName\Acts\TypeEnum;
use App\Exceptions\Pipelines\UnsupportedActTypeForGettingScrapMetalInfoException;
use Carbon\Carbon;
use App\Dto\DtoInterface;

final class ActDto implements DtoInterface
{
    public function __construct(
        private int|null             $id,
        private int|null             $authorId,
        private int|null             $managerContractorId,
        private int|null             $companyId,
        private int|null             $agentId,
        private int|null             $employeeContractorId,
        private int|null             $sourceDocumentId,
        private int|null             $actDocumentId,
        private int|null             $paymentId,
        private int|null             $number,
        private string|null          $name,
        private string|null          $description,
        private float|null           $totalPrice,
        private string|null          $periodFrom,
        private string|null          $periodTo,
        private string|null          $status,
        private array|null           $info,
        private string|null          $createdAt,
        private string|null          $updatedAt,
        private ActSignatureDto|null $signature,
        private FileDto|null         $file,
        private array|null           $files,
        private string|null          $documentHash,
        private int|null             $templateId,
        private string|null          $signOrder,
        private ?string              $type,
        private ?int                 $branchOfficeId,
        private ?string              $externalNumber,
    )
    {
        if ($this->type === null) {
            // по умолчанию тип "акты выполненных работ",
            // для обратной совместимости после введения типов
            $this->type = TypeEnum::JOB;
        }
    }

    public function toArray(): array
    {
        return [
            'id'                     => $this->id,
            'author_id'              => $this->authorId,
            'manager_contractor_id'  => $this->managerContractorId,
            'company_id'             => $this->companyId,
            'agent_id'               => $this->agentId,
            'employee_contractor_id' => $this->employeeContractorId,
            'source_document_id'     => $this->sourceDocumentId,
            'act_document_id'        => $this->actDocumentId,
            'payment_id'             => $this->paymentId,
            'number'                 => $this->number,
            'name'                   => $this->name,
            'description'            => $this->description,
            'total_price'            => $this->totalPrice,
            'period_from'            => $this->periodFrom,
            'period_to'              => $this->periodTo,
            'status'                 => $this->status,
            'info'                   => $this->info,
            'created_at'             => $this->createdAt,
            'updated_at'             => $this->updatedAt,
            'signature'              => $this->signature?->toArray(),
            'file'                   => $this->file?->toArray(),
            'files'                  => $this->files
                ? array_map(static fn(FileDto $file) => $file->toArray(), $this->files)
                : null,
            'document_hash'          => $this->documentHash,
            'template_id'            => $this->templateId,
            'sign_order'             => $this->signOrder,
            'type'                   => $this->type,
            'branch_office_id'       => $this->branchOfficeId,
            'external_number'        => $this->externalNumber,
        ];
    }

    public static function fromArray(array $arguments): self
    {
        return new self(
            $arguments['id'] ?? null,
            $arguments['author_id'] ?? null,
            $arguments['manager_contractor_id'] ?? null,
            $arguments['company_id'] ?? null,
            $arguments['agent_id'] ?? null,
            $arguments['employee_contractor_id'] ?? null,
            $arguments['source_document_id'] ?? null,
            $arguments['act_document_id'] ?? null,
            $arguments['payment_id'] ?? null,
            $arguments['number'] ?? null,
            $arguments['name'] ?? null,
            $arguments['description'] ?? null,
            isset($arguments['total_price']) ? (float) $arguments['total_price'] : null,
            $arguments['period_from'] ?? null,
            $arguments['period_to'] ?? null,
            $arguments['status'] ?? null,
            $arguments['info'] ?? null,
            $arguments['created_at'] ?? null,
            $arguments['updated_at'] ?? null,
            isset($arguments['signature']) ? ActSignatureDto::fromArray($arguments['signature']) : null,
            isset($arguments['file']) ? FileDto::fromArray($arguments['file']) : null,
            isset($arguments['files']) && is_array($arguments['files'])
                    ? array_map(static fn(array $fields) => FileDto::fromArray($fields), $arguments['files'])
                    : null,
            $arguments['document_hash'] ?? null,
            $arguments['template_id'] ?? null,
            $arguments['sign_order'] ?? null,
            $arguments['type'] ?? null,
            $arguments['branch_office_id'] ?? null,
            $arguments['external_number'] ?? null,
        );
    }

    public function setId(?int $id): void
    {
        $this->id = $id;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getAuthorId(): ?int
    {
        return $this->authorId;
    }

    public function getType(): ?string
    {
        return $this->type;
    }

    public function setType(?string $type): void
    {
        $this->type = $type;
    }

    public function getManagerContractorId(): ?int
    {
        return $this->managerContractorId;
    }

    public function setManagerContractorId(?int $value): void
    {
        $this->managerContractorId = $value;
    }

    public function getSourceDocumentId(): ?int
    {
        return $this->sourceDocumentId;
    }

    public function getActDocumentId(): ?int
    {
        return $this->actDocumentId;
    }

    public function setActDocumentId(?int $actDocumentId): void
    {
        $this->actDocumentId = $actDocumentId;
    }

    public function getCompanyId(): ?int
    {
        return $this->companyId;
    }

    public function getAgentId(): ?int
    {
        return $this->agentId;
    }

    public function getEmployeeContractorId(): ?int
    {
        return $this->employeeContractorId;
    }

    public function getTotalPrice(): ?float
    {
        return $this->totalPrice;
    }

    public function setTotalPrice(?float $totalPrice): void
    {
        $this->totalPrice = $totalPrice;
    }

    public function setStatus(string $status): void
    {
        $this->status = $status;
    }

    public function getNumber(): ?int
    {
        return $this->number;
    }

    public function setNumber(int $number): void
    {
        $this->number = $number;
    }

    public function setInfo(array $info): void
    {
        $this->info = $info;
    }

    public function getInfo(): ?array
    {
        return $this->info;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(?string $name): void
    {
        $this->name = $name;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function getPeriodFrom(string $format = 'Y-m-d H:i:s'): ?string
    {
        return $this->periodFrom ? Carbon::parse($this->periodFrom)->format($format) : null;
    }

    public function getPeriodTo(string $format = 'Y-m-d H:i:s'): ?string
    {
        return $this->periodTo ? Carbon::parse($this->periodTo)->format($format) : null;
    }

    public function getCreatedAt(string $format = 'Y-m-d H:i:s'): ?string
    {
        return $this->createdAt ? Carbon::parse($this->createdAt)->format($format) : null;
    }

    public function setCreatedAt(?string $createdAt): void
    {
        $this->createdAt = $createdAt;
    }

    public function getUpdatedAt(): ?string
    {
        return $this->updatedAt;
    }

    public function setUpdatedAt(?string $updatedAt): void
    {
        $this->updatedAt = $updatedAt;
    }

    public function getStatus(): ?string
    {
        return $this->status;
    }

    public function getSignature(): ?ActSignatureDto
    {
        return $this->signature;
    }

    public function getPaymentId(): ?int
    {
        return $this->paymentId;
    }

    public function setPaymentId(?int $paymentId): void
    {
        $this->paymentId = $paymentId;
    }

    public function getFile(): ?FileDto
    {
        return $this->file;
    }

    public function getFiles(): ?array
    {
        return $this->files;
    }

    public function getDocumentHash(): ?string
    {
        return $this->documentHash;
    }

    public function setDocumentHash(?string $documentHash): void
    {
        $this->documentHash = $documentHash;
    }

    public function setTemplateId(?int $templateId): void
    {
        $this->templateId = $templateId;
    }

    public function getTemplateId(): ?int
    {
        return $this->templateId;
    }

    public function getSignOrder(): ?string
    {
        return $this->signOrder;
    }

    public function setSignOrder(?string $signOrder): void
    {
        $this->signOrder = $signOrder;
    }

    /**
     * Геттеры и сеттеры для актов типа TypeEnum::SCRAP_METAL
     */

    /**
     * Дата акта
     */
    public function getDate(string $format = 'Y-m-d H:i:s'): string
    {
        return Carbon::parse($this->periodFrom)->format($format);
    }

    /**
     * ID филиала
     */
    public function getBranchOfficeId(): ?int
    {
        return $this->branchOfficeId;
    }

    /**
     * Номер акта, заполняемый клиентом
     */
    public function getExternalNumber(): ?string
    {
        return $this->externalNumber;
    }

    /**
     * Дополнительная информация приемо-сдаточного акта (ПСА)
     */
    public function getScrapMetalInfo(): ActInfoDto
    {
        if ($this->type !== TypeEnum::SCRAP_METAL) {
            throw new UnsupportedActTypeForGettingScrapMetalInfoException();
        }
        return ActInfoDto::fromArray($this->info);
    }
}
