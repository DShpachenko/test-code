<?php

declare(strict_types=1);

namespace App\Dto\Entities\Acts;

use App\Dto\DtoInterface;
use App\Helpers\DtoHelper;

final class ActAllByFiltersDto implements DtoInterface
{
    public function __construct(
        private array|null  $id,
        private int|null    $companyId,
        private array|null  $status,
        private int|null    $page,
        private int|null    $perPage,
        private int|null    $employeeContractorId,
        private string|null $name,
        private array|null  $agentId,
        private string|null $periodFrom,
        private string|null $periodTo,
        private int|null    $managerContractorId,
        private array|null  $documentHash,
        private string|null $type,
        private array|null  $agentsOrBranchOffices,
        private bool        $statusLogic = true,
    )
    {
    }

    public static function fromArray(array $arguments): DtoInterface|ActAllByFiltersDto
    {
        return new self(
            $arguments['id'] ?? null,
            $arguments['company_id'] ?? null,
            DtoHelper::valueToArrayOrNull('status', $arguments),
            $arguments['page'] ?? null,
            $arguments['per_page'] ?? null,
            $arguments['employee_contractor_id'] ?? null,
            $arguments['name'] ?? null,
            $arguments['agent_id'] ?? null,
            $arguments['period_from'] ?? null,
            $arguments['period_to'] ?? null,
            $arguments['manager_contractor_id'] ?? null,
            $arguments['document_hash'] ?? null,
            $arguments['type'] ?? null,
            $arguments['agents_or_branch_offices'] ?? null,
            $arguments['status_logic'] ?? true,
        );
    }

    public function toArray(): array
    {
        return [
            'id'                       => $this->id,
            'company_id'               => $this->companyId,
            'status'                   => $this->status,
            'page'                     => $this->page,
            'per_page'                 => $this->perPage,
            'employee_contractor_id'   => $this->employeeContractorId,
            'name'                     => $this->name,
            'agent_id'                 => $this->agentId,
            'period_from'              => $this->periodFrom,
            'period_to'                => $this->periodTo,
            'manager_contractor_id'    => $this->managerContractorId,
            'document_hash'            => $this->documentHash,
            'status_logic'             => $this->statusLogic,
            'type'                     => $this->type,
            'agents_or_branch_offices' => $this->agentsOrBranchOffices,
        ];
    }

    public function getId(): ?array
    {
        return $this->id;
    }

    public function getCompanyId(): ?int
    {
        return $this->companyId;
    }

    public function getStatus(): ?array
    {
        return $this->status;
    }

    public function setStatus(array $statuses): void
    {
        $this->status = $statuses;
    }

    public function getPage(): ?int
    {
        return $this->page;
    }

    public function setPage(int $page): void
    {
        $this->page = $page;
    }

    public function getPerPage(): ?int
    {
        return $this->perPage;
    }

    public function setPerPage(int $perPage): void
    {
        $this->perPage = $perPage;
    }

    public function getEmployeeContractorId(): ?int
    {
        return $this->employeeContractorId;
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function getAgentId(): ?array
    {
        return $this->agentId;
    }

    public function getPeriodFrom(): ?string
    {
        return $this->periodFrom;
    }

    public function getPeriodTo(): ?string
    {
        return $this->periodTo;
    }

    public function getManagerContractorId(): ?int
    {
        return $this->managerContractorId;
    }

    public function getDocumentHash(): ?array
    {
        return $this->documentHash;
    }

    public function getStatusLogic(): bool
    {
        return $this->statusLogic;
    }

    public function getType(): ?string
    {
        return $this->type;
    }

    /**
     * @return array{agent_ids: array<int>, branch_office_ids: array<int>}|null
     */
    public function getAgentsOrBranchOffices(): ?array
    {
        return $this->agentsOrBranchOffices;
    }
}
