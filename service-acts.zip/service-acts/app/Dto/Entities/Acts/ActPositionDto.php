<?php

declare(strict_types=1);

namespace App\Dto\Entities\Acts;

use App\Dto\DtoInterface;

final class ActPositionDto implements DtoInterface
{
    public function __construct(
        private ?int $id,
        private ?int $actId,
        private string $name,
        private ?string $type,
        private int $measureUnitId,
        private ?float $impurityPercent,
        private float $value,
        private ?float $tareWeight,
        private float $price,
        private float $amount,
        private ?float $clearValue,
        private ?string $createdAt,
        private ?string $updatedAt,
    ) {}

    public function toArray(): array
    {
        return [
            'id'               => $this->id,
            'act_id'           => $this->actId,
            'name'             => $this->name,
            'type'             => $this->type,
            'measure_unit_id'  => $this->measureUnitId,
            'impurity_percent' => $this->impurityPercent,
            'value'            => $this->value,
            'tare_weight'      => $this->tareWeight,
            'price'            => $this->price,
            'amount'           => $this->amount,
            'clear_value'      => $this->getClearValue(),
        ];
    }

    public static function fromArray(array $arguments): ActPositionDto
    {
        return new self(
            $arguments['id'] ?? null,
            $arguments['act_id'] ?? null,
            $arguments['name'],
            $arguments['type'],
            $arguments['measure_unit_id'],
            $arguments['impurity_percent'],
            $arguments['value'],
            $arguments['tare_weight'],
            $arguments['price'],
            $arguments['amount'],
            $arguments['clear_value'] ?? null,
            $arguments['created_at'] ?? null,
            $arguments['updated_at'] ?? null,
        );
    }

    public function getActId(): ?int
    {
        return $this->actId;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function setActId(?int $actId): self
    {
        $this->actId = $actId;

        return $this;
    }

    public function getName(): string
    {
        return $this->name;
    }

    public function getType(): ?string
    {
        return $this->type;
    }

    public function getMeasureUnitId(): int
    {
        return $this->measureUnitId;
    }

    public function getImpurityPercent(): ?float
    {
        return $this->impurityPercent;
    }

    public function getValue(): float
    {
        return $this->value;
    }

    public function getClearValue(): float
    {
        if (!empty($this->clearValue)) {
            return $this->clearValue;
        }

        /**
         * Нетто, тонн - рассчитывается по формуле
         * Нетто = (Брутто - Вес тары) * (1 - Засор / 100)
         */

        $impurityPercent = $this->getImpurityPercent() ?? 0.0;

        // определение веса грязного лома без тары
        $net = $this->getValue() - ($this->getTareWeight() ?? 0.0);

        if ($net < 0) {
            $net = 0;
        }

        // определение веса чистого лома
        return round($net * (1 - ($impurityPercent / 100)), 6);
    }

    public function getTareWeight(): ?float
    {
        return $this->tareWeight;
    }

    public function getPrice(): float
    {
        return $this->price;
    }

    public function getAmount(): float
    {
        return $this->amount;
    }

    public function getCreatedAt(): ?string
    {
        return $this->createdAt;
    }

    public function getUpdatedAt(): ?string
    {
        return $this->updatedAt;
    }
}
