<?php

declare(strict_types=1);

namespace App\Dto\Entities\Acts;

use App\Dto\DtoInterface;

final class ActFileDto implements DtoInterface
{
    public function __construct(
        private ?int    $actId,
        private ?int    $fileId,
        private ?string $createdAt
    )
    {
    }

    public function toArray(): array
    {
        return [
            'act_id'     => $this->actId,
            'file_id'    => $this->fileId,
            'created_at' => $this->createdAt,
        ];
    }

    public static function fromArray(array $arguments): ActFileDto
    {
        return new self(
            $arguments['act_id'] ?? null,
            $arguments['file_id'] ?? null,
            $arguments['created_at'] ?? null,
        );
    }
}
