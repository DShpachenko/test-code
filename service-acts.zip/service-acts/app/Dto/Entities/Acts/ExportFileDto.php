<?php

declare(strict_types=1);

namespace App\Dto\Entities\Acts;

use App\Dto\DtoInterface;

final class ExportFileDto implements DtoInterface
{
    public function __construct(
        private int|null $id,
        private int|null $exportId,
        private int|null $fileId
    )
    {
    }

    public function toArray(): array
    {
        return [
            'id'        => $this->id,
            'export_id' => $this->exportId,
            'file_id'   => $this->fileId,
        ];
    }

    public static function fromArray(array $arguments): self
    {
        return new self(
            $arguments['id'] ?? null,
            $arguments['export_id'] ?? null,
            $arguments['file_id'] ?? null,
        );
    }

    public function setId(int $id): self
    {
        $this->id = $id;

        return $this;
    }

    public function getId(): ?int
    {
        return $this->id;
    }
}
