<?php

declare(strict_types=1);

namespace App\Dto\Entities\Acts;

use App\Dto\DtoInterface;

final class SignNotificationDto implements DtoInterface
{
    public function __construct(
        private int|null $contractorId,
        private int|null $actId,
    )
    {
    }

    public function toArray(): array
    {
        return [
            'contractor_id' => $this->contractorId,
            'act_id'        => $this->actId,
        ];
    }

    public static function fromArray(array $arguments): DtoInterface|SignNotificationDto
    {
        return new self(
            $arguments['contractor_id'] ?? null,
            $arguments['act_id'] ?? null,
        );
    }

    public function getContractorId(): ?int
    {
        return $this->contractorId;
    }

    public function getActId(): ?int
    {
        return $this->actId;
    }
}
