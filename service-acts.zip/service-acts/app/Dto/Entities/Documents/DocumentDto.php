<?php

declare(strict_types=1);

namespace App\Dto\Entities\Documents;

use Carbon\Carbon;
use App\Dto\DtoInterface;

final class DocumentDto implements DtoInterface
{
    public function __construct(
        private int|null        $id,
        private string|null     $name,
        private string|int|null $number,
        private string|null     $manualNumber,
        private string|null     $date,
    )
    {
    }

    public function toArray(): array
    {
        return [
            'id'            => $this->id,
            'name'          => $this->name,
            'number'        => $this->number,
            'manual_number' => $this->manualNumber,
            'date'          => $this->date,
        ];
    }

    public static function fromArray(array $arguments): DtoInterface|DocumentDto
    {
        return new self(
            $arguments['id'] ?? null,
            $arguments['name'] ?? null,
            $arguments['number'] ?? null,
            $arguments['manual_number'] ?? null,
            $arguments['date'] ?? null,
        );
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function getNumber(): null|int|string
    {
        return $this->number;
    }

    public function getManualNumber(): null|string
    {
        return $this->manualNumber;
    }

    public function getDate(string $format = 'Y-m-d H:i:s'): ?string
    {
        return $this->date ? Carbon::parse($this->date)->format($format) : null;
    }
}
