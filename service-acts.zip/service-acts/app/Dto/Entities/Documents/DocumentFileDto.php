<?php

declare(strict_types=1);

namespace App\Dto\Entities\Documents;

use App\Dto\DtoInterface;

final class DocumentFileDto implements DtoInterface
{
    public function __construct(
        private ?string $name,
        private ?string $content
    )
    {
    }

    public function toArray(): array
    {
        return [
            'name'    => $this->name,
            'content' => $this->content,
        ];
    }

    public static function fromArray(array $arguments): DocumentFileDto
    {
        return new self(
            $arguments['name'] ?? null,
            $arguments['content'] ?? null,
        );
    }

    public function getName(): ?string
    {
        return $this->name;
    }

    public function getContent(): ?string
    {
        return $this->content;
    }
}
