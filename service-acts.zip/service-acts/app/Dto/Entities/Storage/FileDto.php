<?php

declare(strict_types=1);

namespace App\Dto\Entities\Storage;

use App\Dto\DtoInterface;

final class FileDto implements DtoInterface
{
    public function __construct(
        private ?int    $id,
        private ?string $type,
        private ?string $path,
        private ?string $createdAt,
        private ?string $updatedAt
    )
    {
    }

    public function toArray(): array
    {
        return [
            'id'         => $this->id,
            'type'       => $this->type,
            'path'       => $this->path,
            'created_at' => $this->createdAt,
            'updated_at' => $this->updatedAt,
        ];
    }

    public static function fromArray(array $arguments): FileDto
    {
        return new self(
            $arguments['id'] ?? null,
            $arguments['type'] ?? null,
            $arguments['path'] ?? null,
            $arguments['created_at'] ?? null,
            $arguments['updated_at'] ?? null,
        );
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function setId(?int $id): void
    {
        $this->id = $id;
    }

    public function getType(): ?string
    {
        return $this->type;
    }

    public function setType(?string $type): void
    {
        $this->type = $type;
    }

    public function getPath(): ?string
    {
        return $this->path;
    }

    public function setPath(?string $path): void
    {
        $this->path = $path;
    }
}
