<?php

declare(strict_types=1);

namespace App\Dto\Common;

use App\Dto\DtoInterface;

final class FileDataDto implements DtoInterface
{
    public function __construct(
        private ?string $content,
        private ?string $extension,
        private ?string $path,
    )
    {
    }

    public function toArray(): array
    {
        return [
            'content'   => $this->content,
            'extension' => $this->extension,
            'path'      => $this->path,
        ];
    }

    public static function fromArray(array $arguments): FileDataDto
    {
        return new self(
            $arguments['content'] ?? null,
            $arguments['extension'] ?? null,
            $arguments['path'] ?? null,
        );
    }

    public function getContent(): ?string
    {
        return $this->content;
    }

    public function getExtension(): ?string
    {
        return $this->extension;
    }

    public function getPath(): ?string
    {
        return $this->path;
    }
}
