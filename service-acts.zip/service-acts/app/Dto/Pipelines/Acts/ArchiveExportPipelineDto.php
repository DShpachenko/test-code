<?php

declare(strict_types=1);

namespace App\Dto\Pipelines\Acts;

use App\Dto\DtoInterface;
use App\Dto\Entities\Acts\ExportDto;
use App\Dto\Entities\Storage\FileDto;

final class ArchiveExportPipelineDto implements DtoInterface
{
    public function __construct(
        private ExportDto|null $export,
        private string|null    $tmpDirectoryPath,
        private array          $actTmpDirectoryPaths = [],
        private array          $actTmpArchives = [],
        private array          $actS3Archives = [],
    )
    {
    }

    public function toArray(): array
    {
        return [
            'export'                  => $this->export->toArray(),
            'tmp_directory_path'      => $this->tmpDirectoryPath,
            'act_tmp_directory_paths' => $this->actTmpDirectoryPaths,
            'act_tmp_archives'        => $this->actTmpArchives,
            'act_s3_archives'         => $this->actTmpArchives,
        ];
    }

    public static function fromArray(array $arguments): self
    {
        return new self(
            isset($arguments['export']) ? ExportDto::fromArray($arguments['export']) : null,
            $arguments['tmp_directory_path'] ?? null,
            $arguments['act_directory_paths'] ?? [],
            $arguments['act_archive_tmp_paths'] ?? [],
            $arguments['act_archive_s3_paths'] ?? [],
        );
    }

    public function getExport(): ?ExportDto
    {
        return $this->export;
    }

    public function getTmpDirectoryPath(): string
    {
        return $this->tmpDirectoryPath;
    }

    public function setTmpDirectoryPath(string $tmpDirectoryPath): self
    {
        $this->tmpDirectoryPath = $tmpDirectoryPath;

        return $this;
    }

    public function addActDirectoryTmpPath(string $directoryPath): self
    {
        $this->actTmpDirectoryPaths[] = $directoryPath;

        return $this;
    }

    public function getActTmpDirectoryPaths(): array
    {
        return $this->actTmpDirectoryPaths;
    }

    public function addTmpArchive(FileDto $archive): self
    {
        $this->actTmpArchives[] = $archive;

        return $this;
    }

    public function getTmpArchives(): array
    {
        return $this->actTmpArchives;
    }

    /**
     * @return FileDto[]
     */
    public function getS3Archives(): array
    {
        return $this->actS3Archives;
    }

    public function setS3Archives(array $archives): self
    {
        $this->actS3Archives = $archives;

        return $this;
    }
}
