<?php

declare(strict_types=1);

namespace App\Dto\Pipelines\Acts;

use App\Dto\DtoInterface;
use App\Dto\Entities\Acts\ActDto;
use App\Dto\Entities\Taxi\AgentDto;
use App\Dto\Entities\Taxi\CustomerDto;
use App\Dto\Entities\Acts\ActJobTypeDto;
use App\Dto\Entities\Taxi\ContractorDto;
use App\Dto\Entities\Documents\DocumentDto;
use App\Dto\Entities\Taxi\ContractorsWorkplaceDto;

final class GetActPipelineDto implements DtoInterface
{
    public function __construct(
        private ActDto|null                  $act,
        private array|null                   $jobTypes,
        private AgentDto|null                $agent,
        private DocumentDto|null             $document,
        private ContractorDto|null           $employeeContractor,
        private ContractorDto|null           $managerContractor,
        private ContractorsWorkplaceDto|null $employeeContractorsWorkplace,
        private ContractorsWorkplaceDto|null $managerContractorsWorkplace,
        private CustomerDto|null             $customer
    )
    {
    }

    public function toArray(): array
    {
        return [
            'act'                            => $this->act?->toArray(),
            'job_types'                      => array_map(function (ActJobTypeDto $dto) {
                return $dto->toArray();
            }, $this->jobTypes),
            'agent'                          => $this->agent?->toArray(),
            'document'                       => $this->document?->toArray(),
            'employee_contractor'            => $this->employeeContractor?->toArray(),
            'manager_contractor'             => $this->managerContractor?->toArray(),
            'employee_contractors_workplace' => $this->employeeContractorsWorkplace?->toArray(),
            'manager_contractors_workplace'  => $this->managerContractorsWorkplace?->toArray(),
            'customer'                       => $this->customer,
        ];
    }

    public static function fromArray(array $arguments): DtoInterface|GetActPipelineDto
    {
        return new self(
            $arguments['act'] ?? null,
            isset($arguments['job_types']) ? array_map(function (array $item) {
                return ActJobTypeDto::fromArray($item);
            }, $arguments['job_types']) : null,
            isset($arguments['agent']) ? AgentDto::fromArray($arguments['agent']) : null,
            isset($arguments['document']) ? DocumentDto::fromArray($arguments['document']) : null,
            isset($arguments['employee_contractor']) ? ContractorDto::fromArray($arguments['employee_contractor']) : null,
            isset($arguments['manager_contractor']) ? ContractorDto::fromArray($arguments['manager_contractor']) : null,
            isset($arguments['employee_contractors_workplace']) ? ContractorsWorkplaceDto::fromArray($arguments['employee_contractors_workplace']) : null,
            isset($arguments['manager_contractors_workplace']) ? ContractorsWorkplaceDto::fromArray($arguments['manager_contractors_workplace']) : null,
            $arguments['customer'] ?? null,
        );
    }

    public function getAct(): ?ActDto
    {
        return $this->act;
    }

    public function setAct(?ActDto $actDto): void
    {
        $this->act = $actDto;
    }

    public function getJobTypes(): ?array
    {
        return $this->jobTypes;
    }

    public function setJobTypes(array $jobTypes): void
    {
        $this->jobTypes = $jobTypes;
    }

    public function getAgent(): ?AgentDto
    {
        return $this->agent;
    }

    public function setAgent(?AgentDto $agent): void
    {
        $this->agent = $agent;
    }

    public function getDocument(): ?DocumentDto
    {
        return $this->document;
    }

    public function setDocument(?DocumentDto $document): void
    {
        $this->document = $document;
    }

    public function getEmployeeContractor(): ?ContractorDto
    {
        return $this->employeeContractor;
    }

    public function setEmployeeContractor(?ContractorDto $contractor): void
    {
        $this->employeeContractor = $contractor;
    }

    public function getManagerContractor(): ?ContractorDto
    {
        return $this->managerContractor;
    }

    public function setManagerContractor(?ContractorDto $contractor): void
    {
        $this->managerContractor = $contractor;
    }

    public function getEmployeeContractorsWorkplace(): ?ContractorsWorkplaceDto
    {
        return $this->employeeContractorsWorkplace;
    }

    public function setEmployeeContractorsWorkplace(?ContractorsWorkplaceDto $contractorsWorkplace): void
    {
        $this->employeeContractorsWorkplace = $contractorsWorkplace;
    }

    public function getManagerContractorsWorkplace(): ?ContractorsWorkplaceDto
    {
        return $this->managerContractorsWorkplace;
    }

    public function setManagerContractorsWorkplace(?ContractorsWorkplaceDto $contractorsWorkplace): void
    {
        $this->managerContractorsWorkplace = $contractorsWorkplace;
    }

    public function getCustomer(): ?CustomerDto
    {
        return $this->customer;
    }

    public function setCustomer(CustomerDto $customer): void
    {
        $this->customer = $customer;
    }
}
