<?php

declare(strict_types=1);

namespace App\Dto\Pipelines\Acts;

use App\Dto\DtoInterface;
use App\Dto\Entities\Acts\ActDto;
use NoName\ClientDocuments\Dto\Document;

final class CheckSignedDocumentPipelineDto implements DtoInterface
{
    public function __construct(
        private ActDto|null $act,
        private Document|null $document
    )
    {
    }

    public function toArray(): array
    {
        return [
            'act' => $this->act,
            'document' => $this->document,
        ];
    }

    public static function fromArray(array $arguments): CheckSignedDocumentPipelineDto
    {
        return new self(
            $arguments['act'] ?? null,
            $arguments['document'] ?? null,
        );
    }

    public function getAct(): ?ActDto
    {
        return $this->act;
    }

    public function setAct(?ActDto $act): void
    {
        $this->act = $act;
    }

    public function getDocument(): ?Document
    {
        return $this->document;
    }

    public function setDocument(?Document $document): void
    {
        $this->document = $document;
    }
}
