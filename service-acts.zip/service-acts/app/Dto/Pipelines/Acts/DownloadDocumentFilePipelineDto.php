<?php

declare(strict_types=1);

namespace App\Dto\Pipelines\Acts;

use App\Dto\DtoInterface;
use App\Dto\Entities\Acts\ActDto;
use App\Dto\Entities\Storage\FileDto;
use App\Dto\Entities\Documents\DocumentFileDto;

final class DownloadDocumentFilePipelineDto implements DtoInterface
{
    public function __construct(
        private ?ActDto          $act,
        private ?DocumentFileDto $documentFile,
        private ?FileDto         $file
    )
    {
    }

    public function toArray(): array
    {
        return [
            'act'           => $this->act,
            'document_file' => $this->documentFile,
            'file'          => $this->file,
        ];
    }

    public static function fromArray(array $arguments): DownloadDocumentFilePipelineDto
    {
        return new DownloadDocumentFilePipelineDto(
            $arguments['act'] ?? null,
            $arguments['document_file'] ?? null,
            $arguments['file'] ?? null
        );
    }

    public function getAct(): ?ActDto
    {
        return $this->act;
    }

    public function setAct(?ActDto $actDto): void
    {
        $this->act = $actDto;
    }

    public function getDocumentFile(): ?DocumentFileDto
    {
        return $this->documentFile;
    }

    public function setDocumentFile(?DocumentFileDto $documentFileDto): void
    {
        $this->documentFile = $documentFileDto;
    }

    public function getFile(): ?FileDto
    {
        return $this->file;
    }

    public function setFile(?FileDto $file): void
    {
        $this->file = $file;
    }
}
