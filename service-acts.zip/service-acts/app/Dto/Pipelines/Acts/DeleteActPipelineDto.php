<?php

declare(strict_types=1);

namespace App\Dto\Pipelines\Acts;

use App\Dto\DtoInterface;
use App\Dto\Entities\Acts\ActDto;

final class DeleteActPipelineDto implements DtoInterface
{
    public function __construct(
        private ActDto|null $act,
        private int|null    $userId,
    )
    {
    }

    public function toArray(): array
    {
        return [
            'act'     => $this->act?->toArray(),
            'user_id' => $this->userId,
        ];
    }

    public static function fromArray(array $arguments): DtoInterface|DeleteActPipelineDto
    {
        return new self(
            $arguments['act'] ?? null,
            $arguments['user_id'] ?? null,
        );
    }

    public function getAct(): ?ActDto
    {
        return $this->act;
    }

    public function setAct(?ActDto $actDto): void
    {
        $this->act = $actDto;
    }

    public function getUserId(): ?int
    {
        return $this->userId;
    }

    public function setUserId(?int $userId): void
    {
        $this->userId = $userId;
    }
}
