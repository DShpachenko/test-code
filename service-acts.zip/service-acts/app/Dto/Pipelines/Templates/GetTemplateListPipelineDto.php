<?php

declare(strict_types=1);

namespace App\Dto\Pipelines\Templates;

use App\Dto\DtoInterface;
use App\Dto\Entities\Acts\TemplateListByFilterDto;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

final class GetTemplateListPipelineDto implements DtoInterface
{
    /**
     * @param GetTemplatePipelineDto[]|null $items
     */
    public function __construct(
        private TemplateListByFilterDto|null $filter,
        private LengthAwarePaginator|null    $paginator,
        private array|null                   $items,
    )
    {
    }

    public function toArray(): array
    {
        return [
            'filter'    => $this->filter?->toArray(),
            'paginator' => $this->paginator?->toArray(),
            'items'     => $this->items
                ? array_map(fn(GetTemplatePipelineDto $item) => $item->toArray(), $this->items)
                : null,
        ];
    }

    public static function fromArray(array $arguments): DtoInterface|GetTemplateListPipelineDto
    {
        return new self(
            $arguments['filter'] ?? null,
            $arguments['paginator'] ?? null,
            $arguments['items'] ?? null,
        );
    }

    public function getFilter(): ?TemplateListByFilterDto
    {
        return $this->filter;
    }

    public function setFilter(?TemplateListByFilterDto $filter): void
    {
        $this->filter = $filter;
    }

    public function getPaginator(): ?LengthAwarePaginator
    {
        return $this->paginator;
    }

    public function setPaginator(?LengthAwarePaginator $paginator): void
    {
        $this->paginator = $paginator;
    }

    /**
     * @return GetTemplatePipelineDto[]|null
     */
    public function getItems(): ?array
    {
        return $this->items;
    }

    /**
     * @param GetTemplatePipelineDto[]|null $items
     */
    public function setItems(?array $items): void
    {
        $this->items = $items;
    }
}
