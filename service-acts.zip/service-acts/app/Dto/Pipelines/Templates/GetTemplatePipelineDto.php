<?php

declare(strict_types=1);

namespace App\Dto\Pipelines\Templates;

use App\Dto\DtoInterface;
use App\Dto\Entities\Taxi\AgentDto;
use App\Dto\Entities\Acts\TemplateDto;
use App\Dto\Entities\Taxi\ContractorDto;

final class GetTemplatePipelineDto implements DtoInterface
{
    public function __construct(
        private TemplateDto|null    $template,
        private AgentDto|null       $agent,
        private ContractorDto|null  $managerContractor,
    )
    {
    }

    public function toArray(): array
    {
        return [
            'template'           => $this->template?->toArray(),
            'agent'              => $this->agent?->toArray(),
            'manager_contractor' => $this->managerContractor?->toArray(),
        ];
    }

    public static function fromArray(array $arguments): DtoInterface|GetTemplatePipelineDto
    {
        return new self(
            $arguments['template'] ?? null,
            $arguments['agent'] ?? null,
            $arguments['manager_contractor'] ?? null
        );
    }

    public function getTemplate(): ?TemplateDto
    {
        return $this->template;
    }

    public function setTemplate(?TemplateDto $template): void
    {
        $this->template = $template;
    }

    public function getAgent(): ?AgentDto
    {
        return $this->agent;
    }

    public function setAgent(?AgentDto $agent): void
    {
        $this->agent = $agent;
    }

    public function getManagerContractor(): ?ContractorDto
    {
        return $this->managerContractor;
    }

    public function setManagerContractor(?ContractorDto $managerContractor): void
    {
        $this->managerContractor = $managerContractor;
    }
}
