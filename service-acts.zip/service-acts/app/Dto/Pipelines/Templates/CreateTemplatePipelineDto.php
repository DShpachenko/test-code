<?php

declare(strict_types=1);

namespace App\Dto\Pipelines\Templates;

use App\Dto\Common\FileDataDto;
use App\Dto\DtoInterface;
use App\Dto\Entities\Acts\TemplateDto;
use App\Dto\Entities\Storage\FileDto as StorageFileDto;
use App\Dto\Entities\Taxi\AgentDto;
use App\Dto\Entities\Taxi\ContractorDto;

final class CreateTemplatePipelineDto implements DtoInterface
{
    public function __construct(
        private TemplateDto|null    $template,
        private AgentDto|null       $agent,
        private ContractorDto|null  $managerContractor,
        private FileDataDto|null    $fileData,
        private StorageFileDto|null $storageFile,
    )
    {
    }

    public function toArray(): array
    {
        return [
            'template'           => $this->template?->toArray(),
            'agent'              => $this->agent?->toArray(),
            'manager_contractor' => $this->managerContractor?->toArray(),
            'file_data'          => $this->fileData?->toArray(),
            'storage_file'       => $this->storageFile?->toArray(),
        ];
    }

    public static function fromArray(array $arguments): DtoInterface|CreateTemplatePipelineDto
    {
        return new self(
            $arguments['template'] ?? null,
            $arguments['agent'] ?? null,
            $arguments['manager_contractor'] ?? null,
            $arguments['file_data'] ?? null,
            $arguments['storage_file'] ?? null,
        );
    }

    public function getTemplate(): ?TemplateDto
    {
        return $this->template;
    }

    public function setTemplate(?TemplateDto $template): void
    {
        $this->template = $template;
    }

    public function getAgent(): ?AgentDto
    {
        return $this->agent;
    }

    public function setAgent(?AgentDto $agent): void
    {
        $this->agent = $agent;
    }

    public function getManagerContractor(): ?ContractorDto
    {
        return $this->managerContractor;
    }

    public function setManagerContractor(?ContractorDto $managerContractor): void
    {
        $this->managerContractor = $managerContractor;
    }

    public function getFileData(): ?FileDataDto
    {
        return $this->fileData;
    }

    public function setFileData(?StorageFileDto $fileData): void
    {
        $this->fileData = $fileData;
    }

    public function getStorageFile(): ?StorageFileDto
    {
        return $this->storageFile;
    }

    public function setStorageFile(?StorageFileDto $storageFile): void
    {
        $this->storageFile = $storageFile;
    }
}
