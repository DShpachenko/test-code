<?php

declare(strict_types=1);

namespace App\Rules;

use Illuminate\Contracts\Validation\Rule;
use NoName\Support\Numbers;
use LogicException;

class DecimalRule implements Rule
{
    private string $format;

    public function __construct(int $totalDigits, int $decimals)
    {
        if ($totalDigits <= $decimals) {
            throw new LogicException('В DecimalRule значение totalDigits должно быть больше значения decimals');
        }

        $this->format = sprintf('/^\d{1,%d}(\.\d{1,%d})?$/', $totalDigits - $decimals, $decimals);
    }

    public function passes($attribute, $value): bool
    {
        if (!is_numeric($value)) {
            return false;
        }

        $number = is_string($value) ? $value : Numbers::floatToString($value);

        return preg_match($this->format, $number) > 0;
    }

    public function message(): string
    {
        return __('validation.decimal_format', ['format' => $this->format]);
    }
}
