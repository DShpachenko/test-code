<?php

declare(strict_types=1);

namespace App\Services\Storage;

use App\Dto\Entities\Storage\FileDto;
use App\Repositories\Storage\File\FileRepositoryInterface;

final class FileService
{
    public function __construct(private FileRepositoryInterface $repository)
    {
    }

    public function create(FileDto $dto): FileDto
    {
        return $this->repository->create($dto);
    }

    public function update(array $condition, array $data): void
    {
        $this->repository->update(array_filter($condition), array_filter($data));
    }

    public function get(array $filters): ?FileDto
    {
        return $this->repository->get(array_filter($filters));
    }
}
