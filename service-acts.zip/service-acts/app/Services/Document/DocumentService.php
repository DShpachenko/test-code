<?php

declare(strict_types=1);

namespace App\Services\Document;

use NoName\ClientDocuments\Dto\Document;
use App\Dto\Entities\Documents\DocumentFileDto;
use NoName\ClientDocuments\Dto\CreateDocumentData;
use App\Repositories\Document\Document\DocumentRepositoryInterface;

final class DocumentService
{
    public function __construct(private DocumentRepositoryInterface $repository)
    {
    }

    public function create(CreateDocumentData $documentData): Document
    {
        return $this->repository->create($documentData);
    }

    public function findById(int $id): Document
    {
        return $this->repository->findById($id);
    }

    public function downloadDocument(int $id): DocumentFileDto
    {
        return $this->repository->downloadDocument($id);
    }

    public function downloadOriginDocument(int $id): DocumentFileDto
    {
        return $this->repository->downloadOriginDocument($id);
    }
}
