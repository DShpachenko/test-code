<?php

declare(strict_types=1);

namespace App\Services\Logs;

use App\Repositories\Logs\OperationLog\OperationLogsRepositoryInterface;

final class OperationLogService
{
    public function __construct(private OperationLogsRepositoryInterface $repository)
    {
    }

    public function log(string $action, ?int $customerId, ?int $entityId, array $info): void
    {
        $this->repository->create($action, $customerId, $entityId, $info);
    }
}
