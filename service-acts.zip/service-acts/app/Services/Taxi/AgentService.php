<?php

declare(strict_types=1);

namespace App\Services\Taxi;

use App\Dto\Entities\Taxi\AgentDto;
use App\Repositories\Taxi\Agent\AgentRepositoryInterface;

final class AgentService
{
    public function __construct(private AgentRepositoryInterface $repository)
    {
    }

    public function get(array $filters): ?AgentDto
    {
        return $this->repository->get(array_filter($filters));
    }
}
