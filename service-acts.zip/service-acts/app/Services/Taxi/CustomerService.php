<?php

declare(strict_types=1);

namespace App\Services\Taxi;

use App\Dto\Entities\Taxi\CustomerDto;
use App\Repositories\Taxi\Customer\CustomerRepositoryInterface;

final class CustomerService
{
    public function __construct(private CustomerRepositoryInterface $repository)
    {
    }

    public function get(array $filters): ?CustomerDto
    {
        return $this->repository->get(array_filter($filters));
    }
}
