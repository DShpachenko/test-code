<?php

declare(strict_types=1);

namespace App\Services\Taxi;

use App\Dto\Entities\Taxi\ContractorsWorkplaceDto;
use App\Repositories\Taxi\ContractorsWorkplace\ContractorsWorkplaceRepositoryInterface;

final class ContractorsWorkplaceService
{
    public function __construct(private ContractorsWorkplaceRepositoryInterface $repository)
    {
    }

    public function get(array $filters): ?ContractorsWorkplaceDto
    {
        return $this->repository->get(array_filter($filters));
    }
}
