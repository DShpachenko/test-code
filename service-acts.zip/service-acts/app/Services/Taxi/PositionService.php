<?php

declare(strict_types=1);

namespace App\Services\Taxi;

use App\Dto\Entities\Taxi\PositionDto;
use App\Repositories\Taxi\Position\PositionRepositoryInterface;

final class PositionService
{
    public function __construct(private PositionRepositoryInterface $repository)
    {
    }

    public function get(array $filters): ?PositionDto
    {
        return $this->repository->get($filters);
    }
}
