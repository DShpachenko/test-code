<?php

declare(strict_types=1);

namespace App\Services\Taxi;

use App\Dto\Entities\Taxi\ContractorDto;
use App\Repositories\Taxi\Contractor\ContractorRepositoryInterface;

final class ContractorService
{
    public function __construct(private ContractorRepositoryInterface $repository)
    {
    }

    public function get(array $filters): ?ContractorDto
    {
        return $this->repository->get(array_filter($filters));
    }
}
