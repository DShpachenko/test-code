<?php

declare(strict_types=1);

namespace App\Services\Act;

use App\Dto\Entities\Acts\TemplateFileDto;
use App\Repositories\Act\TemplateFile\TemplateFileRepositoryInterface;

final class TemplateFileService
{
    public function __construct(private TemplateFileRepositoryInterface $repository)
    {
    }

    public function create(TemplateFileDto $dto): void
    {
        $this->repository->create($dto);
    }

    public function delete(array $filters): void
    {
        $this->repository->delete($filters);
    }
}
