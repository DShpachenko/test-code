<?php

declare(strict_types=1);

namespace App\Services\Act;

use Illuminate\Support\Collection;
use App\Dto\Entities\Acts\JobTypeDto;
use App\Repositories\Act\JobType\JobTypeRepositoryInterface;

final class JobTypeService
{
    public function __construct(private JobTypeRepositoryInterface $repository)
    {
    }

    public function create(JobTypeDto $dto): JobTypeDto
    {
        return $this->repository->create($dto);
    }

    public function update(array $condition, array $data): void
    {
        $this->repository->update(array_filter($condition), array_filter($data));
    }

    public function get(array $filters): ?JobTypeDto
    {
        return $this->repository->get(array_filter($filters));
    }

    public function list(array $filters): ?Collection
    {
        return $this->repository->list(array_filter($filters));
    }

    public function delete(array $filters): void
    {
        $this->repository->delete(array_filter($filters));
    }
}
