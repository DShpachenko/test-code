<?php

declare(strict_types=1);

namespace App\Services\Act;

use Illuminate\Support\Str;
use App\Helpers\AmountByWordsHelper;
use NoName\Dictionaries\LegalForm;
use Illuminate\Support\Facades\Storage;
use App\Dto\Entities\Taxi\AgentInfoDto;
use App\Dto\Entities\Acts\ActJobTypeDto;
use App\Enums\NoName\JobTypes\MeasureEnum;
use App\Enums\NoName\Companies\CompaniesEnum;
use App\Dto\Pipelines\Acts\CreateActPipelineDto;
use NoName\TemplateProcessor\Facades\Templates;

final class ActGenerationService
{
    public const DOCX_FORMAT = 'docx';

    private const PERSONAL_COMPANY_ACT_TEMPLATE = 'resources/templates/act_template_for_';

    public function generate(CreateActPipelineDto $dto): string
    {
        $act = $dto->getAct();

        $template = Templates::newDocxTemplate($this->templatePath($dto));

        $agent      = $dto->getAgent();
        $agentInfo  = $agent->getInfoDto();
        $document   = $dto->getDocument();
        $contractor = $dto->getEmployeeContractor();
        $customer   = $dto->getCustomer();

        $actCreatedAt = in_array($act->getCompanyId(), [
            CompaniesEnum::NO_NAME_1,
            CompaniesEnum::NO_NAME_2,
        ]) ?
            $act->getPeriodTo('d.m.Y') :
            $act->getCreatedAt('d.m.Y');

        $template->fillPlaceholders([
            'act.number'               => $act->getNumber(),
            'act.name'                 => $act->getName(),
            'act.created_at'           => $actCreatedAt,
            'act.total_price'          => $act->getTotalPrice(),
            'act.from'                 => $act->getPeriodFrom('d.m.Y'),
            'act.to'                   => $act->getPeriodTo('d.m.Y'),
            'act.total_price_by_words' => ucfirst(AmountByWordsHelper::num2str($act->getTotalPrice())),
            'agent.city'               => $agentInfo->getCity(),
            'agent.name'               => $agent->getName(),
            'agent.address'            => $agentInfo->getAddress(),
            'agent.ogrn'               => $this->getOgrnText($agentInfo->getOgrn()),
            'agent.ogrn_date'          => $this->getOgrnDateText($agentInfo->getOgrnDate('d.m.Y')),
            'agent.inn'                => $this->getInnText($agentInfo->getInn()),
            'agent.kpp'                => $this->getKppText($agentInfo->getKpp()),
            'agent.customer_name'      => $this->getAgentCustomerName($agentInfo),
            'document.number'          => $document->getManualNumber() ?: $document->getNumber(),
            'document.date'            => $document->getDate('d.m.Y'),
            'contractor.name'          => $contractor->getFullName(),
            'contractor.inn'           => $this->getInnText($contractor->getInn()),
            'contractor.phone'         => $this->getPhoneText($contractor->getPhone()),
            'contractor.email'         => $this->getEmailText($contractor->getEmail()),
            'customer.phone'           => $this->getPhoneText($customer->getPhone()),
            'customer.email'           => $this->getEmailText($customer->getEmail()),
            'legal_form.additional'    => $this->getLegalFormAdditionalText($contractor->getLegalFormId()),
        ]);

        $template->cloneRowAndSetValues('cell1', $this->makeTableData($dto->getJobTypes()));

        $fileName = md5($act->getId() . Str::random()) . '.' . self::DOCX_FORMAT;

        $generatedDocumentPath = $template->generateDocument(storage_path($fileName));

        if ($template = $dto->getTemplate()) {
            Storage::disk('tmp')->delete($template->getFile()->getPath());
        }

        return $generatedDocumentPath;
    }

    private function templatePath(CreateActPipelineDto $dto): string
    {
        $act = $dto->getAct();

        if ($templateDto = $dto->getTemplate()) {
            $path = $templateDto->getFile()->getPath();
            $templatePath = '/' . $path;
            /*
             *@todo костыль, необходимо подумать как отказаться от phpword из-за отсутствия возможности
             * создавать шаблоны (PhpWordTemplate) из облачного файла по содержимому, а не по абсолютному пути
             */

            Storage::disk('tmp')->put($templatePath, Storage::disk('selectel')->get($path));
            $templatePath = sys_get_temp_dir() . $templatePath;
        } else {
            $templatePath = in_array($act->getCompanyId(), [
                CompaniesEnum::NO_NAME_1,
            ]) ?
                env('ACT_TEMPLATE_WITHOUT_NUMBER_PATH') :
                env('ACT_TEMPLATE_PATH');

            if (in_array($act->getCompanyId(), [
                CompaniesEnum::NO_NAME_3,
                CompaniesEnum::NO_NAME_5,
                CompaniesEnum::NO_NAME_6,
            ])) {
                $templatePath = self::PERSONAL_COMPANY_ACT_TEMPLATE . $act->getCompanyId() . '.' . self::DOCX_FORMAT;
            }
        }

        return $templatePath;
    }

    private function getAgentCustomerName(AgentInfoDto $agentInfo): string
    {
        if ($agentInfo->getManagementPost() && $agentInfo->getManagementName()) {
            $str = $agentInfo->getManagementPost() . ' ' . $agentInfo->getManagementName();
        } else {
            $str = $agentInfo->getIndividualEntrepreneurSurname() . ' ' .
                $agentInfo->getIndividualEntrepreneurName() . ' ' .
                $agentInfo->getIndividualEntrepreneurPatronymic();
        }

        return mb_convert_case($str, MB_CASE_TITLE, 'UTF-8');
    }

    private function makeTableData(array $jobTypes): array
    {
        $data  = [];
        $count = count($jobTypes);

        for ($i = 0; $i < $count; ++$i) {
            /** @var ActJobTypeDto $jobType */
            $jobType = $jobTypes[$i];

            $data[] = [
                'cell1' => (string) ($i + 1),
                'cell2' => $jobType->getName(),
                'cell3' => MeasureEnum::title($jobType->getMeasureId()),
                'cell4' => $jobType->getCount(),
                'cell5' => number_format($jobType->getPrice(), 2, '.', ' '),
                'cell6' => number_format($jobType->getPrice() * $jobType->getCount(), 2, '.', ' '),
            ];
        }

        return $data;
    }

    private function getOgrnText(?string $ogrn): string
    {
        return $ogrn ? 'ОГРН ' . $ogrn : '';
    }

    private function getOgrnDateText(?string $ogrnDate): string
    {
        return $ogrnDate ? 'от ' . $ogrnDate : '';
    }

    private function getInnText(?string $inn): string
    {
        return $inn ? 'ИНН ' . $inn : '';
    }

    private function getKppText(?string $kpp): string
    {
        return $kpp ? 'КПП ' . $kpp : '';
    }

    private function getEmailText(?string $email): string
    {
        return $email ? 'E-mail: ' . $email : '';
    }

    private function getPhoneText(?string $phone): string
    {
        return $phone ? 'Тел./факс: ' . $phone : '';
    }

    private function getLegalFormAdditionalText(?int $legalFormId): string
    {
        return $legalFormId === LegalForm::LEGAL_SELF_EMPLOYED ?
            'являющийся налогоплательщиком «Налога на профессиональный доход», ' : '';
    }
}
