<?php

declare(strict_types=1);

namespace App\Services\Act;

use App\Dto\Entities\Acts\ExportFileDto;
use App\Repositories\Act\ExportFile\ExportFileRepositoryInterface;

final class ExportFileService
{
    public function __construct(private ExportFileRepositoryInterface $repository)
    {
    }

    public function create(ExportFileDto $dto): void
    {
        $this->repository->create($dto);
    }

    public function get(array $filters): ?ExportFileDto
    {
        return $this->repository->get(array_filter($filters));
    }

}
