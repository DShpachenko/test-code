<?php

declare(strict_types=1);

namespace App\Services\Act;

use App\Dto\Entities\Acts\TemplateDto;
use App\Dto\Entities\Acts\TemplateListByFilterDto;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use App\Repositories\Act\Template\TemplateRepositoryInterface;

final class TemplateService
{
    private const DEFAULT_PAGE = 1;

    private const DEFAULT_PER_PAGE = 15;

    public function __construct(private TemplateRepositoryInterface $repository)
    {
    }

    public function create(TemplateDto $dto): TemplateDto
    {
        return $this->repository->create($dto);
    }

    public function list(TemplateListByFilterDto $dto): LengthAwarePaginator
    {
        $dto->setPage($dto->getPage() ?? self::DEFAULT_PAGE);
        $dto->setPerPage($dto->getPerPage() ?? self::DEFAULT_PER_PAGE);

        return $this->repository->list($dto);
    }

    public function get(array $filters, array $with = [], bool $withTrashed = false): ?TemplateDto
    {
        return $this->repository->get(array_filter($filters), $with, $withTrashed);
    }

    public function update(array $condition, array $data): void
    {
        $this->repository->update($condition, $data);
    }

    public function delete(array $filters): void
    {
        $this->repository->delete(array_filter($filters));
    }
}
