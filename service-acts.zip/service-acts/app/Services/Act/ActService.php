<?php

declare(strict_types=1);

namespace App\Services\Act;

use App\Models\Acts\Act;
use App\Dto\Entities\Acts\ActDto;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;
use NoName\Permissions\Permission;
use NoName\ClientAuthJwt\Dto\UserSet;
use App\Enums\NoName\Acts\StatusEnum;
use App\Dto\Entities\Acts\ActAllByFiltersDto;
use App\Repositories\Act\Act\ActRepositoryInterface;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;

final class ActService
{
    private const CHUNK_ITEMS_COUNT = 300;

    private const DEFAULT_PAGE = 1;

    private const DEFAULT_PER_PAGE = 15;

    public function __construct(private ActRepositoryInterface $repository)
    {
    }

    public static function canSign(int $managerContractorId, UserSet $user): bool
    {
        // @todo в будужем заменить на новый пермишен разрешения подписания
        if ($user->can(Permission::WRITE_DOCUMENT)) {
            if ($user->getLinkedContractor()?->getId() === $managerContractorId) {
                return true;
            }
        }

        return false;
    }

    public function create(ActDto $dto): ActDto
    {
        $dto->setStatus(StatusEnum::IN_PROCESSING);

        return $this->repository->create($dto);
    }

    public function update(array $condition, array $data): void
    {
        $this->repository->update(array_filter($condition), array_filter($data));
    }

    public function updateByIds(array $ids, array $data): void
    {
        $this->repository->updateByIds($ids, array_filter($data));
    }

    public function get(array $filters, array $with = []): ?ActDto
    {
        $with[] = 'signature';

        return $this->repository->get(array_filter($filters), $with);
    }

    public function list(array $filters, array $with = []): ?Collection
    {
        return $this->repository->list(array_filter($filters), $with);
    }

    public function listByFilters(ActAllByFiltersDto $dto): Collection
    {
        return $this->repository->listByFilters($dto);
    }

    public function allByFilters(ActAllByFiltersDto $dto): LengthAwarePaginator
    {
        $dto->setPage($dto->getPage() ?? self::DEFAULT_PAGE);
        $dto->setPerPage($dto->getPerPage() ?? self::DEFAULT_PER_PAGE);

        return $this->repository->allByFilters($dto);
    }

    public function delete(array $filters): void
    {
        $this->repository->delete(array_filter($filters));
    }

    public function getMaxActNumber(int $companyId, string $type = null): int
    {
        return $this->repository->getMaxActNumber($companyId, $type);
    }

    public function getCountActsByStatuses(ActDto $dto): array
    {
        $items = $this->repository->getCountActsByStatuses([
            'company_id'             => $dto->getCompanyId(),
            'employee_contractor_id' => $dto->getEmployeeContractorId(),
            'type'                   => $dto->getType(),
        ]);

        $data     = [];
        $statuses = StatusEnum::allValues();
        foreach ($statuses as $status) {
            $data[$status] = $items[$status] ?? 0;
        }

        return $data;
    }

    public function allByFiltersWithChunk(ActAllByFiltersDto $dto, int $count, callable $callback, array $with): void
    {
        $this->repository->allByFiltersWithChunk($dto, $count, $callback, $with);
    }

    public function signingInfo(ActAllByFiltersDto $dto): Collection
    {
        $result = [];

        $callback = function (Collection $items) use (&$result) {
            $items->map(function (Act $item) use (&$result) {
                $actDto = ActDto::fromArray($item->toArray());

                $result[] = [
                    'act_id'               => $actDto->getId(),
                    'document_hash'        => $actDto->getDocumentHash(),
                    'manager_signature_id' => $actDto->getSignature()?->getManagerSignatureId(),
                ];
            });
        };

        $this->allByFiltersWithChunk($dto, self::CHUNK_ITEMS_COUNT, $callback, ['signature']);

        return new Collection($result);
    }
}
