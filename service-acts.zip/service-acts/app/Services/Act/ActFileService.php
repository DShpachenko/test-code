<?php

declare(strict_types=1);

namespace App\Services\Act;

use App\Dto\Entities\Acts\ActFileDto;
use App\Repositories\Act\ActFile\ActFileRepositoryInterface;

final class ActFileService
{
    public function __construct(private ActFileRepositoryInterface $repository)
    {
    }

    public function create(ActFileDto $dto)
    {
        $this->repository->create($dto);
    }

    public function update(array $condition, array $data): void
    {
        $this->repository->update(array_filter($condition), array_filter($data));
    }

    public function get(array $filters): ?ActFileDto
    {
        return $this->repository->get(array_filter($filters));
    }

    public function delete(array $filters): void
    {
        $this->repository->delete($filters);
    }
}
