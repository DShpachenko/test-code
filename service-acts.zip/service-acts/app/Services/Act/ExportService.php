<?php

declare(strict_types=1);

namespace App\Services\Act;

use App\Dto\Entities\Acts\ExportDto;
use App\Enums\NoName\Exports\StatusEnum;
use App\Repositories\Act\Export\ExportRepositoryInterface;

final class ExportService
{
    public function __construct(private ExportRepositoryInterface $repository)
    {
    }

    public function create(ExportDto $dto): ExportDto
    {
        $dto->setStatus(StatusEnum::NEW);

        return $this->repository->create($dto);
    }

    public function update(array $condition, array $data): void
    {
        $this->repository->update(array_filter($condition), array_filter($data));
    }

    public function get(array $filters, ?array $with = null): ?ExportDto
    {
        return $this->repository->get(array_filter($filters), $with);
    }

    public function getById(int $exportId, ?array $with = null): ?ExportDto
    {
        return $this->repository->getById($exportId, $with);
    }

    public function done(ExportDto $dto): ExportDto
    {
        return $this->changeStatus($dto, StatusEnum::DONE);
    }

    public function fail(ExportDto $dto): ExportDto
    {
        return $this->changeStatus($dto, StatusEnum::ERROR);
    }

    private function changeStatus(ExportDto $dto, string $status): ExportDto
    {
        $dto->setStatus($status);

        $this->repository->update(
            ['id' => $dto->getId()],
            [
                'status'         => $dto->getStatus(),
                'status_details' => $dto->getStatusDetails()?->toArray(),
            ],
        );

        return $dto;
    }
}
