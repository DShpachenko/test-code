<?php

declare(strict_types=1);

namespace App\Services\Act;

use Illuminate\Support\Collection;
use App\Dto\Entities\Acts\ActJobTypeDto;
use App\Repositories\Act\ActJobType\ActJobTypeRepositoryInterface;

final class ActJobTypeService
{
    public function __construct(private ActJobTypeRepositoryInterface $repository)
    {
    }

    public function create(ActJobTypeDto $dto): ActJobTypeDto
    {
        return $this->repository->create($dto);
    }

    public function list(array $filters): ?Collection
    {
        return $this->repository->list(array_filter($filters));
    }
}
