<?php

declare(strict_types=1);

namespace App\Services\Act;

use App\Dto\Entities\Acts\ActSignatureDto;
use App\Repositories\Act\ActSignature\ActSignatureRepositoryInterface;

final class ActSignatureService
{
    public function __construct(private ActSignatureRepositoryInterface $repository)
    {
    }

    public function create(ActSignatureDto $dto): ActSignatureDto
    {
        return $this->repository->create($dto);
    }

    public function update(array $condition, array $data): void
    {
        $this->repository->update(array_filter($condition), array_filter($data));
    }

    public function get(array $filters): ?ActSignatureDto
    {
        return $this->repository->get(array_filter($filters));
    }

    public function allByFiltersWithChunk(array $filters, int $count, callable $callback, array $with): void
    {
        $this->repository->allByFiltersWithChunk($filters, $count, $callback, $with);
    }
}
