<?php

declare(strict_types=1);

namespace App\Enums\NoName\Storage\File;

use NoName\Base\Dictionaries\Dictionary;

final class TypeEnum extends Dictionary
{
    public const DOCUMENT_FILE       = 'document_file';
    public const DOCUMENTS_ARCHIVE   = 'documents_archive';
    public const ACT_TEMPLATE        = 'act_template';
    public const DOCUMENTS_FILE_XLSX = 'documents_export_xlsx';

    public static function all(): array
    {
        return [
            self::DOCUMENT_FILE       => 'Файл документа',
            self::DOCUMENTS_ARCHIVE   => 'Архив документов',
            self::ACT_TEMPLATE        => 'Файл шаблона акта',
            self::DOCUMENTS_FILE_XLSX => 'Файл документов в XLSX.'
        ];
    }
}
