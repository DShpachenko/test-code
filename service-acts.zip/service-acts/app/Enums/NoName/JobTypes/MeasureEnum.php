<?php

declare(strict_types=1);

namespace App\Enums\NoName\JobTypes;

use NoName\Dictionaries\Acts\ActMeasureDictionary;

final class MeasureEnum extends ActMeasureDictionary
{
    public static function all(): array
    {
        return [
            self::HOUR    => 'Час',
            self::PIECE   => 'Штука',
            self::SERVICE => 'Услуга',
        ];
    }
}
