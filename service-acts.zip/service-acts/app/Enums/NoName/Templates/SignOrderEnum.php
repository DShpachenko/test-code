<?php

declare(strict_types=1);

namespace App\Enums\NoName\Templates;

use NoName\Base\Dictionaries\Dictionary;

final class SignOrderEnum extends Dictionary
{
    public const ARBITRARY     = 'arbitrary';
    public const EMPLOYEE_ONLY = 'employee_only';

    public static function all(): array
    {
        return [
            self::ARBITRARY     => 'Обе стороны',
            self::EMPLOYEE_ONLY => 'Только исполнитель',
        ];
    }
}
