<?php

declare(strict_types=1);

namespace App\Enums\NoName\Logs;

use NoName\Base\Dictionaries\Dictionary;

final class ActionEnum extends Dictionary
{
    public const ACT_CREATING = 'act_creating';
    public const ACT_UPDATING = 'act_updating';
    public const ACT_DELETING = 'act_deleting';

    public static function all(): array
    {
        return [
            self::ACT_CREATING => 'Создание акта',
            self::ACT_UPDATING => 'Редактирование акта',
            self::ACT_DELETING => 'Удаление акта',
        ];
    }
}
