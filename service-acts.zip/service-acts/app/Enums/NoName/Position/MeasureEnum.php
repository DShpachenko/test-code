<?php

declare(strict_types=1);

namespace App\Enums\NoName\Position;

use NoName\Dictionaries\Acts\NoNameMeasureDictionary;

final class MeasureEnum extends NoNameMeasureDictionary
{
    //
}
