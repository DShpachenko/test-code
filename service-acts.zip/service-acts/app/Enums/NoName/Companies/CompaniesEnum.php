<?php

declare(strict_types=1);

namespace App\Enums\NoName\Companies;

use NoName\Base\Dictionaries\Dictionary;

final class CompaniesEnum extends Dictionary
{
    public const NO_NAME_1 = 11185;

    public const NO_NAME_2 = 8964;

    public const NO_NAME_3 = 9118;

    public const NO_NAME_4 = 4255;

    public const NO_NAME_5 = 11493;

    public const NO_NAME_6 = 6598;

    public static function all(): array
    {
        return [
            self::NO_NAME_1 => 'NO_NAME_1',
            self::NO_NAME_2 => 'NO_NAME_2',
            self::NO_NAME_3 => 'NO_NAME_3',
            self::NO_NAME_4 => 'NO_NAME_4',
            self::NO_NAME_5 => 'NO_NAME_5',
        ];
    }
}
