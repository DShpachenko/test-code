<?php

declare(strict_types=1);

namespace App\Enums\NoName\Acts;

use NoName\Base\Dictionaries\Dictionary;

final class StatusEnum extends Dictionary
{
    public const IN_PROCESSING              = 'in_processing';
    public const PENDING_EMPLOYEE_SIGNATURE = 'pending_employee_signature';
    public const PENDING_COMPANY_SIGNATURE  = 'pending_company_signature';
    public const PROCESSING_SIGNATURE       = 'processing_signature';
    public const DONE                       = 'done';
    public const CANCELLED                  = 'cancelled';

    public static function all(): array
    {
        return [
            self::IN_PROCESSING              => 'В обработке',
            self::PENDING_EMPLOYEE_SIGNATURE => 'На подписи исполнителя',
            self::PENDING_COMPANY_SIGNATURE  => 'На подписи компании',
            self::PROCESSING_SIGNATURE       => 'Обработка подписи',
            self::DONE                       => 'Подписан',
            self::CANCELLED                  => 'Аннулирован',
        ];
    }

    public static function isPendingSignature(): array
    {
        return [
            self::PENDING_COMPANY_SIGNATURE,
            self::PENDING_EMPLOYEE_SIGNATURE,
        ];
    }
}
