<?php

declare(strict_types=1);

namespace App\Enums\NoName\Acts;

use NoName\Base\Dictionaries\Dictionary;

final class TypeEnum extends Dictionary
{
    public const JOB         = 'job';
    public const SCRAP_METAL = 'scrap_metal';

    public static function all(): array
    {
        return [
            self::JOB         => 'Акт выполненных работ',
            self::SCRAP_METAL => 'Акт приемо-сдачи металлолома',
        ];
    }
}
