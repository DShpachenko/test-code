<?php

declare(strict_types=1);

namespace App\Enums\NoName\Exports;

use NoName\Base\Dictionaries\Dictionary;

/**
 * Типы экспортов актов
 */
final class TypeEnum extends Dictionary
{
    public const JOB_ZIP_TO_EMAIL = 'job_zip_to_email';
    public const SCRAP_METAL_ZIP  = 'scrap_metal_zip';
    public const SCRAP_METAL_XLSX = 'scrap_metal_xlsx';

    public static function all(): array
    {
        return [
            self::JOB_ZIP_TO_EMAIL => 'Экспорт актов выполненных работ в zip с отправкой на email',
            self::SCRAP_METAL_ZIP  => 'Экспорт ПСА металлистов в zip архив для дальнейшего скачивания',
            self::SCRAP_METAL_XLSX => 'Экспорт ПСА металлистов в виде таблицы xlsx для дальнейшего скачивания',
        ];
    }
}
