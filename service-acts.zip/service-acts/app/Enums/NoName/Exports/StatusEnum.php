<?php

declare(strict_types=1);

namespace App\Enums\NoName\Exports;

use NoName\Base\Dictionaries\Dictionary;

final class StatusEnum extends Dictionary
{
    public const NEW              = 'new';
    public const ARCHIVE_CREATION = 'archive_creation';
    public const MAIL_SENDING     = 'mail_sending';
    public const DONE             = 'done';
    public const CANCELLED        = 'cancelled';
    public const ERROR            = 'error';

    public static function all(): array
    {
        return [
            self::NEW              => 'Новый экспорт',
            self::ARCHIVE_CREATION => 'Формирование архива',
            self::MAIL_SENDING     => 'Отправка письма',
            self::DONE             => 'Готово',
            self::CANCELLED        => 'Отменено',
            self::ERROR            => 'Ошибка',
        ];
    }
}
