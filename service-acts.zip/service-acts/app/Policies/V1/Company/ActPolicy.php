<?php

declare(strict_types=1);

namespace App\Policies\V1\Company;

use NoName\Permissions\Permission;
use Illuminate\Auth\Access\Response;
use NoName\ClientAuthJwt\Contracts\User;
use Illuminate\Auth\Access\HandlesAuthorization;

final class ActPolicy
{
    use HandlesAuthorization;

    public function canCreate(User $user): Response
    {
        if (!$user->can(Permission::WRITE_ACT)) {
            return $this->deny(trans('exceptions.9'));
        }

        return Response::allow();
    }

    public function canGet(User $user): Response
    {
        if (!$user->can(Permission::READ_ACT)) {
            return $this->deny(trans('exceptions.10'));
        }

        return Response::allow();
    }

    public function canAll(User $user): Response
    {
        if (!$user->can(Permission::READ_ACT)) {
            return $this->deny(trans('exceptions.10'));
        }

        return Response::allow();
    }

    public function canDelete(User $user): Response
    {
        if (!$user->can(Permission::WRITE_ACT)) {
            return $this->deny(trans('exceptions.9'));
        }

        return Response::allow();
    }

    public function canExport(User $user): Response
    {
        if (!$user->can(Permission::EXPORT_ACT)) {
            return $this->deny(trans('exceptions.15'));
        }

        return Response::allow();
    }

    public function canViewDocumentsInfo(User $user): Response
    {
        if (!$user->can(Permission::READ_ACT)) {
            return $this->deny(trans('exceptions.10'));
        }

        return Response::allow();
    }

    public function canPreviewActDocumentFile(User $user): Response
    {
        if (!$user->can(Permission::READ_ACT)) {
            return $this->deny(trans('exceptions.10'));
        }

        return Response::allow();
    }

}
