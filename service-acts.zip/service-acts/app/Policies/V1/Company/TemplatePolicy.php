<?php

declare(strict_types=1);

namespace App\Policies\V1\Company;

use Illuminate\Auth\Access\HandlesAuthorization;
use Illuminate\Auth\Access\Response;
use NoName\ClientAuthJwt\Contracts\User;
use NoName\Permissions\Permission;

final class TemplatePolicy
{
    use HandlesAuthorization;

    public function canCreate(User $user): Response
    {
        if (! $user->can(Permission::WRITE_ACT_TEMPLATE)) {
            return $this->deny(trans('exceptions.21'));
        }

        return Response::allow();
    }

    public function canList(User $user): Response
    {
        if (! $user->can(Permission::READ_ACT)) {
            return $this->deny(trans('exceptions.10'));
        }

        return Response::allow();
    }

    public function canGet(User $user): Response
    {
        if (!$user->can(Permission::READ_ACT)) {
            return $this->deny(trans('exceptions.10'));
        }

        return Response::allow();
    }

    public function canDelete(User $user): Response
    {
        if (! $user->can(Permission::WRITE_ACT_TEMPLATE)) {
            return $this->deny(trans('exceptions.21'));
        }

        return Response::allow();
    }
}
