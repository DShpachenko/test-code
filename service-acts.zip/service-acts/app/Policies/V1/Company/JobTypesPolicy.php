<?php

declare(strict_types=1);

namespace App\Policies\V1\Company;

use Illuminate\Auth\Access\Response;
use NoName\Permissions\Permission;
use NoName\ClientAuthJwt\Contracts\User;
use Illuminate\Auth\Access\HandlesAuthorization;

final class JobTypesPolicy
{
    use HandlesAuthorization;

    public function canCreate(User $user): Response
    {
        if (!$user->can(Permission::WRITE_ACT_JOBS_TYPES)) {
            return $this->deny(trans('exceptions.11'));
        }

        return Response::allow();
    }

    public function canUpdate(User $user): Response
    {
        if (!$user->can(Permission::WRITE_ACT_JOBS_TYPES)) {
            return $this->deny(trans('exceptions.11'));
        }

        return Response::allow();
    }

    public function canAll(User $user): Response
    {
        if (!$user->can(Permission::READ_ACT_JOBS_TYPES)) {
            return $this->deny(trans('exceptions.12'));
        }

        return Response::allow();
    }

    public function canDelete(User $user): Response
    {
        if (!$user->can(Permission::WRITE_ACT_JOBS_TYPES)) {
            return $this->deny(trans('exceptions.11'));
        }

        return Response::allow();
    }
}
