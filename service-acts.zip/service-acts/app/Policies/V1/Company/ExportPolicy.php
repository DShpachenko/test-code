<?php

declare(strict_types=1);

namespace App\Policies\V1\Company;

use App\Dto\Entities\Acts\ExportDto;
use NoName\ClientCustomers\Agent;
use NoName\ClientCustomers\BranchOffice;
use NoName\ClientCustomers\Facades\Customers;
use NoName\Permissions\Permission;
use Illuminate\Auth\Access\Response;
use NoName\ClientAuthJwt\Contracts\User;
use Illuminate\Auth\Access\HandlesAuthorization;

final class ExportPolicy
{
    use HandlesAuthorization;

    /**
     * @param array<array{id: int, branch_office_ids: ?array<int>}> $agentsOrBranchOffices
     */
    public function create(User $user, array $agentsOrBranchOffices): Response
    {
        if (!$user->can(Permission::READ_NO_NAME)) {
            return $this->deny(trans('exceptions.15'));
        }

        // Проверка доступа к переданным юрлицам и филиалам
        $available = collect(iterator_to_array(Customers::getAgentsWithBranchOffices($user->getId())))
            ->mapWithKeys(fn(Agent $agent) => [
                $agent->id() => array_map(
                    static fn(BranchOffice $branchOffice) => $branchOffice->id(),
                    $agent->branchOffices(),
                ),
            ]);

        $branchOffices = collect($agentsOrBranchOffices)->mapWithKeys(fn($agent) => [
            $agent['id'] => ($agent['branch_office_ids'] ?? [])
        ]);

        foreach ($branchOffices->all() as $agentId => $branchOfficeIds) {
            if (!$available->offsetExists($agentId)) {
                return $this->deny(trans('exceptions.56'));
            }

            $diff = array_diff($branchOfficeIds, $available->get($agentId, []));
            if (!empty($diff)) {
                return $this->deny(trans('exceptions.55'));
            }
        }

        return Response::allow();
    }

    public function view(User $user, ExportDto $dto): Response
    {
        if (!$user->can(Permission::READ_NO_NAME)) {
            return $this->deny(trans('exceptions.15'));
        }

        if ($user->getId() !== $dto->getAuthorId()) {
            return $this->deny(trans('exceptions.54'));
        }

        return Response::allow();
    }
}
