<?php

declare(strict_types=1);

namespace App\Exceptions\Pipelines;

use App\Exceptions\AbstractException;
use Symfony\Component\HttpFoundation\Response;

final class ManagerContractorException extends AbstractException
{
    public function __construct(string $message = '', int $code = Response::HTTP_BAD_REQUEST)
    {
        $message = empty($message) ? trans('exceptions.6') : $message;

        parent::__construct($message, $code);
    }
}
