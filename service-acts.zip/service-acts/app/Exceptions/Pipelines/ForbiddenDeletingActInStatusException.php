<?php

declare(strict_types=1);

namespace App\Exceptions\Pipelines;

use App\Exceptions\AbstractException;
use Symfony\Component\HttpFoundation\Response;

final class ForbiddenDeletingActInStatusException extends AbstractException
{
    public function __construct(string $message = '', int $code = Response::HTTP_FORBIDDEN)
    {
        $message = empty($message) ? trans('exceptions.60') : $message;

        parent::__construct($message, $code);
    }
}
