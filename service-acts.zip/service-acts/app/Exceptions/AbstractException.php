<?php

declare(strict_types=1);

namespace App\Exceptions;

use RuntimeException;
use NoName\Framework\Response\Errors\Error;
use NoName\Framework\Contracts\ErrorableInterface;
use NoName\Framework\Contracts\ExceptionErrorable;

abstract class AbstractException extends RuntimeException implements ExceptionErrorable
{
    protected string|null $details = null;

    protected array|null $fields = null;

    public bool $isMuteReport = false;

    public function getError(): ErrorableInterface
    {
        $error = new Error($this->code, $this->message);

        if ($this->details) {
            $error->setDetail($this->details);
        }

        if ($this->fields) {
            $error->setFields($this->fields);
        }

        return $error;
    }

    public function isMuteReport(): bool
    {
        return $this->isMuteReport;
    }

    public function setIsMuteReport(bool $value): void
    {
        $this->isMuteReport = $value;
    }
}
