<?php

declare(strict_types=1);

namespace App\Exceptions;

use Throwable;
use NoName\Framework\Exceptions\Handler as ExceptionHandler;

final class Handler extends ExceptionHandler
{
    public function reportWithoutBusinessExceptions(BusinessExceptionInterface | Throwable $e): void
    {
        if (! $e->isMuteReport() && $this->shouldReport($e)) {
            $this->logException($e);
        }

        $e->setIsMuteReport(true);

        parent::report($e);
    }
}
