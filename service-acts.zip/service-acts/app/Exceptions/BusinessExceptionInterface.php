<?php

declare(strict_types=1);

namespace App\Exceptions;

interface BusinessExceptionInterface
{
    public function isMuteReport(): bool;

    public function setIsMuteReport(bool $value): void;
}
