<?php

declare(strict_types=1);

namespace App\Traits;

use Carbon\Carbon;

trait CliLogger
{
    protected Carbon $startTime;

    public function start(): void
    {
        $this->startTime = now();

        $this->comment($this->getName() . ' start', 'v');
    }

    public function finish(): void
    {
        $this->comment('время выполнения ' . $this->elapsed(), 'v');
        $this->comment($this->getName() . ' finish', 'v');
    }

    public function elapsed(): string
    {
        return $this->startTime->diffAsCarbonInterval(now())->format('%H:%I:%S');
    }

    protected function log($message, $verbosity = 'v'): void
    {
        $this->info('[' . date('H:i:s') . '] ' . $message, $verbosity);
    }
}
