<?php

declare(strict_types=1);

namespace App\Console;

use App\Console\Commands\Acts\AddCreateActDocumentJobCommand;
use App\Console\Commands\Acts\DeleteActCommand;
use App\Console\Commands\Acts\HandleProcessingSignatureActsCommand;
use Illuminate\Console\Scheduling\Schedule;
use NoName\EventBus\Commands\EventBusListen;
use App\Console\Commands\Acts\UpdateManagerSignatureId;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;
use App\Console\Commands\Acts\AddDocumentHashToActsCommand;
use App\Console\Commands\Acts\TransferAllActsDocumentsFilesCommand;

class Kernel extends ConsoleKernel
{
    protected $commands = [
        EventBusListen::class,
        TransferAllActsDocumentsFilesCommand::class,
        AddDocumentHashToActsCommand::class,
        UpdateManagerSignatureId::class,
        AddCreateActDocumentJobCommand::class,
        DeleteActCommand::class,
    ];

    protected function schedule(Schedule $schedule)
    {
        $schedule->command(HandleProcessingSignatureActsCommand::class)->everyMinute();

        $schedule->command(UpdateManagerSignatureId::class)->everyMinute();

        $schedule->command(AddDocumentHashToActsCommand::class)->everyMinute();
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__ . '/Commands');

        require base_path('routes/console.php');
    }
}
