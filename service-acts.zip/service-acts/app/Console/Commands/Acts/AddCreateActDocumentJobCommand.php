<?php

declare(strict_types=1);

namespace App\Console\Commands\Acts;

use App\Traits\CliLogger;
use NoName\Support\Strings;
use Illuminate\Console\Command;
use App\Jobs\Acts\CreateActDocumentJob;

final class AddCreateActDocumentJobCommand extends Command
{
    use CliLogger;

    protected $signature = 'acts:add-create-act-document-job {--id=}';

    protected $description = 'Создание джоб генерации документов актов по массиву id-шников';

    public function handle(): void
    {
        $actsIds = Strings::extractNumbers(($this->option('id') ?? ''), ',');

        if (empty($actsIds)) {
            $this->log('Missing act identifiers');

            return;
        }

        foreach ($actsIds as $actId) {
            dispatch(new CreateActDocumentJob($actId));

            $this->log('new CreateActDocumentJob by act_id - ' . $actId);
        }

        $this->log('Total jobs: ' . count($actsIds));
    }
}
