<?php

declare(strict_types=1);

namespace App\Console\Commands\Acts;

use App\Models\Acts\Act;
use Illuminate\Console\Command;
use App\Services\Act\ActService;
use App\Dto\Entities\Acts\ActDto;
use Illuminate\Support\Collection;
use App\Jobs\Acts\DownloadDocumentFileJob;
use App\Dto\Entities\Acts\ActAllByFiltersDto;

final class TransferAllActsDocumentsFilesCommand extends Command
{
    private const COUNT_ITEMS = 300;

    protected $signature = 'acts:transfer-all-documents-files';

    protected $description = 'Перенос всех файлов документов актов в облако S3 сервиса актов';

    public function handle(ActService $actService): void
    {
        $iterator = 0;

        $callback = function (Collection $items) use (&$iterator) {
            $items->map(function (Act $item) {
                $actDto = ActDto::fromArray($item->toArray());

                dispatch(new DownloadDocumentFileJob($actDto->getId()));
            });

            $iterator += $items->count();

            $this->info('processed: ' . $iterator);
        };

        $actService->allByFiltersWithChunk(ActAllByFiltersDto::fromArray([]), self::COUNT_ITEMS, $callback, []);
    }
}
