<?php

declare(strict_types=1);

namespace App\Console\Commands\Acts;

use App\Models\Acts\Act;
use Illuminate\Console\Command;
use App\Services\Act\ActService;
use App\Dto\Entities\Acts\ActDto;
use Illuminate\Support\Collection;
use App\Enums\NoName\Acts\StatusEnum;
use App\Jobs\Acts\CheckSignedDocumentJob;
use App\Dto\Entities\Acts\ActAllByFiltersDto;

final class CheckActStatusCommand extends Command
{
    private const COUNT_ITEMS = 300;

    protected $signature = 'acts:check-status';

    protected $description = 'Актуализация статуса актов';

    public function handle(ActService $actService): void
    {
        $iterator = 0;

        $callback = function (Collection $items) use (&$iterator) {
            $items->map(function (Act $item) {
                $actDto = ActDto::fromArray($item->toArray());

                if (
                    $actDto->getActDocumentId() &&
                    !in_array($actDto->getStatus(), [StatusEnum::DONE, StatusEnum::CANCELLED])
                ) {
                    dispatch(new CheckSignedDocumentJob($actDto->getActDocumentId()));
                }
            });

            $iterator += $items->count();

            $this->info('processed: ' . $iterator);
        };

        $actService->allByFiltersWithChunk(ActAllByFiltersDto::fromArray([
            'status'       => [StatusEnum::PENDING_COMPANY_SIGNATURE, StatusEnum::PENDING_EMPLOYEE_SIGNATURE],
            'status_logic' => false,
        ]), self::COUNT_ITEMS, $callback, []);
    }
}
