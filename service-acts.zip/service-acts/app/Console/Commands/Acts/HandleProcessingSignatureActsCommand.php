<?php

declare(strict_types=1);

namespace App\Console\Commands\Acts;

use App\Dto\Entities\Acts\ActDto;
use App\Enums\NoName\Acts\StatusEnum;
use App\Pipelines\V1\Acts\ActsPipeline;
use Illuminate\Console\Command;
use App\Services\Act\ActService;

final class HandleProcessingSignatureActsCommand extends Command
{
    protected $signature = 'acts:handle_processing_signatures';

    protected $description = 'Обработка актов, зависших в статусе массового подписания';

    public function handle(
        ActService   $actService,
        ActsPipeline $actsPipeline
    ): void
    {
        $actService->list(
            [
                ['status', '=', StatusEnum::PROCESSING_SIGNATURE],
                ['updated_at', '<=', now()->subHour()],
            ],
            ['signature']
        )?->map(function (ActDto $act) use ($actsPipeline) {
            $actsPipeline->cancelProcessingSignature($act);
            $this->info("У акта c id={$act->getId()} изменен статус");
        });
    }
}
