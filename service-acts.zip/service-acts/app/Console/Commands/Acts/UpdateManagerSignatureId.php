<?php

declare(strict_types=1);

namespace App\Console\Commands\Acts;

use Illuminate\Console\Command;
use App\Services\Act\ActService;
use App\Models\Acts\ActSignature;
use Illuminate\Support\Collection;
use App\Services\Act\ActSignatureService;
use App\Dto\Entities\Acts\ActSignatureDto;
use App\Services\Document\DocumentService;

final class UpdateManagerSignatureId extends Command
{
    private const COUNT_ITEMS = 300;

    protected $signature = 'acts:update-manager-signature-id';

    protected $description = 'Обновление отсутствующих идентификаторов подписи менеджера';

    public function handle(
        ActSignatureService $actSignatureService,
        DocumentService     $documentService,
        ActService          $actService,
    ): void
    {
        $iterator = 0;
        $failed   = 0;
        $failedIds = [];

        $callback = function (Collection $items) use (&$failedIds, &$iterator, &$failed, $actSignatureService, $documentService, $actService) {
            $items->map(function (ActSignature $item) use (&$failedIds, &$failed, $actSignatureService, $documentService, $actService) {
                $actSignatureDto = ActSignatureDto::fromArray($item->toArray());
                $actDto          = $actService->get(['id' => $actSignatureDto->getActId()]);

                if ($actDto) {
                    if (! $actSignatureDto->getManagerSignatureId()) {
                        // обработка кейса, когда у нас документ акта не создан
                        if ($actDto->getActDocumentId()) {
                            // обработка кейса, когда в сервисе документов не находится документ акта
                            // причина может быть любая, от падения сервиса - до удаления / аннулирования документа
                            try {
                                $documentDto = $documentService->findById($actDto->getActDocumentId());

                                if (count($documentDto->managerSignatures()) > 0) {
                                    $actSignatureService->update([
                                        'id' => $actSignatureDto->getId(),
                                    ], [
                                        'manager_signature_id' => $documentDto->managerSignatures()[0]->id(),
                                    ]);
                                }
                            } catch (\Exception $e) {
                                $failed++;
                                $failedIds[] = $actSignatureDto->getId();
                            }
                        }
                    }
                }
            });

            $iterator += $items->count();

            $this->info('processed: ' . $iterator);
            $this->info('successful: ' . ($iterator - $failed));
            $this->info('failed: ' . $failed);
            $this->info('failed_ids: ' . implode(',', $failedIds));
        };

        $actSignatureService->allByFiltersWithChunk([
            ['manager_signature_id', '=', null],
        ], self::COUNT_ITEMS, $callback, []);
    }
}
