<?php

declare(strict_types=1);

namespace App\Console\Commands\Acts;

use App\Models\Acts\Act;
use Illuminate\Console\Command;
use App\Services\Act\ActService;
use App\Dto\Entities\Acts\ActDto;
use Illuminate\Support\Collection;
use App\Services\Document\DocumentService;
use App\Dto\Entities\Acts\ActAllByFiltersDto;

final class AddDocumentHashToActsCommand extends Command
{
    private const COUNT_ITEMS = 300;

    protected $signature = 'acts:add-document-hash';

    protected $description = 'Прописать всем актам document_hash с сервиса документов';

    public function handle(ActService $actService, DocumentService $documentService): void
    {
        $iterator = 0;
        $failed = 0;

        $callback = function (Collection $items) use (&$iterator, &$failed, $actService, $documentService) {
            $items->map(function (Act $item) use (&$failed, $actService, $documentService) {
                $actDto = ActDto::fromArray($item->toArray());

                // обработка кейса, когда у нас документ акта не создан
                if ($actDocumentId = $actDto->getActDocumentId()) {
                    // обработка кейса, когда в сервисе документов не находится документ акта
                    // причина может быть любая, от падения сервиса - до удаления / аннулирования документа
                    try {
                        $documentDto = $documentService->findById($actDocumentId);
                        $actService->update(['id' => $actDto->getId()], ['document_hash' => $documentDto->hash()]);
                    } catch (\Exception $e) {
                        $failed++;
                    }
                }
            });

            $iterator += $items->count();

            $this->info('processed: ' . $iterator);
            $this->info('successful: ' . ($iterator - $failed));
            $this->info('failed: ' . $failed);
        };

        $actService->allByFiltersWithChunk(ActAllByFiltersDto::fromArray([
            'document_hash' => [['document_hash', '=', null]]
        ]), self::COUNT_ITEMS, $callback, []);
    }
}
