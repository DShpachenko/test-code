<?php

declare(strict_types=1);

namespace App\Console\Commands\Acts;

use App\Traits\CliLogger;
use NoName\Support\Strings;
use Illuminate\Console\Command;
use App\Services\Act\ActService;

final class DeleteActCommand extends Command
{
    use CliLogger;

    protected $signature = 'acts:delete-act {--id=}';

    protected $description = 'Удаление указанных актов';

    public function handle(ActService $actService): void
    {
        $actsIds = Strings::extractNumbers(($this->option('id') ?? ''), ',');

        if (empty($actsIds)) {
            $this->log('Missing act identifiers');

            return;
        }

        foreach ($actsIds as $actId) {
            $actService->delete(['id' => $actId]);

            $this->log('Act ' . $actId . ' removed!');
        }

        $this->log('Total: ' . count($actsIds));
    }
}
