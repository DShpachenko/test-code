<?php

declare(strict_types=1);

namespace App\Providers;

use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;

final class PolicyServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        $policies = config('policies');

        foreach ($policies as $policy) {
            Gate::define($policy['ability'], [$policy['callback']['policy'], $policy['callback']['method']]);
        }
    }
}
