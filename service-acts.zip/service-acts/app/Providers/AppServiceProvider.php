<?php

namespace App\Providers;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        if (app()->isLocal()) {
            Log::channel('sql')->info(str_pad('', 20, '-'));

            DB::listen(function ($query) {
                Log::channel('sql')->info($query->time, [
                    'query'    => $query->sql,
                    'bindings' => $query->bindings,
                ]);
            });
        }
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }
}
