<?php

use Illuminate\Support\Facades\Route;

Route::get('health-check', \NoName\HealthCheck\Controllers\HealthCheckController::class);

// TODO: временный роут, пока админы не настроят /health-check
Route::get('health', \NoName\HealthCheck\Controllers\HealthCheckController::class);
