<?php

use App\Http\Controllers\Api\V1\Company\TemplatesController as CompanyTemplatesController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\V1\Company\JobTypesController;
use App\Http\Controllers\Api\V1\Company\ActsController as CompanyActsController;
use App\Http\Controllers\Api\V1\Internal\ActsController as InternalActsController;
use App\Http\Controllers\Api\V1\Internal\TemplatesController as InternalTemplatesController;
use App\Http\Controllers\Api\V1\Contractor\ActsController as ContractorActsController;

Route::middleware('auth:jwt-auth')
     ->group(function () {

         Route::group([
             'prefix'    => 'company',
             'namespace' => 'Company',
         ], function () {
             Route::group([
                 'prefix' => 'jobs-types',
             ], function () {
                 Route::post('/', [JobTypesController::class, 'create']);
                 Route::get('all', [JobTypesController::class, 'all']);
                 Route::put('/{id}', [JobTypesController::class, 'update']);
                 Route::delete('/{id}', [JobTypesController::class, 'delete']);
             });

             Route::group([
                 'prefix' => 'acts',
             ], function () {
                 Route::post('/', [CompanyActsController::class, 'create']);
                 Route::get('/', [CompanyActsController::class, 'all']);
                 Route::get('/{id}', [CompanyActsController::class, 'get']);
                 Route::delete('/{id}', [CompanyActsController::class, 'delete']);
                 Route::post('/export', [CompanyActsController::class, 'export']);
                 Route::post('/sign/simple', [CompanyActsController::class, 'signBySimpleSignature']);
                 Route::get('/sign/info', [CompanyActsController::class, 'signingInfo']);
                 Route::get('/{id}/preview', [CompanyActsController::class, 'preview']);

             });

             Route::group([
                 'prefix' => 'templates',
             ], function () {
                 Route::post('/', [CompanyTemplatesController::class, 'create']);
                 Route::get('/', [CompanyTemplatesController::class, 'list']);
                 Route::get('/{id}', [CompanyTemplatesController::class, 'get']);
                 Route::post('/{id}', [CompanyTemplatesController::class, 'update']);
                 Route::get('/{id}/preview', [CompanyTemplatesController::class, 'preview']);
                 Route::delete('/{id}', [CompanyTemplatesController::class, 'delete']);
             });

         });

         Route::group([
             'prefix'    => 'contractor',
             'namespace' => 'Contractor',
         ], function () {
             Route::group([
                 'prefix' => 'acts',
             ], function () {
                 Route::get('/', [ContractorActsController::class, 'all']);
                 Route::get('/count', [ContractorActsController::class, 'count']);
                 Route::get('/{id}', [ContractorActsController::class, 'get']);
                 Route::get('/{id}/preview', [ContractorActsController::class, 'preview']);
             });
         });

     });

Route::prefix('internal')
     ->middleware('microservice')
     ->withoutMiddleware(['throttle:api'])
     ->group(function () {

         Route::prefix('acts')
              ->group(function () {
                  Route::post('/', [InternalActsController::class, 'createFromPaymentImport']);
              });

         Route::prefix('templates')
              ->group(function () {
                  Route::get('/', [InternalTemplatesController::class, 'list']);
                  Route::get('/{id}', [InternalTemplatesController::class, 'get']);
              });


     });

/*
 * Роут для отладки, чтобы сделать фейковую авторизацию (взято из сервиса документов).
 * Чтобы работало, нужно указать в .env:
 * -  SERVICE_AUTH_URL=http://service.acts.test/api
 * -  APP_USER_DEBUG_SERVICE_AUTH_URL = true
 */

if (app()->environment('local') && env('APP_USER_DEBUG_SERVICE_AUTH_URL')) {
    Route::get('check-jwt', function (\Illuminate\Http\Request $request) {
        $permissions = [
            'write-document' => true,
            'read-act'       => true,
        ];

        return [
            'data' => [
                'token_type' => 'customer',
                'contractor' => [
                    'type'        => 'contractor',
                    'id'          => 3980442,
                    'full_name'   => 'test user',
                    'email'       => 'test@test.com',
                    'company_id'  => 4255,
                    'agent_ids'   => [
                        61,
                    ],
                    'is_employee' => false,
                    'permissions' => [],
                ],
                'customer'   => [
                    'type'        => 'customer',
                    'id'          => 4648,
                    'full_name'   => 'test user',
                    'email'       => 'test@test.com',
                    'company_id'  => 4255,
                    'agent_ids'   => [
                        61,
                    ],
                    'is_employee' => false,
                    'permissions' => $permissions,
                ],
            ],
        ];
    });
}
