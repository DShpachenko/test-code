<?php

return [
    'ton'       => ':value ton|:value tons',
    'kg'        => ':value kilogram|:value kilograms',
    'gram'      => ':value gram|:value grams',
    'milligram' => ':value milligram|:value milligrams',
];
