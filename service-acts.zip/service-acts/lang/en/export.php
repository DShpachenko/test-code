<?php

declare(strict_types=1);

return [
    'status' => [
        'descriptions' => [
            '0' => 'Export of acts in progress.',
            '1' => 'Not all acts were downloaded.',
            '2' => 'Failed to export acts. Try again.',
            '3' => 'Acts were successfully imported.',
        ],
    ],
];
