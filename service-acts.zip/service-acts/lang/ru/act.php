<?php

declare(strict_types=1);

return [

    'default_name'                              => 'Акт выполненных работ',
    'sign_signature_notification_message_title' => 'Появился новый акт',
    'sign_signature_notification_message_body'  => 'Подпишите его в приложении',

];
