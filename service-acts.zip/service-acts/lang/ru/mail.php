<?php

declare(strict_types=1);

return [

    'send_export_mail_title_done' => 'Экспорт актов завершен',

];
