<?php

return [
    'ton'       => ':value тонна|:value тонны|:value тонн',
    'kg'        => ':value килограмм|:value килограмма|:value килограммов',
    'gram'      => ':value грамм|:value грамма|:value граммов',
    'milligram' => ':value миллиграмм|:value миллиграмма|:value миллиграммов',
];
